"""
Bulk upload: one ZIP file = an Excel sheet (metadata, one row per document) + the document files.

    my_batch.zip
      ├── metadata.xlsx          (any name ending .xlsx; use the sample template)
      ├── invoice_10008.pdf
      ├── committee_minutes_aug.docx
      └── ...

Every row becomes a document that goes through the normal workflow: registered,
files attached (SHA-256, OCR), metadata saved, and - when complete - submitted
to the Super Librarian for approval. Nothing is approved automatically.
"""
import io
import json
import logging
import os
import threading
import zipfile
from datetime import date

from django.conf import settings
from django.core.exceptions import ValidationError
from django.core.files.uploadedfile import SimpleUploadedFile
from django.db import close_old_connections, transaction
from django.utils import timezone

from ..models import (
    AcquisitionType, Action, BulkImport, Category, Confidentiality, Department, Document, InvoiceRecord, SourceType,
)
from . import lifecycle as L
from .audit import audit, notify
from .invoices import clean_text, parse_amount, parse_date

log = logging.getLogger("ldr")

MAX_ROWS = 2000
MAX_UNZIPPED = 4 * 1024 ** 3  # 4 GB

# key, heading, required, help, example (minutes), example (invoice)
COLUMNS = [
    ("file_name", "file_name", True, "Exact name of the file(s) inside the ZIP. Several files: separate with ;", "minutes_2025_08_12.pdf", "invoice_KLBH_389.pdf"),
    ("title", "title", True, "Title of the document", "Library Advisory Committee minutes - 12 Aug 2025", "KL Book House invoice KLBH/IN/389/2025-26"),
    ("category_code", "category_code", True, "Category code (see 'Categories' sheet), e.g. INV, MIN, NAAC", "MIN", "INV"),
    ("department", "department", False, "Department / section name (see 'Departments' sheet)", "Central Library", "Acquisition Section"),
    ("received_from", "received_from", False, "Originator / vendor / office the document came from", "Library Committee", "KL Book House"),
    ("received_date", "received_date", False, "Date received (DD-MM-YYYY). Blank = today", "12-08-2025", "06-08-2025"),
    ("reference_number", "reference_number", False, "Letter / order / invoice number", "LAC/2025/03", "KLBH/IN/389/2025-26"),
    ("physical_location", "physical_location", False, "Where the hard copy is kept", "Cabinet B, File 4", "Cabinet A, File 12"),
    ("description", "description", True, "Short description (required for submission)", "Minutes of the 3rd meeting: e-resources renewal, stock verification", "Purchase of books for Physics and Chemistry"),
    ("document_year", "document_year", True, "Year or period, e.g. 2025 or 2025-26", "2025-26", "2025-26"),
    ("document_date", "document_date", False, "Date written on the document (DD-MM-YYYY)", "12-08-2025", "06-08-2025"),
    ("keywords", "keywords", False, "Comma-separated keywords", "committee, e-resources", "books, purchase, physics"),
    ("creator", "creator", False, "Author / creator", "Librarian", ""),
    ("language", "language", False, "Language (blank = English)", "English", "English"),
    ("access", "access", False, "OPEN, DEPARTMENT or PERMISSION (proposed; final decision at approval)", "DEPARTMENT", "OPEN"),
    ("vendor", "invoice_vendor", False, "INVOICES ONLY - vendor / source", "", "KL Book House"),
    ("invoice_no", "invoice_no", False, "INVOICES ONLY - invoice / bill number", "", "KLBH/IN/389/2025-26"),
    ("invoice_date", "invoice_date", False, "INVOICES ONLY - invoice date (DD-MM-YYYY)", "", "06-08-2025"),
    ("po_number", "po_number", False, "INVOICES ONLY - purchase order number", "", "PU/LIB/PO/112"),
    ("po_date", "po_date", False, "INVOICES ONLY - purchase order date", "", "20-07-2025"),
    ("accession_range", "accession_no", False, "INVOICES ONLY - accession number(s), e.g. 61584-62180", "", "61584-62180"),
    ("no_of_titles", "no_of_titles", False, "INVOICES ONLY - number of titles", "", "412"),
    ("no_of_books", "no_of_books", False, "INVOICES ONLY - number of books (blank = from accession range)", "", ""),
    ("invoice_amount", "invoice_amount", False, "INVOICES ONLY - invoice amount in Rs", "", "303974"),
    ("acquisition_type", "acquisition_type", False, "INVOICES ONLY - PURCHASE, DONATION or COMPLIMENTARY", "", "PURCHASE"),
]
INVOICE_KEYS = ("vendor", "invoice_no", "invoice_date", "po_number", "po_date", "accession_range", "no_of_titles",
                "no_of_books", "invoice_amount", "acquisition_type")
ACCESS = {"OPEN": Confidentiality.GENERAL, "GENERAL": Confidentiality.GENERAL, "DEPARTMENT": Confidentiality.DEPARTMENT,
          "PERMISSION": Confidentiality.CONFIDENTIAL, "CONFIDENTIAL": Confidentiality.CONFIDENTIAL, "RESTRICTED": Confidentiality.CONFIDENTIAL}


def _norm(h):
    return clean_text(h).lower().replace("*", "").strip().replace(" ", "_").replace("-", "_")


HEADING_TO_KEY = {}
for key, heading, *_ in COLUMNS:
    HEADING_TO_KEY[_norm(heading)] = key
    HEADING_TO_KEY[_norm(key)] = key
HEADING_TO_KEY.update({"filename": "file_name", "file": "file_name", "files": "file_name", "category": "category_code",
                       "year": "document_year", "accession_range": "accession_range", "acc_no": "accession_range",
                       "amount_rs": "invoice_amount", "po_no": "po_number"})


# ----------------------------------------------------------------------- template & sample
def build_template():
    import openpyxl
    from openpyxl.comments import Comment
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter
    from openpyxl.worksheet.datavalidation import DataValidation

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Documents"
    req_fill, opt_fill, inv_fill = PatternFill("solid", fgColor="0F5C63"), PatternFill("solid", fgColor="5B7F84"), PatternFill("solid", fgColor="A06200")
    for i, (key, heading, required, helptext, *_e) in enumerate(COLUMNS, 1):
        c = ws.cell(1, i, heading + (" *" if required else ""))
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = req_fill if required else (inv_fill if key in INVOICE_KEYS else opt_fill)
        c.alignment = Alignment(wrap_text=True, vertical="center")
        c.comment = Comment(helptext, "LDR")
        ws.column_dimensions[get_column_letter(i)].width = max(14, min(42, len(heading) + 6))
        ws.cell(2, i, COLUMNS[i - 1][4])
        ws.cell(3, i, COLUMNS[i - 1][5])
    ws.row_dimensions[1].height = 32
    ws.freeze_panes = "B2"
    codes = list(Category.objects.filter(is_active=True).values_list("code", flat=True)) or ["INV", "MIN"]
    dv = DataValidation(type="list", formula1='"' + ",".join(codes)[:250] + '"', allow_blank=False)
    ws.add_data_validation(dv)
    dv.add(f"C2:C{MAX_ROWS + 1}")
    dv2 = DataValidation(type="list", formula1='"OPEN,DEPARTMENT,PERMISSION"', allow_blank=True)
    ws.add_data_validation(dv2)
    dv2.add(f"O2:O{MAX_ROWS + 1}")
    dv3 = DataValidation(type="list", formula1='"PURCHASE,DONATION,COMPLIMENTARY,OTHER"', allow_blank=True)
    ws.add_data_validation(dv3)
    dv3.add(f"Y2:Y{MAX_ROWS + 1}")

    ins = wb.create_sheet("Instructions")
    ins.append(["How to use this template"])
    ins["A1"].font = Font(bold=True, size=14)
    for line in [
        "1. Fill one row per document on the 'Documents' sheet. Delete the two example rows (rows 2 and 3) first.",
        "2. Columns marked * are required. Dark-green = required, grey-green = optional, orange = only for invoices.",
        "3. Put this Excel file and ALL the document files into ONE folder, select them all, right-click > Send to > Compressed (zipped) folder.",
        "4. In LDR open 'Bulk upload', choose the ZIP file and click 'Check file'. LDR lists any problems before importing anything.",
        "5. Click 'Start import'. Each row becomes a document with its files and metadata, sent to the Super Librarian for approval.",
        "6. Invoice columns (orange) also fill the Invoice register, so book counts and amounts appear in the invoice statistics.",
        "Dates: DD-MM-YYYY (e.g. 06-08-2025). File names must match exactly, including the extension (.pdf, .docx, .xlsx, .jpg).",
    ]:
        ins.append([line])
    ins.append([])
    ins.append(["Column", "Required", "Meaning", "Example"])
    for c in ins[ins.max_row]:
        c.font = Font(bold=True)
    for key, heading, required, helptext, ex1, ex2 in COLUMNS:
        ins.append([heading, "yes" if required else "", helptext, ex2 or ex1])
    ins.column_dimensions["A"].width = 20
    ins.column_dimensions["B"].width = 10
    ins.column_dimensions["C"].width = 80
    ins.column_dimensions["D"].width = 40

    cat = wb.create_sheet("Categories")
    cat.append(["category_code", "Category", "Retention (years, 0 = permanent)"])
    for c in cat[1]:
        c.font = Font(bold=True)
    for cobj in Category.objects.filter(is_active=True).order_by("code"):
        cat.append([cobj.code, cobj.name, cobj.retention_years])
    cat.column_dimensions["B"].width = 40
    dep = wb.create_sheet("Departments")
    dep.append(["department"])
    dep["A1"].font = Font(bold=True)
    for d in Department.objects.order_by("name"):
        dep.append([d.name])
    dep.column_dimensions["A"].width = 40
    out = io.BytesIO()
    wb.save(out)
    return out.getvalue()


def _sample_pdf(title, lines):
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas

    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    c.setFont("Helvetica-Bold", 16)
    c.drawString(72, 770, title)
    c.setFont("Helvetica", 11)
    y = 740
    for line in lines:
        c.drawString(72, y, line)
        y -= 18
    c.save()
    return buf.getvalue()


def build_sample_zip():
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("metadata.xlsx", build_template())
        zf.writestr("minutes_2025_08_12.pdf", _sample_pdf("Library Advisory Committee - Minutes", [
            "Date: 12 August 2025", "1. Renewal of e-resources for 2026 approved.", "2. Stock verification to finish by March."]))
        zf.writestr("invoice_KLBH_389.pdf", _sample_pdf("KL Book House - Tax Invoice", [
            "Invoice No: KLBH/IN/389/2025-26   Date: 06-08-2025", "To: The Librarian", "Supply of books (Acc. 61584-62180)",
            "Total: Rs 3,03,974.00"]))
        zf.writestr("READ_ME.txt", "Sample bulk-upload ZIP for LDR.\r\nmetadata.xlsx describes the two sample files.\r\n"
                                   "Replace them with your own files and rows, zip the folder and upload it in LDR > Bulk upload.\r\n")
    return buf.getvalue()


# ----------------------------------------------------------------------- validation
def _find_sheet(zf):
    names = [n for n in zf.namelist() if n.lower().endswith((".xlsx", ".xlsm")) and not os.path.basename(n).startswith("~$")
             and "__macosx" not in n.lower()]
    if not names:
        raise ValidationError("The ZIP must contain the metadata Excel file (.xlsx). Download the sample template.")
    preferred = [n for n in names if "metadata" in os.path.basename(n).lower()]
    return (preferred or sorted(names, key=len))[0]


def _file_index(zf, sheet_name):
    idx = {}
    for info in zf.infolist():
        if info.is_dir() or info.filename == sheet_name or "__macosx" in info.filename.lower():
            continue
        idx.setdefault(os.path.basename(info.filename).lower(), info.filename)
    return idx


def validate_zip(path):
    """Returns (rows, problems). rows = list of dicts ready for import; problems = list of row messages."""
    import openpyxl

    rows, problems = [], []
    try:
        zf = zipfile.ZipFile(path)
    except zipfile.BadZipFile:
        return [], [{"row": "-", "error": "This is not a valid ZIP file."}]
    with zf:
        if sum(i.file_size for i in zf.infolist()) > MAX_UNZIPPED:
            return [], [{"row": "-", "error": "The ZIP is larger than 4 GB when unpacked. Split it into smaller batches."}]
        try:
            sheet = _find_sheet(zf)
        except ValidationError as e:
            return [], [{"row": "-", "error": e.messages[0]}]
        wb = openpyxl.load_workbook(io.BytesIO(zf.read(sheet)), data_only=True, read_only=True)
        ws = wb["Documents"] if "Documents" in wb.sheetnames else wb.worksheets[0]
        it = ws.iter_rows(values_only=True)
        header = next(it, None) or []
        keys = [HEADING_TO_KEY.get(_norm(h)) for h in header]
        missing = [h for k, h, req, *_ in COLUMNS if req and k not in keys]
        if missing:
            return [], [{"row": 1, "error": "Missing column(s): " + ", ".join(missing) + ". Use the sample template."}]
        files = _file_index(zf, sheet)
        cats = {c.code.upper(): c for c in Category.objects.filter(is_active=True)}
        cats.update({c.name.upper(): c for c in Category.objects.filter(is_active=True)})
        deps = {d.name.upper(): d for d in Department.objects.all()}
        for rnum, values in enumerate(it, 2):
            rec = {k: values[i] for i, k in enumerate(keys) if k and i < len(values)}
            if not any(clean_text(v) for v in rec.values()):
                continue
            if len(rows) >= MAX_ROWS:
                problems.append({"row": rnum, "error": f"More than {MAX_ROWS} rows - split into several ZIP files."})
                break
            errs = []
            title = clean_text(rec.get("title"))
            if not title:
                errs.append("title is empty")
            cat = cats.get(clean_text(rec.get("category_code")).upper())
            if not cat:
                errs.append(f"unknown category_code '{clean_text(rec.get('category_code'))}'")
            fnames = [f.strip() for f in clean_text(rec.get("file_name")).split(";") if f.strip()]
            if not fnames:
                errs.append("file_name is empty")
            members = []
            for f in fnames:
                m = files.get(os.path.basename(f).lower())
                if not m:
                    errs.append(f"file '{f}' is not in the ZIP")
                else:
                    ext = f.rsplit(".", 1)[-1].lower() if "." in f else ""
                    if ext not in L.ALLOWED_EXT:
                        errs.append(f"file type .{ext} not allowed")
                    members.append(m)
            dep = None
            if clean_text(rec.get("department")):
                dep = deps.get(clean_text(rec.get("department")).upper())
                if not dep:
                    errs.append(f"unknown department '{clean_text(rec.get('department'))}'")
            dates = {}
            for dk in ("received_date", "document_date", "invoice_date", "po_date"):
                if clean_text(rec.get(dk)):
                    d = parse_date(rec.get(dk))
                    if not d:
                        errs.append(f"{dk} '{clean_text(rec.get(dk))}' is not a date (use DD-MM-YYYY)")
                    dates[dk] = d
            if dates.get("received_date") and dates["received_date"] > date.today():
                errs.append("received_date is in the future")
            access = ACCESS.get(clean_text(rec.get("access")).upper()) if clean_text(rec.get("access")) else None
            if clean_text(rec.get("access")) and not access:
                errs.append("access must be OPEN, DEPARTMENT or PERMISSION")
            amount = parse_amount(rec.get("invoice_amount")) if clean_text(rec.get("invoice_amount")) else None
            if clean_text(rec.get("invoice_amount")) and amount is None:
                errs.append("invoice_amount is not a number")
            missing_meta = [k for k in ("description", "document_year") if not clean_text(rec.get(k))]
            row = {
                "row": rnum, "title": title, "category_id": cat.pk if cat else None, "category": cat.code if cat else "",
                "department_id": dep.pk if dep else None, "files": members,
                "received_from": clean_text(rec.get("received_from")), "received_date": dates.get("received_date"),
                "reference_number": clean_text(rec.get("reference_number")),
                "physical_location": clean_text(rec.get("physical_location")),
                "description": clean_text(rec.get("description")), "document_year": clean_text(rec.get("document_year")),
                "document_date": dates.get("document_date"), "keywords": clean_text(rec.get("keywords")),
                "creator": clean_text(rec.get("creator")), "language": clean_text(rec.get("language")) or "English",
                "access": access, "missing_meta": missing_meta,
                "invoice": None,
            }
            if any(clean_text(rec.get(k)) for k in INVOICE_KEYS):
                acq = clean_text(rec.get("acquisition_type")).upper() or "PURCHASE"
                if acq not in AcquisitionType.values:
                    errs.append("acquisition_type must be PURCHASE, DONATION, COMPLIMENTARY or OTHER")
                nb = clean_text(rec.get("no_of_books"))
                nt = clean_text(rec.get("no_of_titles"))
                row["invoice"] = {
                    "vendor": clean_text(rec.get("vendor")) or row["received_from"],
                    "invoice_no": clean_text(rec.get("invoice_no")) or row["reference_number"],
                    "invoice_date": dates.get("invoice_date") or row["document_date"], "po_number": clean_text(rec.get("po_number")),
                    "po_date": dates.get("po_date"), "accession_range": clean_text(rec.get("accession_range")),
                    "no_of_titles": int(float(nt)) if nt.replace(".", "", 1).isdigit() else None,
                    "no_of_books": int(float(nb)) if nb.replace(".", "", 1).isdigit() else None,
                    "amount": amount, "acquisition_type": acq,
                }
                if not row["invoice"]["vendor"]:
                    errs.append("invoice rows need invoice_vendor (or received_from)")
            row["errors"] = errs
            if errs:
                problems.append({"row": rnum, "error": "; ".join(errs), "title": title})
            rows.append(row)
        if not rows and not problems:
            problems.append({"row": "-", "error": "The Documents sheet has no rows."})
    return rows, problems


def _json_default(o):
    if isinstance(o, date):
        return o.isoformat()
    return str(o)


def create_batch(upload, user):
    folder = settings.DATA_DIR / "bulk"
    folder.mkdir(parents=True, exist_ok=True)
    stamp = timezone.localtime().strftime("%Y%m%d_%H%M%S")
    path = folder / f"batch_{stamp}_{user.pk}.zip"
    with open(path, "wb") as fh:
        for chunk in upload.chunks():
            fh.write(chunk)
    rows, problems = validate_zip(path)
    batch = BulkImport.objects.create(
        created_by=user, file_name=os.path.basename(upload.name), stored_path=str(path),
        state=BulkImport.State.INVALID if problems else BulkImport.State.VALIDATED, total_rows=len(rows),
        report=json.dumps({"rows": rows, "problems": problems}, default=_json_default),
    )
    if problems:
        try:
            os.remove(path)
        except OSError:
            pass
    return batch


# ----------------------------------------------------------------------- import
def _d(v):
    return date.fromisoformat(v) if isinstance(v, str) and v else (v or None)


def run_import(batch_id):
    batch = BulkImport.objects.get(pk=batch_id)
    user = batch.created_by
    data = json.loads(batch.report)
    rows = data["rows"]
    results = []
    batch.state = BulkImport.State.RUNNING
    batch.save(update_fields=["state"])
    try:
        with zipfile.ZipFile(batch.stored_path) as zf:
            for row in rows:
                res = {"row": row["row"], "title": row["title"]}
                try:
                    with transaction.atomic():
                        doc = Document(
                            title=row["title"], category_id=row["category_id"], department_id=row["department_id"],
                            source_type=SourceType.BORN_DIGITAL, received_from=row["received_from"],
                            received_date=_d(row["received_date"]) or timezone.localdate(),
                            reference_number=row["reference_number"], physical_location=row["physical_location"],
                            custodian=user,
                        )
                        if row.get("access"):
                            doc.confidentiality = row["access"]
                        else:
                            doc.confidentiality = Category.objects.get(pk=row["category_id"]).default_confidentiality
                        L.register_document(doc, user)
                        for member in row["files"]:
                            content = zf.read(member)
                            L.add_file(doc, SimpleUploadedFile(os.path.basename(member), content), user)
                        doc.description = row["description"]
                        doc.document_year = row["document_year"]
                        doc.document_date = _d(row["document_date"])
                        doc.keywords = row["keywords"]
                        doc.creator = row["creator"]
                        doc.language = row["language"]
                        inv = row.get("invoice")
                        if inv and inv.get("amount") not in (None, ""):
                            doc.amount = inv["amount"]
                        L.mark_digitized(doc, user)
                        L.save_metadata(doc, user, ["description", "document_year", "document_date", "keywords"])
                        if inv:
                            fields = dict(
                                vendor=inv["vendor"], invoice_no=inv["invoice_no"], invoice_date=_d(inv["invoice_date"]),
                                po_number=inv["po_number"], po_date=_d(inv["po_date"]), accession_range=inv["accession_range"],
                                no_of_titles=inv["no_of_titles"], no_of_books=inv["no_of_books"], amount=inv["amount"] or None,
                                acquisition_type=inv["acquisition_type"],
                            )
                            existing = None
                            if inv["invoice_no"]:
                                existing = InvoiceRecord.objects.filter(
                                    vendor__iexact=inv["vendor"], invoice_no__iexact=inv["invoice_no"], document__isnull=True).first()
                            if existing:  # already in the register (e.g. imported index): link it, fill gaps
                                existing.document = doc
                                for k, v in fields.items():
                                    if v not in (None, "") and getattr(existing, k) in (None, ""):
                                        setattr(existing, k, v)
                                existing.save()
                                res["invoice"] = "linked to existing register entry"
                            else:
                                InvoiceRecord.objects.create(document=doc, created_by=user, **fields)
                    if not inv:  # invoice without register columns: read the details from the file itself
                        from .invoice_jobs import is_invoice_document, read_into_register

                        if is_invoice_document(doc):
                            try:
                                got = read_into_register(doc, user)
                                if got["records"]:
                                    res["invoice"] = "read automatically from the file - please check"
                                doc.refresh_from_db()
                            except Exception:
                                log.exception("automatic invoice reading failed")
                    with transaction.atomic():
                        if batch.submit_for_approval and not L.metadata_missing(doc):
                            L.submit_for_approval(doc, user, notify_approvers=False)
                            res["status"] = "submitted"
                        else:
                            res["status"] = "in workflow"
                        res["doc_id"] = doc.doc_id
                        res["pk"] = doc.pk
                    batch.imported += 1
                except Exception as exc:  # one bad row never stops the batch
                    log.exception("bulk row failed")
                    res["status"] = "failed"
                    res["error"] = "; ".join(exc.messages) if isinstance(exc, ValidationError) else f"{exc.__class__.__name__}: {exc}"
                    batch.failed += 1
                results.append(res)
                batch.processed += 1
                batch.report = json.dumps({"rows": rows, "problems": data.get("problems", []), "results": results},
                                          default=_json_default)
                batch.save(update_fields=["processed", "imported", "failed", "report"])
        batch.state = BulkImport.State.DONE
    except Exception as exc:
        log.exception("bulk import failed")
        batch.state = BulkImport.State.FAILED
        results.append({"row": "-", "status": "failed", "error": f"{exc.__class__.__name__}: {exc}"})
        batch.report = json.dumps({"rows": rows, "problems": data.get("problems", []), "results": results}, default=_json_default)
    batch.finished_at = timezone.now()
    batch.save()
    audit(Action.BULK_IMPORT, user=user, details=f"Batch #{batch.pk} {batch.file_name}: {batch.imported} imported, "
                                                 f"{batch.failed} failed of {batch.total_rows}")
    submitted = sum(1 for r in results if r.get("status") == "submitted")
    if submitted:
        notify(L.approvers(), f"Bulk upload: {submitted} documents from {user.display_name()} are awaiting approval.",
               link="/approvals/", level="warning")
    try:
        os.remove(batch.stored_path)
    except OSError:
        pass
    return batch


def start_import(batch, submit_for_approval=True, background=True):
    batch.submit_for_approval = submit_for_approval
    batch.state = BulkImport.State.RUNNING
    batch.save(update_fields=["submit_for_approval", "state"])
    if not background:
        return run_import(batch.pk)

    def _job(pk):
        try:
            run_import(pk)
        finally:
            close_old_connections()

    threading.Thread(target=_job, args=(batch.pk,), daemon=True, name=f"ldr-bulk-{batch.pk}").start()
    return batch
