"""
LDR release tool - for the DEVELOPER only (not needed by libraries).

Publishing a new version
------------------------
    python tools/release.py build --version 1.2.0 --notes "Added X; fixed Y" \
        --url https://YOUR-SITE/latest.json --key ../ldr_signing_key.pem --website website

This will:
  1. set the version number inside the application,
  2. create dist/LDR-1.2.0.zip containing a manifest of every file (SHA-256)
     and your digital signature,
  3. write dist/latest.json,
  4. (with --website) copy the zip to website/downloads/ and latest.json to website/.

Then upload the website folder (or just the new zip + latest.json) to your web host.
Every installed LDR sees "Update available" within a day.

One-time: creating a new signing key
------------------------------------
    python tools/release.py keygen --key ../ldr_signing_key.pem

Keep the private key file SAFE and PRIVATE (back it up!). Anyone with it can publish
updates that all libraries will trust. If you lose it you cannot publish updates to
existing installations. (Changing the key requires every library to install the next
version manually once.)
"""
import argparse
import base64
import hashlib
import json
import re
import shutil
import sys
import zipfile
from datetime import date, datetime
from pathlib import Path

APP = Path(__file__).resolve().parent.parent
EXCLUDE_TOP = {"data", ".venv", "venv", "staticfiles", "ldr_config.ini", ".git", "dist", "release_keys", "website", "release_settings.ini", "publish_release.bat", "ocr",
               "RELEASE_MANIFEST.json", "RELEASE_SIGNATURE.txt"}


def collect_files():
    files = []
    for p in sorted(APP.rglob("*")):
        if not p.is_file():
            continue
        rel = p.relative_to(APP)
        if rel.parts[0] in EXCLUDE_TOP or "__pycache__" in rel.parts or p.suffix in (".pyc", ".pyo"):
            continue
        if rel.name.startswith("file:memorydb") or rel.name.endswith("_key.pem") or rel.name == ".DS_Store":
            continue
        files.append(rel)
    return files


def load_private_key(path):
    from cryptography.hazmat.primitives.serialization import load_pem_private_key

    return load_pem_private_key(Path(path).read_bytes(), password=None)


def set_version(version):
    p = APP / "ldr_project" / "settings.py"
    s = p.read_text(encoding="utf-8")
    s, n = re.subn(r'LDR_VERSION = "[^"]*"', f'LDR_VERSION = "{version}"', s)
    if n != 1:
        sys.exit("Could not find LDR_VERSION in settings.py")
    p.write_text(s, encoding="utf-8")


def set_update_url(url):
    p = APP / "repository" / "update_source.py"
    s = p.read_text(encoding="utf-8")
    s = re.sub(r'UPDATE_URL = "[^"]*"', f'UPDATE_URL = "{url}"', s)
    p.write_text(s, encoding="utf-8")


def set_public_key(pem):
    p = APP / "repository" / "update_source.py"
    s = p.read_text(encoding="utf-8")
    s = re.sub(r'PUBLIC_KEY_PEM = """.*?"""', f'PUBLIC_KEY_PEM = """{pem.strip()}\n"""', s, flags=re.S)
    p.write_text(s, encoding="utf-8")


def cmd_keygen(args):
    from cryptography.hazmat.primitives import serialization as S
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

    key_path = Path(args.key)
    if key_path.exists() and not args.force:
        sys.exit(f"{key_path} already exists. Use --force to replace it (existing installations will then reject updates).")
    k = Ed25519PrivateKey.generate()
    key_path.write_bytes(k.private_bytes(S.Encoding.PEM, S.PrivateFormat.PKCS8, S.NoEncryption()))
    pub = k.public_key().public_bytes(S.Encoding.PEM, S.PublicFormat.SubjectPublicKeyInfo).decode()
    set_public_key(pub)
    print(f"Private key written to {key_path.resolve()}  <-- keep it secret and backed up")
    print("Public key embedded in repository/update_source.py")


def cmd_build(args):
    from cryptography.hazmat.primitives import serialization as S

    key = load_private_key(args.key)
    # safety: private key must match the public key shipped in the app
    embedded = (APP / "repository" / "update_source.py").read_text(encoding="utf-8")
    pub = key.public_key().public_bytes(S.Encoding.PEM, S.PublicFormat.SubjectPublicKeyInfo).decode().strip()
    if pub not in embedded:
        sys.exit("This private key does not match the public key inside the application. Wrong key file?")

    version = args.version.strip().lstrip("v")
    set_version(version)
    if args.url:
        set_update_url(args.url)

    files = collect_files()
    manifest = {
        "product": "LDR",
        "version": version,
        "created": datetime.now().isoformat(timespec="seconds"),
        "min_from_version": args.min_from or "",
        "notes": args.notes or "",
        "files": {str(rel).replace("\\", "/"): hashlib.sha256((APP / rel).read_bytes()).hexdigest() for rel in files},
    }
    manifest_bytes = json.dumps(manifest, indent=1, sort_keys=True).encode("utf-8")
    signature = base64.b64encode(key.sign(manifest_bytes)).decode()

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    zip_name = f"LDR-{version}.zip"
    zip_path = out / zip_name
    top = f"LDR-{version}"
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for rel in files:
            zf.write(APP / rel, f"{top}/{str(rel).replace(chr(92), '/')}")
        zf.writestr(f"{top}/RELEASE_MANIFEST.json", manifest_bytes)
        zf.writestr(f"{top}/RELEASE_SIGNATURE.txt", signature + "\n")
    sha = hashlib.sha256(zip_path.read_bytes()).hexdigest()

    download_url = f"downloads/{zip_name}" if args.website else zip_name
    latest = {
        "product": "LDR",
        "version": version,
        "released": date.today().isoformat(),
        "notes": args.notes or "",
        "download_url": download_url,
        "sha256": sha,
        "size": zip_path.stat().st_size,
        "min_from_version": args.min_from or "",
    }
    (out / "latest.json").write_text(json.dumps(latest, indent=1), encoding="utf-8")
    print(f"Built {zip_path}  ({zip_path.stat().st_size / 1024:.0f} KB, {len(files)} files, signed)")
    print(f"Wrote {out / 'latest.json'}")
    if args.website:
        web = Path(args.website)
        (web / "downloads").mkdir(parents=True, exist_ok=True)
        shutil.copy2(zip_path, web / "downloads" / zip_name)
        (web / "latest.json").write_text(json.dumps(latest, indent=1), encoding="utf-8")
        print(f"Copied to {web}/downloads/{zip_name} and {web}/latest.json")
        print("Now upload the website folder to your web host.")
    else:
        print(f"Upload {zip_name} and latest.json to the same folder on your website.")


def main():
    ap = argparse.ArgumentParser(description="LDR release tool (developer only)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    k = sub.add_parser("keygen", help="create a new signing key pair")
    k.add_argument("--key", default=str(APP.parent / "ldr_signing_key.pem"))
    k.add_argument("--force", action="store_true")
    b = sub.add_parser("build", help="build and sign a release")
    b.add_argument("--version", required=True)
    b.add_argument("--notes", default="", help="What's new (shown to administrators)")
    b.add_argument("--url", default="", help="Address of latest.json on your website")
    b.add_argument("--key", default=str(APP.parent / "ldr_signing_key.pem"))
    b.add_argument("--out", default=str(APP / "dist"))
    b.add_argument("--website", default="", help="Website folder to copy the release into")
    b.add_argument("--min-from", default="", help="Oldest version that can update directly")
    args = ap.parse_args()
    {"keygen": cmd_keygen, "build": cmd_build}[args.cmd](args)


if __name__ == "__main__":
    main()
