"""
Django settings for LDR - Library Document Repository.

All installation-specific values are read from ``ldr_config.ini`` in the
application folder (created automatically on first start), so librarians
never need to edit Python files.
"""
import configparser
import os
import secrets
import sys
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
CONFIG_FILE = Path(os.environ.get("LDR_CONFIG", BASE_DIR / "ldr_config.ini"))

LDR_VERSION = "1.3.0"


def _load_config():
    cfg = configparser.ConfigParser()
    if CONFIG_FILE.exists():
        cfg.read(CONFIG_FILE, encoding="utf-8")
    changed = False
    defaults = {
        "server": {"host": "0.0.0.0", "port": "8080", "threads": "8"},
        "paths": {"data_dir": "data"},
        "security": {"secret_key": "", "debug": "false", "allowed_hosts": "*"},
        "database": {
            "engine": "sqlite",
            "name": "ldr",
            "user": "ldr",
            "password": "",
            "host": "localhost",
            "port": "5432",
        },
        "ocr": {"enabled": "true", "tesseract_cmd": "", "languages": "eng"},
        "email": {
            "enabled": "false",
            "host": "",
            "port": "587",
            "user": "",
            "password": "",
            "use_tls": "true",
            "from_address": "",
        },
    }
    for section, values in defaults.items():
        if not cfg.has_section(section):
            cfg.add_section(section)
            changed = True
        for key, val in values.items():
            if not cfg.has_option(section, key):
                cfg.set(section, key, val)
                changed = True
    if not cfg.get("security", "secret_key"):
        cfg.set("security", "secret_key", secrets.token_urlsafe(50))
        changed = True
    if changed:
        try:
            with open(CONFIG_FILE, "w", encoding="utf-8") as fh:
                cfg.write(fh)
        except OSError:
            pass
    return cfg


CONFIG = _load_config()

SECRET_KEY = CONFIG.get("security", "secret_key")
DEBUG = CONFIG.getboolean("security", "debug")
ALLOWED_HOSTS = [h.strip() for h in CONFIG.get("security", "allowed_hosts").split(",") if h.strip()]

_data = Path(CONFIG.get("paths", "data_dir"))
DATA_DIR = _data if _data.is_absolute() else BASE_DIR / _data
DATA_DIR.mkdir(parents=True, exist_ok=True)
MEDIA_ROOT = DATA_DIR / "repository_files"
BACKUP_DIR = DATA_DIR / "backups"
LOG_DIR = DATA_DIR / "logs"
for _d in (MEDIA_ROOT, BACKUP_DIR, LOG_DIR):
    _d.mkdir(parents=True, exist_ok=True)

INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "django.contrib.humanize",
    "repository",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "whitenoise.middleware.WhiteNoiseMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
    "repository.middleware.SetupRequiredMiddleware",
    "repository.middleware.PermissionNeededMiddleware",
]

ROOT_URLCONF = "ldr_project.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
                "repository.context_processors.ldr_context",
            ],
        },
    },
]

WSGI_APPLICATION = "ldr_project.wsgi.application"

if CONFIG.get("database", "engine").lower() in ("postgres", "postgresql"):
    DATABASES = {
        "default": {
            "ENGINE": "django.db.backends.postgresql",
            "NAME": CONFIG.get("database", "name"),
            "USER": CONFIG.get("database", "user"),
            "PASSWORD": CONFIG.get("database", "password"),
            "HOST": CONFIG.get("database", "host"),
            "PORT": CONFIG.get("database", "port"),
        }
    }
else:
    DATABASES = {
        "default": {
            "ENGINE": "django.db.backends.sqlite3",
            "NAME": DATA_DIR / "ldr.sqlite3",
            "OPTIONS": {"timeout": 30, "init_command": "PRAGMA journal_mode=WAL;"},
        }
    }
    if "test" in sys.argv:
        DATABASES["default"]["OPTIONS"] = {"timeout": 30}

AUTH_USER_MODEL = "repository.User"
LOGIN_URL = "login"
LOGIN_REDIRECT_URL = "dashboard"
LOGOUT_REDIRECT_URL = "login"
SESSION_COOKIE_AGE = 8 * 60 * 60  # one working day
SESSION_EXPIRE_AT_BROWSER_CLOSE = True

AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator"},
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator", "OPTIONS": {"min_length": 8}},
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
]

LANGUAGE_CODE = "en-in"
TIME_ZONE = "Asia/Kolkata"
USE_I18N = True
USE_TZ = True

STATIC_URL = "static/"
STATIC_ROOT = BASE_DIR / "staticfiles"
STORAGES = {
    "default": {"BACKEND": "django.core.files.storage.FileSystemStorage"},
    "staticfiles": {"BACKEND": "whitenoise.storage.CompressedStaticFilesStorage"},
}
WHITENOISE_USE_FINDERS = True

DATA_UPLOAD_MAX_MEMORY_SIZE = 50 * 1024 * 1024
FILE_UPLOAD_MAX_MEMORY_SIZE = 10 * 1024 * 1024
MAX_UPLOAD_MB = 200

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

# OCR
OCR_ENABLED = CONFIG.getboolean("ocr", "enabled")
TESSERACT_CMD = CONFIG.get("ocr", "tesseract_cmd")
OCR_LANGUAGES = CONFIG.get("ocr", "languages")

# Email alerts (optional)
if CONFIG.getboolean("email", "enabled"):
    EMAIL_BACKEND = "django.core.mail.backends.smtp.EmailBackend"
    EMAIL_HOST = CONFIG.get("email", "host")
    EMAIL_PORT = CONFIG.getint("email", "port")
    EMAIL_HOST_USER = CONFIG.get("email", "user")
    EMAIL_HOST_PASSWORD = CONFIG.get("email", "password")
    EMAIL_USE_TLS = CONFIG.getboolean("email", "use_tls")
    DEFAULT_FROM_EMAIL = CONFIG.get("email", "from_address") or EMAIL_HOST_USER
else:
    EMAIL_BACKEND = "django.core.mail.backends.locmem.EmailBackend"

LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {"std": {"format": "%(asctime)s %(levelname)s %(name)s: %(message)s"}},
    "handlers": {
        "file": {
            "class": "logging.handlers.RotatingFileHandler",
            "filename": str(LOG_DIR / "ldr.log"),
            "maxBytes": 5 * 1024 * 1024,
            "backupCount": 5,
            "formatter": "std",
            "encoding": "utf-8",
        },
        "console": {"class": "logging.StreamHandler", "formatter": "std"},
    },
    "loggers": {
        "ldr": {"handlers": ["file", "console"], "level": "INFO", "propagate": False},
        "django": {"handlers": ["file"], "level": "WARNING"},
    },
}
