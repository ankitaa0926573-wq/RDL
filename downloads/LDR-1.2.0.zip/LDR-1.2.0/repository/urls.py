from django.contrib.auth import views as auth_views
from django.urls import path

from . import bulk_views as bv
from . import invoice_views as iv
from . import views as v

urlpatterns = [
    path("setup/", v.setup, name="setup"),
    path("login/", auth_views.LoginView.as_view(template_name="repository/login.html", redirect_authenticated_user=True), name="login"),
    path("logout/", auth_views.LogoutView.as_view(), name="logout"),
    path("", v.dashboard, name="dashboard"),
    # documents
    path("documents/", v.document_list, name="document_list"),
    path("documents/export.csv", v.document_export, name="document_export"),
    path("documents/new/", v.document_new, name="document_new"),
    path("documents/<int:pk>/", v.document_detail, name="document_detail"),
    path("documents/<int:pk>/upload/", v.document_upload, name="document_upload"),
    path("documents/<int:pk>/digitized/", v.document_digitized, name="document_digitized"),
    path("documents/<int:pk>/metadata/", v.document_metadata, name="document_metadata"),
    path("documents/<int:pk>/submit/", v.document_submit, name="document_submit"),
    path("documents/<int:pk>/decide/", v.document_decide, name="document_decide"),
    path("documents/<int:pk>/request-access/", v.access_request, name="access_request"),
    path("documents/<int:pk>/retention-review/", v.retention_review, name="retention_review"),
    path("documents/<int:pk>/request-disposal/", v.disposal_request, name="disposal_request"),
    path("files/<int:pk>/", v.file_download, name="file_download"),
    path("files/<int:pk>/remove/", v.file_remove, name="file_remove"),
    path("files/<int:pk>/view/", v.file_view, name="file_view"),
    path("files/<int:pk>/page/<int:page>.png", v.file_png, name="file_png"),
    path("files/<int:pk>/edit/", v.file_edit, name="file_edit"),
    path("files/<int:pk>/new-version/", v.file_new_version, name="file_new_version"),
    path("files/<int:pk>/version-decide/", v.version_decide, name="version_decide"),
    # bulk upload
    path("bulk-upload/", bv.bulk_upload, name="bulk_upload"),
    path("bulk-upload/template.xlsx", bv.bulk_template, name="bulk_template"),
    path("bulk-upload/sample.zip", bv.bulk_sample, name="bulk_sample"),
    path("bulk-upload/<int:pk>/", bv.bulk_detail, name="bulk_detail"),
    path("bulk-upload/<int:pk>/start/", bv.bulk_start, name="bulk_start"),
    path("bulk-upload/<int:pk>/status/", bv.bulk_status, name="bulk_status"),
    path("approvals/approve-selected/", bv.approve_selected, name="approve_selected"),
    # invoice register & statistics
    path("invoices/", iv.register, name="invoices"),
    path("invoices/export.<str:fmt>", iv.export, name="invoice_export"),
    path("invoices/save/", iv.save_edits, name="invoice_save"),
    path("invoices/import/", iv.import_index, name="invoice_import"),
    path("invoices/new/", iv.invoice_edit, name="invoice_new"),
    path("invoices/<int:pk>/edit/", iv.invoice_edit, name="invoice_edit"),
    path("documents/<int:doc_pk>/invoice/", iv.invoice_edit, name="invoice_for_doc"),
    # queues
    path("approvals/", v.approvals, name="approvals"),
    path("access-requests/", v.access_requests, name="access_requests"),
    path("access-requests/<int:pk>/decide/", v.access_decide, name="access_decide"),
    path("retention/", v.retention, name="retention"),
    path("retention/run/", v.run_daily, name="run_daily"),
    path("disposals/", v.disposals, name="disposals"),
    path("disposals/<int:pk>/decide/", v.disposal_decide, name="disposal_decide"),
    path("disposals/<int:pk>/certificate/", v.disposal_certificate, name="disposal_certificate"),
    # audit & reports
    path("audit/", v.audit_log, name="audit_log"),
    path("reports/", v.reports, name="reports"),
    # user
    path("notifications/", v.notifications, name="notifications"),
    path("notifications/<int:pk>/", v.notification_open, name="notification_open"),
    path("profile/", v.profile, name="profile"),
    path("help/", v.help_page, name="help"),
    # admin
    path("admin/users/", v.users, name="users"),
    path("admin/users/new/", v.user_edit, name="user_new"),
    path("admin/users/<int:pk>/", v.user_edit, name="user_edit"),
    path("admin/categories/", v.categories, name="categories"),
    path("admin/categories/new/", v.category_edit, name="category_new"),
    path("admin/categories/<int:pk>/", v.category_edit, name="category_edit"),
    path("admin/departments/new/", v.department_edit, name="department_new"),
    path("admin/departments/<int:pk>/", v.department_edit, name="department_edit"),
    path("admin/settings/", v.site_settings, name="site_settings"),
    path("backups/", v.backups, name="backups"),
    path("admin/backup/", v.backup_now, name="backup_now"),
    path("admin/update/check/", v.update_check, name="update_check"),
    path("admin/update/install/", v.update_install, name="update_install"),
    path("admin/update/upload/", v.update_upload, name="update_upload"),
    path("admin/update/cancel/", v.update_cancel, name="update_cancel"),
    path("update-status/", v.update_status, name="update_status"),
    path("admin/backup/<str:name>", v.backup_download, name="backup_download"),
]
