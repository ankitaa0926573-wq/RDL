from django import forms
from django.contrib.auth.forms import SetPasswordForm
from django.utils import timezone

from .models import (
    Category,
    Confidentiality,
    Department,
    DisposalRecord,
    Document,
    RetentionReview,
    Role,
    SiteSettings,
    User,
)


class BootstrapMixin:
    def _bootstrap(self):
        for name, field in self.fields.items():
            w = field.widget
            if isinstance(w, (forms.CheckboxInput,)):
                w.attrs.setdefault("class", "form-check-input")
            elif isinstance(w, (forms.Select, forms.SelectMultiple)):
                w.attrs.setdefault("class", "form-select")
            else:
                w.attrs.setdefault("class", "form-control")


class DateInput(forms.DateInput):
    input_type = "date"

    def __init__(self, **kw):
        super().__init__(format="%Y-%m-%d", **kw)


# ---------------------------------------------------------------- Phase 1
class ReceiptForm(BootstrapMixin, forms.ModelForm):
    class Meta:
        model = Document
        fields = [
            "title", "category", "department", "source_type", "received_from", "received_date",
            "reference_number", "physical_location", "custodian", "confidentiality",
        ]
        widgets = {"received_date": DateInput()}

    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self.fields["category"].queryset = Category.objects.filter(is_active=True)
        self.fields["custodian"].queryset = User.objects.filter(is_active=True).order_by("first_name", "username")
        self.fields["custodian"].required = False
        self.fields["custodian"].help_text = "Leave blank to make yourself the custodian"
        self.fields["confidentiality"].required = False
        self._bootstrap()

    def clean_received_date(self):
        d = self.cleaned_data["received_date"]
        if d and d > timezone.localdate():
            raise forms.ValidationError("Received date cannot be in the future.")
        return d

    def clean(self):
        data = super().clean()
        if not data.get("confidentiality") and data.get("category"):
            data["confidentiality"] = data["category"].default_confidentiality
        return data


# ---------------------------------------------------------------- Phase 2
class MultipleFileInput(forms.ClearableFileInput):
    allow_multiple_selected = True


class MultipleFileField(forms.FileField):
    def __init__(self, *a, **kw):
        kw.setdefault("widget", MultipleFileInput(attrs={"class": "form-control", "multiple": True}))
        super().__init__(*a, **kw)

    def clean(self, data, initial=None):
        single = super().clean
        if isinstance(data, (list, tuple)):
            return [single(d, initial) for d in data]
        return [single(data, initial)] if data else []


class UploadForm(forms.Form):
    files = MultipleFileField(
        label="Select scanned or digital files",
        help_text="PDF, Word, Excel, images (JPG/PNG/TIFF) and more. Several files can be selected at once.",
    )


# ---------------------------------------------------------------- Phase 3
RETENTION_FIELDS = ("retention_years", "permanent", "expiry_date")


class MetadataForm(BootstrapMixin, forms.ModelForm):
    class Meta:
        model = Document
        fields = [
            "title", "category", "department", "description", "creator", "keywords", "document_year",
            "document_date", "reference_number", "received_from", "amount", "language", "custodian",
            "physical_location", "confidentiality", "retention_years", "permanent", "expiry_date",
        ]
        widgets = {
            "description": forms.Textarea(attrs={"rows": 3}),
            "document_date": DateInput(),
            "expiry_date": DateInput(),
        }

    def __init__(self, *a, user=None, **kw):
        super().__init__(*a, **kw)
        if user is not None and not user.can_approve:
            # retention is decided by the Super Librarian / Administrator at approval (Phase 4)
            for name in RETENTION_FIELDS:
                self.fields.pop(name, None)
        self.fields["category"].queryset = Category.objects.filter(is_active=True)
        self.fields["custodian"].queryset = User.objects.filter(is_active=True)
        self.fields["description"].required = True
        self.fields["document_year"].required = True
        if "retention_years" in self.fields:
            self.fields["retention_years"].help_text = "Blank = use category default. Expiry date is calculated automatically."
            self.fields["expiry_date"].help_text = "Calculated from retention period; change only if a different date is required."
        self._bootstrap()


# ---------------------------------------------------------------- Phase 4
class DecisionForm(forms.Form):
    retention = forms.CharField(required=False)
    retention_until = forms.DateField(required=False)
    remarks = forms.CharField(
        required=False, widget=forms.Textarea(attrs={"rows": 2, "class": "form-control"}),
        label="Remarks",
    )


# ---------------------------------------------------------------- Phase 5
class AccessRequestForm(forms.Form):
    purpose = forms.CharField(
        widget=forms.Textarea(attrs={"rows": 2, "class": "form-control"}),
        label="Purpose of access", help_text="e.g. Required for NAAC SSR criterion 4 audit",
    )


class SearchForm(BootstrapMixin, forms.Form):
    q = forms.CharField(required=False, label="Search", widget=forms.TextInput(attrs={"placeholder": "Title, ID, keyword, text inside documents..."}))
    category = forms.ModelChoiceField(Category.objects.all(), required=False, empty_label="All categories")
    department = forms.ModelChoiceField(Department.objects.all(), required=False, empty_label="All departments")
    status = forms.ChoiceField(required=False)
    year = forms.CharField(required=False, label="Year", widget=forms.TextInput(attrs={"placeholder": "e.g. 2025-26"}))
    date_from = forms.DateField(required=False, widget=DateInput(), label="Received from")
    date_to = forms.DateField(required=False, widget=DateInput(), label="to")

    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        from .models import Status

        self.fields["status"].choices = [("", "Any status"), ("WORKFLOW", "In workflow (phases 1-4)")] + list(Status.choices)
        self._bootstrap()


# ---------------------------------------------------------------- Phase 6
class RetentionReviewForm(BootstrapMixin, forms.Form):
    decision = forms.ChoiceField(choices=RetentionReview.Decision.choices, widget=forms.RadioSelect)
    new_expiry = forms.DateField(required=False, widget=DateInput(), label="New expiry date (if retaining)")
    remarks = forms.CharField(widget=forms.Textarea(attrs={"rows": 2}), required=False)

    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self._bootstrap()
        self.fields["decision"].widget.attrs["class"] = "form-check-input"


# ---------------------------------------------------------------- Phase 7
class DisposalRequestForm(BootstrapMixin, forms.ModelForm):
    class Meta:
        model = DisposalRecord
        fields = ["method", "reason", "authority_reference"]
        widgets = {"reason": forms.Textarea(attrs={"rows": 3})}

    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self._bootstrap()


# ---------------------------------------------------------------- Admin
class UserForm(BootstrapMixin, forms.ModelForm):
    password = forms.CharField(
        widget=forms.PasswordInput, required=False,
        help_text="Required for a new user. Leave blank to keep the current password.",
    )

    class Meta:
        model = User
        fields = ["username", "first_name", "last_name", "email", "phone", "designation", "role", "department",
                  "can_backup", "is_active"]

    def __init__(self, *a, editor=None, **kw):
        super().__init__(*a, **kw)
        if editor is not None and not editor.is_admin_role:
            # a Super Librarian manages library staff accounts, not administrators / super librarians
            self.fields["role"].choices = [c for c in Role.choices if c[0] not in (Role.ADMIN, Role.SUPER_LIBRARIAN)]
        self._bootstrap()

    def clean(self):
        data = super().clean()
        if not self.instance.pk and not data.get("password"):
            self.add_error("password", "Password is required for a new user.")
        pw = data.get("password")
        if pw:
            from django.contrib.auth.password_validation import validate_password

            try:
                validate_password(pw, self.instance)
            except forms.ValidationError as e:
                self.add_error("password", e)
        return data

    def save(self, commit=True):
        user = super().save(commit=False)
        if self.cleaned_data.get("password"):
            user.set_password(self.cleaned_data["password"])
        if commit:
            user.save()
        return user


class CategoryForm(BootstrapMixin, forms.ModelForm):
    default_confidentiality = forms.ChoiceField(choices=Confidentiality.choices)

    class Meta:
        model = Category
        fields = ["name", "code", "description", "retention_years", "default_confidentiality", "is_active"]
        widgets = {"description": forms.Textarea(attrs={"rows": 2})}

    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self._bootstrap()


class DepartmentForm(BootstrapMixin, forms.ModelForm):
    class Meta:
        model = Department
        fields = ["name", "code"]

    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self._bootstrap()


class SiteSettingsForm(BootstrapMixin, forms.ModelForm):
    class Meta:
        model = SiteSettings
        fields = [
            "library_name", "institution_name", "address", "id_prefix", "alert_days_before_expiry",
            "access_grant_days", "backup_hour", "backups_to_keep", "update_check_enabled", "update_url",
        ]
        widgets = {"address": forms.Textarea(attrs={"rows": 2})}

    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self._bootstrap()


class SetupForm(BootstrapMixin, forms.Form):
    library_name = forms.CharField(max_length=200, initial="Central Library")
    institution_name = forms.CharField(max_length=250, required=False)
    id_prefix = forms.CharField(max_length=10, initial="LDR")
    admin_username = forms.CharField(max_length=150, initial="admin")
    admin_full_name = forms.CharField(max_length=150)
    admin_email = forms.EmailField(required=False)
    password1 = forms.CharField(widget=forms.PasswordInput, label="Password")
    password2 = forms.CharField(widget=forms.PasswordInput, label="Confirm password")
    load_defaults = forms.BooleanField(
        required=False, initial=True, label="Load standard library document categories (invoices, NAAC, minutes...)"
    )

    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self._bootstrap()

    def clean(self):
        d = super().clean()
        if d.get("password1") != d.get("password2"):
            self.add_error("password2", "Passwords do not match.")
        elif d.get("password1"):
            from django.contrib.auth.password_validation import validate_password

            try:
                validate_password(d["password1"])
            except forms.ValidationError as e:
                self.add_error("password1", e)
        return d


class OwnPasswordForm(SetPasswordForm):
    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        for f in self.fields.values():
            f.widget.attrs["class"] = "form-control"
