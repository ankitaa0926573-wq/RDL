"""
Data model for the Library Document Repository (LDR).

The seven phases of the LDR framework map onto ``Document.status``:

  1. Document Creation / Receipt  -> RECEIVED
  2. Digitization                 -> DIGITIZED
  3. Metadata Assignment          -> METADATA_DONE
  4. Validation & Approval        -> PENDING_APPROVAL / RETURNED
  5. Active Access Phase          -> ACTIVE
  6. Retention Monitoring         -> ACTIVE (+ UNDER_REVIEW when expired)
  7. Secure Disposal              -> DISPOSAL_REQUESTED -> DISPOSED
"""
import hashlib
import json
import uuid
from datetime import date

from django.conf import settings
from django.contrib.auth.models import AbstractUser
from django.core.exceptions import PermissionDenied
from django.db import models, transaction
from django.urls import reverse
from django.utils import timezone


# --------------------------------------------------------------------------
# Users and roles
# --------------------------------------------------------------------------
class Role(models.TextChoices):
    ADMIN = "ADMIN", "System Administrator"
    SUPER_LIBRARIAN = "SUPER", "Super Librarian"
    CATALOGUER = "CATALOGUER", "Cataloguer / Librarian"
    TECHNICAL = "TECHNICAL", "Technical Staff"
    LIBRARY_STAFF = "STAFF", "Library Staff"
    AUTHORIZED = "AUTHORIZED", "Authorized Staff (view only)"


class Department(models.Model):
    name = models.CharField(max_length=150, unique=True)
    code = models.CharField(max_length=20, blank=True)

    class Meta:
        ordering = ["name"]

    def __str__(self):
        return self.name


class User(AbstractUser):
    role = models.CharField(max_length=20, choices=Role.choices, default=Role.LIBRARY_STAFF)
    department = models.ForeignKey(Department, null=True, blank=True, on_delete=models.SET_NULL)
    designation = models.CharField(max_length=120, blank=True)
    phone = models.CharField(max_length=30, blank=True)
    can_backup = models.BooleanField(
        "Allow this person to take backups", default=False,
        help_text="Lets this staff member create and download full backups (database + all documents).",
    )

    # ---- permission helpers (used by views and templates) ----
    @property
    def is_admin_role(self):
        return self.role == Role.ADMIN or self.is_superuser

    @property
    def is_super_librarian(self):
        return self.role == Role.SUPER_LIBRARIAN or self.is_admin_role

    @property
    def may_backup(self):
        return self.is_admin_role or self.can_backup

    @property
    def can_manage_users(self):
        return self.is_super_librarian

    @property
    def can_register(self):
        return self.role in (Role.ADMIN, Role.SUPER_LIBRARIAN, Role.CATALOGUER, Role.TECHNICAL, Role.LIBRARY_STAFF)

    @property
    def can_digitize(self):
        # Phase 2 - every working library staff role (not the view-only role)
        return self.role in (Role.ADMIN, Role.SUPER_LIBRARIAN, Role.CATALOGUER, Role.TECHNICAL, Role.LIBRARY_STAFF)

    @property
    def can_catalogue(self):
        # Phase 3 metadata + submitting for approval - every working library staff role
        return self.role in (Role.ADMIN, Role.SUPER_LIBRARIAN, Role.CATALOGUER, Role.TECHNICAL, Role.LIBRARY_STAFF)

    @property
    def can_request_disposal(self):
        return self.role in (Role.ADMIN, Role.SUPER_LIBRARIAN, Role.CATALOGUER)

    @property
    def can_approve(self):
        return self.is_super_librarian

    @property
    def can_manage_retention(self):
        return self.is_super_librarian

    @property
    def can_view_audit(self):
        return self.is_super_librarian

    def display_name(self):
        return self.get_full_name() or self.username

    def __str__(self):
        return self.display_name()


# --------------------------------------------------------------------------
# Site settings (singleton)
# --------------------------------------------------------------------------
class SiteSettings(models.Model):
    library_name = models.CharField(max_length=200, default="Central Library")
    institution_name = models.CharField(max_length=250, blank=True)
    address = models.TextField(blank=True)
    id_prefix = models.CharField(
        "ID prefix", max_length=10, default="LDR", help_text="Prefix used for document IDs, e.g. LDR-2026-00001"
    )
    alert_days_before_expiry = models.PositiveIntegerField(default=60)
    backup_hour = models.PositiveSmallIntegerField(default=1, help_text="Hour of day (0-23) for the automatic backup")
    backups_to_keep = models.PositiveSmallIntegerField(default=14)
    access_grant_days = models.PositiveSmallIntegerField(
        default=7, help_text="How many days an approved access request to a confidential document stays valid"
    )
    setup_completed = models.BooleanField(default=False)
    # software updates
    update_url = models.CharField(
        "Update address", max_length=400, blank=True,
        help_text="Address of latest.json on the LDR website. Leave blank to use the built-in address.",
    )
    update_check_enabled = models.BooleanField("Check for updates daily", default=True)
    update_latest_version = models.CharField(max_length=30, blank=True)
    update_latest_info = models.TextField(blank=True)
    update_last_check = models.DateTimeField(null=True, blank=True)
    update_check_error = models.CharField(max_length=400, blank=True)
    last_daily_run = models.DateTimeField(null=True, blank=True)
    last_backup = models.DateTimeField(null=True, blank=True)

    class Meta:
        verbose_name_plural = "Site settings"

    def save(self, *args, **kwargs):
        self.pk = 1
        super().save(*args, **kwargs)

    @classmethod
    def load(cls):
        obj, _ = cls.objects.get_or_create(pk=1)
        return obj

    def __str__(self):
        return self.library_name


# --------------------------------------------------------------------------
# Categories (with retention schedule)
# --------------------------------------------------------------------------
class Category(models.Model):
    name = models.CharField(max_length=150, unique=True)
    code = models.CharField(max_length=20, unique=True, help_text="Short code, e.g. INV, AGR, NAAC")
    description = models.TextField(blank=True)
    retention_years = models.PositiveSmallIntegerField(
        default=5, help_text="Default retention period in years (0 = permanent)"
    )
    default_confidentiality = models.CharField(max_length=20, default="GENERAL")
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["name"]
        verbose_name_plural = "Categories"

    def __str__(self):
        return f"{self.name} ({self.code})"


# --------------------------------------------------------------------------
# Documents
# --------------------------------------------------------------------------
class Status(models.TextChoices):
    RECEIVED = "RECEIVED", "1. Received"
    DIGITIZED = "DIGITIZED", "2. Digitized"
    METADATA_DONE = "METADATA_DONE", "3. Metadata assigned"
    PENDING_APPROVAL = "PENDING_APPROVAL", "4. Awaiting approval"
    RETURNED = "RETURNED", "4. Returned for correction"
    ACTIVE = "ACTIVE", "5. Active (approved)"
    UNDER_REVIEW = "UNDER_REVIEW", "6. Retention review due"
    DISPOSAL_REQUESTED = "DISPOSAL_REQUESTED", "7. Disposal requested"
    DISPOSED = "DISPOSED", "7. Disposed"


PHASE_OF_STATUS = {
    Status.RECEIVED: 1,
    Status.DIGITIZED: 2,
    Status.METADATA_DONE: 3,
    Status.PENDING_APPROVAL: 4,
    Status.RETURNED: 4,
    Status.ACTIVE: 5,
    Status.UNDER_REVIEW: 6,
    Status.DISPOSAL_REQUESTED: 7,
    Status.DISPOSED: 7,
}

PHASE_NAMES = [
    (1, "Creation / Receipt"),
    (2, "Digitization"),
    (3, "Metadata"),
    (4, "Validation & Approval"),
    (5, "Active Access"),
    (6, "Retention Monitoring"),
    (7, "Secure Disposal"),
]


class Confidentiality(models.TextChoices):
    GENERAL = "GENERAL", "Open - all library staff"
    DEPARTMENT = "DEPARTMENT", "Department only"
    CONFIDENTIAL = "CONFIDENTIAL", "Permission required - Super Librarian must allow"


class SourceType(models.TextChoices):
    PHYSICAL = "PHYSICAL", "Physical (hard copy)"
    BORN_DIGITAL = "DIGITAL", "Born digital (email, file)"


class Document(models.Model):
    uid = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    doc_id = models.CharField("Document ID", max_length=40, unique=True, editable=False)

    # Phase 1: receipt
    title = models.CharField(max_length=300)
    category = models.ForeignKey(Category, on_delete=models.PROTECT)
    department = models.ForeignKey(Department, null=True, blank=True, on_delete=models.SET_NULL)
    source_type = models.CharField(max_length=10, choices=SourceType.choices, default=SourceType.PHYSICAL)
    received_from = models.CharField(
        "Received from / Originator", max_length=250, blank=True,
        help_text="Vendor, office, authority or person the document came from",
    )
    received_date = models.DateField(default=date.today)
    reference_number = models.CharField(max_length=120, blank=True, help_text="Invoice no., letter no., order no.")
    physical_location = models.CharField(
        max_length=200, blank=True, help_text="Where the hard copy is kept (cabinet / file / rack)"
    )
    custodian = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="custodian_of",
        help_text="Staff member responsible for this document",
    )

    # Phase 3: metadata (Dublin Core aligned)
    description = models.TextField(blank=True)
    creator = models.CharField("Author / Creator", max_length=250, blank=True)
    keywords = models.CharField("Subject keywords", max_length=400, blank=True, help_text="Comma separated")
    document_year = models.CharField(
        "Year / Period", max_length=20, blank=True, help_text="e.g. 2025 or 2025-26 (academic/financial year)"
    )
    document_date = models.DateField(null=True, blank=True, help_text="Date written on the document")
    language = models.CharField(max_length=40, default="English")
    amount = models.DecimalField(
        max_digits=14, decimal_places=2, null=True, blank=True, help_text="Amount (for invoices/bills), optional"
    )
    confidentiality = models.CharField(
        max_length=20, choices=Confidentiality.choices, default=Confidentiality.GENERAL
    )
    retention_years = models.PositiveSmallIntegerField(null=True, blank=True)
    expiry_date = models.DateField(null=True, blank=True, help_text="Leave blank for permanent retention")
    permanent = models.BooleanField(default=False)

    # Workflow
    status = models.CharField(max_length=30, choices=Status.choices, default=Status.RECEIVED)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="documents_created"
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    digitized_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="+"
    )
    digitized_at = models.DateTimeField(null=True, blank=True)
    catalogued_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="+"
    )
    catalogued_at = models.DateTimeField(null=True, blank=True)
    submitted_at = models.DateTimeField(null=True, blank=True)
    approved_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="+"
    )
    approved_at = models.DateTimeField(null=True, blank=True)
    approval_remarks = models.TextField(blank=True)
    last_reviewed_at = models.DateTimeField(null=True, blank=True)

    extracted_text = models.TextField(blank=True, editable=False)

    class Meta:
        ordering = ["-created_at"]
        indexes = [
            models.Index(fields=["status"]),
            models.Index(fields=["expiry_date"]),
            models.Index(fields=["document_year"]),
        ]

    def __str__(self):
        return f"{self.doc_id} - {self.title}"

    def get_absolute_url(self):
        return reverse("document_detail", args=[self.pk])

    # ---- helpers ----
    @property
    def phase(self):
        return PHASE_OF_STATUS.get(self.status, 1)

    @property
    def is_disposed(self):
        return self.status == Status.DISPOSED

    @property
    def is_official(self):
        return self.status in (Status.ACTIVE, Status.UNDER_REVIEW, Status.DISPOSAL_REQUESTED)

    @property
    def is_editable(self):
        return self.status in (Status.RECEIVED, Status.DIGITIZED, Status.METADATA_DONE, Status.RETURNED)

    @property
    def days_to_expiry(self):
        if not self.expiry_date or self.permanent:
            return None
        return (self.expiry_date - timezone.localdate()).days

    @property
    def keyword_list(self):
        return [k.strip() for k in self.keywords.split(",") if k.strip()]

    def compute_expiry(self):
        """Expiry = received date + retention years (category default if not set)."""
        years = self.retention_years if self.retention_years is not None else self.category.retention_years
        if self.permanent or years == 0:
            self.permanent = True
            self.expiry_date = None
            return
        base = self.document_date or self.received_date or timezone.localdate()
        try:
            self.expiry_date = base.replace(year=base.year + years)
        except ValueError:  # 29 Feb
            self.expiry_date = base.replace(year=base.year + years, day=28)

    @staticmethod
    def next_doc_id(prefix):
        year = timezone.localdate().year
        stem = f"{prefix}-{year}-"
        last = (
            Document.objects.filter(doc_id__startswith=stem).order_by("-doc_id").values_list("doc_id", flat=True).first()
        )
        n = int(last.rsplit("-", 1)[1]) + 1 if last else 1
        return f"{stem}{n:05d}"

    def save(self, *args, **kwargs):
        if not self.doc_id:
            with transaction.atomic():
                self.doc_id = Document.next_doc_id(SiteSettings.load().id_prefix)
                return super().save(*args, **kwargs)
        return super().save(*args, **kwargs)


def document_upload_path(instance, filename):
    d = instance.document
    return f"{d.created_at:%Y}/{d.doc_id}/{uuid.uuid4().hex[:8]}_{filename}"


class FileRole(models.TextChoices):
    MASTER = "MASTER", "Preservation master (original)"
    ACCESS = "ACCESS", "Access copy (searchable PDF)"


class DocumentFile(models.Model):
    document = models.ForeignKey(Document, on_delete=models.CASCADE, related_name="files")
    file = models.FileField(upload_to=document_upload_path, max_length=500, null=True, blank=True)
    role = models.CharField(max_length=10, choices=FileRole.choices, default=FileRole.MASTER)
    derived_from = models.ForeignKey("self", null=True, blank=True, on_delete=models.SET_NULL)
    original_name = models.CharField(max_length=300)
    mime_type = models.CharField(max_length=120, blank=True)
    size = models.BigIntegerField(default=0)
    sha256 = models.CharField(max_length=64, editable=False)
    pages = models.PositiveIntegerField(null=True, blank=True)
    extracted_text = models.TextField(blank=True, editable=False)
    ocr_applied = models.BooleanField(default=False)
    uploaded_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT)
    uploaded_at = models.DateTimeField(auto_now_add=True)
    last_fixity_check = models.DateTimeField(null=True, blank=True)
    fixity_ok = models.BooleanField(default=True)
    purged = models.BooleanField(default=False, help_text="File content destroyed during secure disposal")

    # ---- versioning ----
    version = models.PositiveIntegerField(default=1)
    previous = models.ForeignKey(
        "self", null=True, blank=True, on_delete=models.SET_NULL, related_name="next_versions",
        help_text="The version this file replaces",
    )
    is_current = models.BooleanField(default=True, db_index=True)
    pending_approval = models.BooleanField(default=False, help_text="New version of an approved record awaiting approval")
    change_note = models.CharField(max_length=400, blank=True)
    version_decided_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="+"
    )
    version_decided_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["role", "uploaded_at"]

    # ---- viewer / editor capabilities ----
    VIEW_KINDS = {
        "pdf": "pdf",
        "jpg": "image", "jpeg": "image", "png": "image", "gif": "image", "webp": "image", "bmp": "image",
        "tif": "image", "tiff": "image",
        "xlsx": "sheet", "xlsm": "sheet", "xls": "sheet", "csv": "sheet",
        "docx": "word",
        "txt": "text", "md": "text", "json": "text", "xml": "text", "html": "text", "htm": "text", "log": "text",
        "eml": "email",
    }
    EDIT_KINDS = {"xlsx": "sheet", "xlsm": "sheet", "csv": "sheet", "docx": "word", "txt": "text", "md": "text",
                  "json": "text", "xml": "text"}

    @property
    def view_kind(self):
        return self.VIEW_KINDS.get(self.extension)

    @property
    def edit_kind(self):
        return self.EDIT_KINDS.get(self.extension)

    def version_chain(self):
        """All versions of this file, newest first (walks back through ``previous``)."""
        chain, f, seen = [], self, set()
        while f is not None and f.pk not in seen:
            chain.append(f)
            seen.add(f.pk)
            f = f.previous
        return chain

    def __str__(self):
        return self.original_name

    @property
    def extension(self):
        return self.original_name.rsplit(".", 1)[-1].lower() if "." in self.original_name else ""

    @property
    def icon(self):
        ext = self.extension
        return {
            "pdf": "bi-file-earmark-pdf",
            "doc": "bi-file-earmark-word", "docx": "bi-file-earmark-word", "odt": "bi-file-earmark-word",
            "xls": "bi-file-earmark-excel", "xlsx": "bi-file-earmark-excel", "csv": "bi-file-earmark-spreadsheet",
            "ods": "bi-file-earmark-excel",
            "jpg": "bi-file-earmark-image", "jpeg": "bi-file-earmark-image", "png": "bi-file-earmark-image",
            "tif": "bi-file-earmark-image", "tiff": "bi-file-earmark-image", "bmp": "bi-file-earmark-image",
            "ppt": "bi-file-earmark-slides", "pptx": "bi-file-earmark-slides",
            "txt": "bi-file-earmark-text", "zip": "bi-file-earmark-zip",
        }.get(ext, "bi-file-earmark")

    @property
    def can_preview_inline(self):
        return self.extension in ("pdf", "jpg", "jpeg", "png", "gif", "txt")

    @staticmethod
    def hash_file(django_file):
        h = hashlib.sha256()
        django_file.seek(0)
        for chunk in django_file.chunks() if hasattr(django_file, "chunks") else iter(lambda: django_file.read(1 << 20), b""):
            h.update(chunk)
        django_file.seek(0)
        return h.hexdigest()

    def verify_fixity(self):
        if self.purged or not self.file:
            return True
        try:
            h = hashlib.sha256()
            with self.file.open("rb") as fh:
                for chunk in iter(lambda: fh.read(1 << 20), b""):
                    h.update(chunk)
            ok = h.hexdigest() == self.sha256
        except (FileNotFoundError, OSError):
            ok = False
        self.fixity_ok = ok
        self.last_fixity_check = timezone.now()
        self.save(update_fields=["fixity_ok", "last_fixity_check"])
        return ok


# --------------------------------------------------------------------------
# Audit trail (append only, hash chained so tampering is detectable)
# --------------------------------------------------------------------------
class AuditLog(models.Model):
    timestamp = models.DateTimeField(default=timezone.now, db_index=True)
    user = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL)
    username = models.CharField(max_length=150, blank=True)
    action = models.CharField(max_length=40, db_index=True)
    document = models.ForeignKey(Document, null=True, blank=True, on_delete=models.SET_NULL, related_name="audit")
    doc_ref = models.CharField(max_length=40, blank=True, db_index=True)
    details = models.TextField(blank=True)
    ip_address = models.GenericIPAddressField(null=True, blank=True)
    prev_hash = models.CharField(max_length=64, blank=True)
    entry_hash = models.CharField(max_length=64, blank=True)

    class Meta:
        ordering = ["-timestamp", "-id"]

    def __str__(self):
        return f"{self.timestamp:%Y-%m-%d %H:%M} {self.username} {self.action} {self.doc_ref}"

    def compute_hash(self):
        payload = json.dumps(
            [
                self.prev_hash,
                self.timestamp.isoformat(),
                self.username,
                self.action,
                self.doc_ref,
                self.details,
                self.ip_address or "",
            ],
            ensure_ascii=False,
        )
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()

    def save(self, *args, **kwargs):
        if self.pk:
            raise PermissionDenied("Audit log entries cannot be modified.")
        with transaction.atomic():
            last = AuditLog.objects.order_by("-id").values_list("entry_hash", flat=True).first()
            self.prev_hash = last or "0" * 64
            self.entry_hash = self.compute_hash()
            super().save(*args, **kwargs)

    def delete(self, *args, **kwargs):
        raise PermissionDenied("Audit log entries cannot be deleted.")


class Action:
    LOGIN = "LOGIN"
    LOGOUT = "LOGOUT"
    LOGIN_FAILED = "LOGIN_FAILED"
    REGISTERED = "REGISTERED"
    FILE_UPLOADED = "FILE_UPLOADED"
    FILE_REMOVED = "FILE_REMOVED"
    OCR = "OCR"
    DIGITIZED = "DIGITIZED"
    METADATA = "METADATA_UPDATED"
    SUBMITTED = "SUBMITTED"
    APPROVED = "APPROVED"
    RETURNED = "RETURNED"
    VIEWED = "VIEWED"
    DOWNLOADED = "DOWNLOADED"
    ACCESS_DENIED = "ACCESS_DENIED"
    ACCESS_REQUESTED = "ACCESS_REQUESTED"
    ACCESS_GRANTED = "ACCESS_GRANTED"
    ACCESS_REJECTED = "ACCESS_REJECTED"
    RETENTION_ALERT = "RETENTION_ALERT"
    RETENTION_REVIEW = "RETENTION_REVIEW"
    DISPOSAL_REQUESTED = "DISPOSAL_REQUESTED"
    DISPOSAL_APPROVED = "DISPOSAL_APPROVED"
    DISPOSAL_REJECTED = "DISPOSAL_REJECTED"
    DISPOSED = "DISPOSED"
    FIXITY_OK = "FIXITY_OK"
    FIXITY_FAILED = "FIXITY_FAILED"
    BACKUP = "BACKUP"
    BULK_IMPORT = "BULK_IMPORT"
    INVOICE_CHANGE = "INVOICE_CHANGE"
    USER_CHANGE = "USER_CHANGE"
    SETTINGS = "SETTINGS"
    VERSION_CREATED = "VERSION_CREATED"
    VERSION_SUBMITTED = "VERSION_SUBMITTED"
    VERSION_APPROVED = "VERSION_APPROVED"
    VERSION_REJECTED = "VERSION_REJECTED"
    UPDATE_AVAILABLE = "UPDATE_AVAILABLE"
    UPDATE_STARTED = "UPDATE_STARTED"
    UPDATE_APPLIED = "UPDATE_APPLIED"
    UPDATE_FAILED = "UPDATE_FAILED"


# --------------------------------------------------------------------------
# Access requests for confidential documents (Phase 5)
# --------------------------------------------------------------------------
class AccessRequest(models.Model):
    class State(models.TextChoices):
        PENDING = "PENDING", "Pending"
        APPROVED = "APPROVED", "Approved"
        REJECTED = "REJECTED", "Rejected"

    document = models.ForeignKey(Document, on_delete=models.CASCADE, related_name="access_requests")
    requested_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="access_requests")
    purpose = models.TextField()
    requested_at = models.DateTimeField(auto_now_add=True)
    state = models.CharField(max_length=10, choices=State.choices, default=State.PENDING)
    decided_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="+"
    )
    decided_at = models.DateTimeField(null=True, blank=True)
    valid_until = models.DateTimeField(null=True, blank=True)
    remarks = models.CharField(max_length=300, blank=True)

    class Meta:
        ordering = ["-requested_at"]

    @property
    def is_valid(self):
        return self.state == self.State.APPROVED and self.valid_until and self.valid_until >= timezone.now()


# --------------------------------------------------------------------------
# Retention reviews (Phase 6)
# --------------------------------------------------------------------------
class RetentionReview(models.Model):
    class Decision(models.TextChoices):
        RETAIN = "RETAIN", "Retain - extend retention"
        PERMANENT = "PERMANENT", "Retain permanently"
        DISPOSE = "DISPOSE", "Recommend for disposal"

    document = models.ForeignKey(Document, on_delete=models.CASCADE, related_name="reviews")
    reviewed_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT)
    reviewed_at = models.DateTimeField(auto_now_add=True)
    decision = models.CharField(max_length=10, choices=Decision.choices)
    previous_expiry = models.DateField(null=True, blank=True)
    new_expiry = models.DateField(null=True, blank=True)
    remarks = models.TextField(blank=True)

    class Meta:
        ordering = ["-reviewed_at"]


# --------------------------------------------------------------------------
# Disposal (Phase 7)
# --------------------------------------------------------------------------
class DisposalRecord(models.Model):
    class Method(models.TextChoices):
        DIGITAL_DELETE = "DELETE", "Secure deletion of digital files"
        DELETE_AND_SHRED = "SHRED", "Secure deletion + shredding of hard copy"
        TRANSFER = "TRANSFER", "Transfer to institutional archive / authority"

    class State(models.TextChoices):
        REQUESTED = "REQUESTED", "Requested"
        APPROVED = "APPROVED", "Approved & executed"
        REJECTED = "REJECTED", "Rejected"

    document = models.ForeignKey(Document, on_delete=models.PROTECT, related_name="disposals")
    reason = models.TextField()
    method = models.CharField(max_length=10, choices=Method.choices, default=Method.DIGITAL_DELETE)
    authority_reference = models.CharField(
        max_length=200, blank=True, help_text="Committee resolution / order number authorising disposal"
    )
    requested_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="+")
    requested_at = models.DateTimeField(auto_now_add=True)
    state = models.CharField(max_length=10, choices=State.choices, default=State.REQUESTED)
    decided_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.PROTECT, related_name="+"
    )
    decided_at = models.DateTimeField(null=True, blank=True)
    decision_remarks = models.TextField(blank=True)
    file_manifest = models.TextField(blank=True, help_text="JSON list of destroyed files with SHA-256 checksums")
    certificate_number = models.CharField(max_length=40, blank=True)

    class Meta:
        ordering = ["-requested_at"]

    def manifest(self):
        try:
            return json.loads(self.file_manifest or "[]")
        except ValueError:
            return []


# --------------------------------------------------------------------------
# In-app notifications
# --------------------------------------------------------------------------
class Notification(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="notifications")
    message = models.CharField(max_length=400)
    link = models.CharField(max_length=300, blank=True)
    level = models.CharField(max_length=10, default="info")
    created_at = models.DateTimeField(auto_now_add=True)
    read = models.BooleanField(default=False)
    dedupe_key = models.CharField(max_length=120, blank=True, db_index=True)

    class Meta:
        ordering = ["-created_at"]


# --------------------------------------------------------------------------
# Invoice register (statistics on book purchase invoices)
# --------------------------------------------------------------------------
def financial_year_of(d):
    """Indian financial year (April-March), e.g. 12-08-2025 -> '2025-26'."""
    if not d:
        return ""
    start = d.year if d.month >= 4 else d.year - 1
    return f"{start}-{str(start + 1)[-2:]}"


def parse_accession_range(text):
    """
    '61356-61360' -> 5 ; '35944-46' -> 3 ; '61373' -> 1 ; '100-105, 110' -> 7.
    Returns (count, normalised_text). Unknown formats -> (None, text).
    """
    import re

    raw = str(text or "").strip()
    if not raw:
        return None, ""
    total = 0
    parts = []
    for chunk in re.split(r"[,;/&]+", raw):
        chunk = chunk.strip()
        if not chunk:
            continue
        m = re.fullmatch(r"(\d+)\s*(?:-|–|to)\s*(\d+)", chunk)
        if m:
            a, b = m.group(1), m.group(2)
            if len(b) < len(a):  # shorthand 35944-46
                b = a[: len(a) - len(b)] + b
            a, b = int(a), int(b)
            if b < a:
                return None, raw
            total += b - a + 1
            parts.append(f"{a}-{b}")
        elif re.fullmatch(r"\d+(\.0)?", chunk):
            total += 1
            parts.append(str(int(float(chunk))))
        else:
            return None, raw
    return (total or None), ", ".join(parts)


class AcquisitionType(models.TextChoices):
    PURCHASE = "PURCHASE", "Purchase"
    DONATION = "DONATION", "Donation / gift"
    COMPLIMENTARY = "COMPLIMENTARY", "Complimentary"
    OTHER = "OTHER", "Other"


class InvoiceRecord(models.Model):
    document = models.ForeignKey(
        Document, null=True, blank=True, on_delete=models.SET_NULL, related_name="invoices",
        help_text="The scanned invoice in the repository (optional)",
    )
    financial_year = models.CharField(max_length=9, blank=True, db_index=True, help_text="e.g. 2025-26")
    vendor = models.CharField("Vendor / source", max_length=250, db_index=True)
    invoice_no = models.CharField("Invoice / bill no.", max_length=120, blank=True)
    invoice_date = models.DateField(null=True, blank=True)
    po_number = models.CharField("PO number", max_length=120, blank=True)
    po_date = models.DateField("PO date", null=True, blank=True)
    accession_range = models.CharField("Accession no(s).", max_length=200, blank=True, help_text="e.g. 61356-61360")
    no_of_titles = models.PositiveIntegerField("No. of titles", null=True, blank=True)
    no_of_books = models.PositiveIntegerField("No. of books (volumes)", null=True, blank=True,
                                              help_text="Calculated from the accession range when left blank")
    amount = models.DecimalField("Invoice amount (Rs)", max_digits=14, decimal_places=2, null=True, blank=True)
    acquisition_type = models.CharField(max_length=15, choices=AcquisitionType.choices, default=AcquisitionType.PURCHASE)
    remarks = models.CharField(max_length=300, blank=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, on_delete=models.SET_NULL, related_name="+")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-financial_year", "invoice_date", "id"]

    def __str__(self):
        return f"{self.vendor} {self.invoice_no}"

    def save(self, *args, **kwargs):
        self.vendor = (self.vendor or "").strip()
        if self.invoice_date and not self.financial_year:
            self.financial_year = financial_year_of(self.invoice_date)
        if self.accession_range and self.no_of_books is None:
            count, norm = parse_accession_range(self.accession_range)
            self.no_of_books = count
        super().save(*args, **kwargs)


# --------------------------------------------------------------------------
# Bulk import batches
# --------------------------------------------------------------------------
class BulkImport(models.Model):
    class State(models.TextChoices):
        VALIDATED = "VALIDATED", "Checked - ready to import"
        INVALID = "INVALID", "Errors found - nothing imported"
        RUNNING = "RUNNING", "Importing"
        DONE = "DONE", "Finished"
        FAILED = "FAILED", "Stopped with an error"

    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="+")
    created_at = models.DateTimeField(auto_now_add=True)
    file_name = models.CharField(max_length=300)
    stored_path = models.CharField(max_length=500, blank=True)
    state = models.CharField(max_length=10, choices=State.choices, default=State.VALIDATED)
    submit_for_approval = models.BooleanField(default=True)
    total_rows = models.PositiveIntegerField(default=0)
    processed = models.PositiveIntegerField(default=0)
    imported = models.PositiveIntegerField(default=0)
    failed = models.PositiveIntegerField(default=0)
    report = models.TextField(blank=True, help_text="JSON list of per-row results")
    finished_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-created_at"]

    def rows(self):
        try:
            return json.loads(self.report or "[]")
        except ValueError:
            return []
