"""Invoice register, statistics and reports."""
import json

from django import forms
from django.contrib import messages
from django.core.exceptions import PermissionDenied
from django.http import HttpResponse, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.http import require_POST

from .forms import BootstrapMixin, DateInput
from .models import AcquisitionType, Action, Document, InvoiceRecord, parse_accession_range
from .services import invoices as I
from .services.audit import audit
from .views import require

EDITABLE = {
    "financial_year": "text", "vendor": "text", "accession_range": "text", "no_of_books": "int", "no_of_titles": "int",
    "invoice_no": "text", "invoice_date": "date", "po_number": "text", "po_date": "date", "amount": "money",
    "acquisition_type": "type", "remarks": "text",
}


class InvoiceForm(BootstrapMixin, forms.ModelForm):
    class Meta:
        model = InvoiceRecord
        fields = ["vendor", "invoice_no", "invoice_date", "po_number", "po_date", "accession_range", "no_of_books",
                  "no_of_titles", "amount", "acquisition_type", "financial_year", "remarks"]
        widgets = {"invoice_date": DateInput(), "po_date": DateInput()}

    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self.fields["financial_year"].help_text = "Leave blank to calculate from the invoice date (April-March)"
        self._bootstrap()


def _ids(request):
    raw = request.GET.get("ids") or request.POST.get("ids") or ""
    return [int(x) for x in raw.split(",") if x.strip().isdigit()]


@require("can_register")
def register(request):
    params = request.GET
    qs = I.filtered(params)
    t = I.totals(qs)
    years = (InvoiceRecord.objects.exclude(financial_year="").values_list("financial_year", flat=True)
             .distinct().order_by("-financial_year"))
    vendors = InvoiceRecord.objects.values_list("vendor", flat=True).distinct().order_by("vendor")
    query = params.copy()
    return render(request, "repository/invoice_register.html", {
        "rows": qs.order_by("-financial_year", "invoice_date", "id"), "t": t, "years": years, "vendors": vendors,
        "types": AcquisitionType.choices, "params": params, "query": query.urlencode(),
        "by_vendor": I.by_vendor(qs), "by_year": I.by_year(qs), "describe": I.describe_filters(params),
        "can_edit": request.user.can_catalogue, "all_count": InvoiceRecord.objects.count(),
    })


@require("can_register")
def export(request, fmt):
    ids = _ids(request)
    qs = I.filtered(request.GET, ids).order_by("financial_year", "invoice_date", "id")
    title = I.describe_filters(request.GET, ids)
    stamp = timezone.localdate().strftime("%Y%m%d")
    if fmt == "xlsx":
        data, ctype = I.export_excel(qs, title), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    elif fmt == "pdf":
        data, ctype = I.export_pdf(qs, title), "application/pdf"
    elif fmt == "docx":
        data, ctype = I.export_word(qs, title), "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    else:
        raise PermissionDenied
    audit(Action.DOWNLOADED, request, details=f"Invoice report ({fmt}) - {title} - {qs.count()} invoices")
    resp = HttpResponse(data, content_type=ctype)
    resp["Content-Disposition"] = f'attachment; filename="invoice_report_{stamp}.{fmt}"'
    return resp


def _coerce(field, value):
    kind = EDITABLE[field]
    v = (value or "").strip()
    if kind == "text":
        return v
    if kind == "int":
        if not v:
            return None
        if not v.isdigit():
            raise ValueError(f"'{v}' is not a whole number")
        return int(v)
    if kind == "date":
        if not v:
            return None
        d = I.parse_date(v)
        if not d:
            raise ValueError(f"'{v}' is not a date (use DD-MM-YYYY)")
        return d
    if kind == "money":
        if not v:
            return None
        a = I.parse_amount(v)
        if a is None:
            raise ValueError(f"'{v}' is not an amount")
        return a
    if kind == "type":
        for code, label in AcquisitionType.choices:
            if v.upper() == code or v.lower() == label.lower() or label.lower().startswith(v.lower()):
                return code
        raise ValueError(f"Type must be one of: {', '.join(l for _, l in AcquisitionType.choices)}")
    return v


@require("can_catalogue")
@require_POST
def save_edits(request):
    """In-table editing: {"changes": {"<id>": {"field": "value"}}, "new": [{...}], "delete": [ids]}"""
    try:
        payload = json.loads(request.body.decode("utf-8"))
    except ValueError:
        return JsonResponse({"ok": False, "error": "Invalid data"}, status=400)
    errors, changed, created, deleted = [], 0, 0, 0
    for sid, fields in (payload.get("changes") or {}).items():
        rec = InvoiceRecord.objects.filter(pk=int(sid)).first()
        if not rec:
            continue
        before = {}
        for f, v in fields.items():
            if f not in EDITABLE:
                continue
            try:
                new = _coerce(f, v)
            except ValueError as e:
                errors.append(f"Row {sid}, {f}: {e}")
                continue
            before[f] = getattr(rec, f)
            setattr(rec, f, new)
            if f == "accession_range" and "no_of_books" not in fields:
                rec.no_of_books = parse_accession_range(new)[0]
        if before:
            if "invoice_date" in before and "financial_year" not in fields and rec.invoice_date:
                pass  # keep the register's year unless changed explicitly
            rec.save()
            changed += 1
            audit(Action.INVOICE_CHANGE, request, details=f"Invoice #{rec.pk} {rec.vendor} {rec.invoice_no}: "
                  + "; ".join(f"{k}: {before[k]} -> {getattr(rec, k)}" for k in before))
    for fields in payload.get("new") or []:
        if not (fields.get("vendor") or "").strip():
            continue
        rec = InvoiceRecord(created_by=request.user)
        ok = True
        for f, v in fields.items():
            if f in EDITABLE:
                try:
                    setattr(rec, f, _coerce(f, v))
                except ValueError as e:
                    errors.append(f"New row {fields.get('vendor')}: {e}")
                    ok = False
        if ok:
            rec.save()
            created += 1
            audit(Action.INVOICE_CHANGE, request, details=f"Added invoice #{rec.pk} {rec.vendor} {rec.invoice_no} {rec.amount}")
    for sid in payload.get("delete") or []:
        rec = InvoiceRecord.objects.filter(pk=int(sid)).first()
        if rec:
            audit(Action.INVOICE_CHANGE, request, details=f"Deleted invoice entry #{rec.pk} {rec.vendor} {rec.invoice_no} {rec.amount}")
            rec.delete()
            deleted += 1
    return JsonResponse({"ok": not errors, "errors": errors, "changed": changed, "created": created, "deleted": deleted})


@require("can_catalogue")
def import_index(request):
    if request.method == "POST" and request.FILES.get("workbook"):
        f = request.FILES["workbook"]
        if not f.name.lower().endswith((".xlsx", ".xlsm")):
            messages.error(request, "Please choose an Excel .xlsx file.")
            return redirect("invoice_import")
        try:
            res = I.import_index_workbook(f, request.user)
        except Exception as exc:
            messages.error(request, f"Could not read the workbook: {exc.__class__.__name__}")
            return redirect("invoice_import")
        audit(Action.INVOICE_CHANGE, request, details=f"Imported invoice index {f.name}: {res['created']} added, "
                                                      f"{res['skipped']} duplicates skipped ({', '.join(res['sheets'])})")
        messages.success(request, f"Imported {res['created']} invoices ({', '.join(res['sheets']) or 'none'}). "
                                  f"{res['skipped']} already in the register were skipped.")
        return redirect("invoices")
    return render(request, "repository/invoice_import.html")


@require("can_catalogue")
def invoice_edit(request, pk=None, doc_pk=None):
    rec = get_object_or_404(InvoiceRecord, pk=pk) if pk else None
    doc = get_object_or_404(Document, pk=doc_pk) if doc_pk else (rec.document if rec else None)
    initial = {}
    if doc and not rec:
        initial = {"vendor": doc.received_from, "invoice_no": doc.reference_number, "invoice_date": doc.document_date,
                   "amount": doc.amount}
    form = InvoiceForm(request.POST or None, instance=rec, initial=initial)
    if request.method == "POST" and form.is_valid():
        r = form.save(commit=False)
        if doc:
            r.document = doc
        if not rec:
            r.created_by = request.user
        r.save()
        audit(Action.INVOICE_CHANGE, request, document=doc,
              details=f"{'Updated' if rec else 'Added'} invoice details #{r.pk}: {r.vendor} {r.invoice_no} Rs {r.amount}")
        messages.success(request, "Invoice details saved.")
        return redirect(doc.get_absolute_url() if doc else "invoices")
    return render(request, "repository/simple_form.html", {
        "form": form, "title": ("Edit invoice details" if rec else "Add invoice details") + (f" · {doc.doc_id}" if doc else ""),
        "back": "invoices",
        "help": "These details feed the invoice register and statistics (number of invoices, books, amounts, vendors). "
                "No. of books is calculated from the accession range when left blank.",
    })
