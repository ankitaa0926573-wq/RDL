from django import template

from ..services.invoices import money

register = template.Library()


@register.filter
def inr(value):
    """12345678.5 -> 1,23,45,678.50 (Indian digit grouping)."""
    if value in (None, ""):
        return ""
    try:
        return money(value)
    except Exception:
        return value
