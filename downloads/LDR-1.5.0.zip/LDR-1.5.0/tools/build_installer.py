"""
Build the one-click Windows installer:  dist/LDR-Setup-<version>.exe

    python tools/build_installer.py                      (on the developer PC, Windows)
    python tools/build_installer.py --python-zip FILE    (use a zipped python.org install)

The installer contains everything a library needs - LDR, its own Python (the official,
Python-Software-Foundation-signed build), all packages and the built-in OCR - so nothing
has to be downloaded or typed on the library's computer and no .bat/.ps1 file is run.

Code signing (removes every Windows "unknown publisher" / Smart App Control warning)
----------------------------------------------------------------------------------
Set LDR_SIGN_CMD to the signtool command for your code-signing certificate, with $f where the
file name goes, for example (certificate on a USB token / in the Windows certificate store):

    set LDR_SIGN_CMD=signtool sign /fd SHA256 /tr http://timestamp.sectigo.com /td SHA256 /a "$f"

Every .exe / .dll / .pyd that is not already signed (Python's own files are signed by the PSF)
is signed with your certificate, and so are Setup.exe and the uninstaller.
"""
import argparse
import os
import re
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

APP = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(APP / "tools"))
from release import collect_files  # noqa: E402

PY_TAG = "3.14"  # replaced by the version of the Python that is bundled
BUILD = APP / "build"
STAGE = BUILD / "stage"
DIST = APP / "dist"


def version():
    m = re.search(r'LDR_VERSION\s*=\s*"([^"]+)"', (APP / "ldr_project" / "settings.py").read_text(encoding="utf-8"))
    return m.group(1)


def say(msg):
    print(msg, flush=True)


def stage_app():
    dest = STAGE / "app"
    shutil.rmtree(dest, ignore_errors=True)
    n = 0
    for rel in collect_files():
        if rel.parts[0] in ("installer_build",):
            continue
        target = dest / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(APP / rel, target)
        n += 1
    say(f"  LDR application: {n} files")


def stage_python(python_zip=None):
    dest = STAGE / "python"
    shutil.rmtree(dest, ignore_errors=True)
    if python_zip:
        with zipfile.ZipFile(python_zip) as zf:
            zf.extractall(STAGE)  # the zip holds a top-level "python/" folder
    else:
        if os.name != "nt":
            sys.exit("On Linux/macOS pass --python-zip (a zipped Windows python.org install).")
        src = Path(sys.base_prefix)
        skip = {"Doc", "include", "libs", "test", "idlelib", "tkinter", "turtledemo", "__pycache__", "site-packages",
                "ensurepip", "Scripts", "Tools", "tcl"}

        def ignore(d, names):
            return [n for n in names if n in skip or n.endswith(".pyc")]

        shutil.copytree(src, dest, ignore=ignore)
    if not (dest / "pythonw.exe").exists():
        sys.exit("The Python runtime has no pythonw.exe - use a 64-bit python.org Python 3.10 or newer")
    global PY_TAG
    dll = next(dest.glob("python3[0-9]*.dll"), None)
    if dll:
        digits = re.search(r"python3(\d+)\.dll", dll.name).group(1)
        PY_TAG = f"3.{digits}"
    say(f"  Bundled Python {PY_TAG} (official python.org build)")
    site = dest / "Lib" / "site-packages"
    site.mkdir(parents=True, exist_ok=True)
    say("  Installing packages for Windows into the bundled Python ...")
    subprocess.check_call([
        sys.executable, "-m", "pip", "install", "--quiet", "--disable-pip-version-check", "--no-compile",
        "--target", str(site), "--platform", "win_amd64", "--python-version", PY_TAG, "--implementation", "cp",
        "--only-binary=:all:", "-r", str(APP / "requirements.txt"), "pip", "tzdata"])
    shutil.rmtree(site / "bin", ignore_errors=True)


def stage_ocr():
    src = APP / "ocr" / "tesseract"
    dest = STAGE / "ocr" / "tesseract"
    shutil.rmtree(STAGE / "ocr", ignore_errors=True)
    if not (src / "tesseract.exe").exists():
        sys.exit("ocr/tesseract is missing - copy the 'ocr' folder from the LDR 1.3.0 package into the developer folder.")
    shutil.copytree(src, dest)
    say("  Built-in OCR added")


def is_signed(path):
    try:
        out = subprocess.run(["signtool", "verify", "/pa", "/q", str(path)], capture_output=True)
        return out.returncode == 0
    except FileNotFoundError:
        return False


def sign_binaries(cmd):
    files = [p for p in STAGE.rglob("*") if p.suffix.lower() in (".exe", ".dll", ".pyd")]
    todo = [p for p in files if not is_signed(p)]
    say(f"  Signing {len(todo)} of {len(files)} program files with your certificate ...")
    for i in range(0, len(todo), 50):
        batch = todo[i:i + 50]
        subprocess.check_call(cmd.replace('"$f"', " ".join(f'"{p}"' for p in batch)), shell=True)


def find_iscc():
    if os.environ.get("ISCC"):
        return os.environ["ISCC"].split()
    bundled = APP / "build" / "inno" / "ISCC.exe"  # Inno Setup compiler kept in the developer kit (no install needed)
    if bundled.exists():
        return [str(bundled)]
    for base in (os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"), os.environ.get("ProgramFiles", r"C:\Program Files"),
                 os.path.expandvars(r"%LOCALAPPDATA%\Programs")):
        p = Path(base) / "Inno Setup 6" / "ISCC.exe"
        if p.exists():
            return [str(p)]
    sys.exit("The installer compiler was not found in build\\inno (Inno Setup 6 by Jordan Russell, jrsoftware.org).")


def winpath(p):
    """Path as the (possibly wine-hosted) compiler sees it."""
    p = str(p)
    if os.name != "nt":
        return "Z:" + p.replace("/", "\\")
    return p


def compile_installer(ver, sign_cmd):
    DIST.mkdir(exist_ok=True)
    args = find_iscc() + ["/Q", f"/DAppVersion={ver}", f"/DSourceDir={winpath(STAGE)}", f"/DOutDir={winpath(DIST)}"]
    if sign_cmd:
        args += ["/DSignTool=ldrsign", "/Sldrsign=" + sign_cmd.replace('"$f"', "$f")]
    args.append(winpath(APP / "installer" / "ldr.iss"))
    say("  Compiling the installer (a few minutes) ...")
    subprocess.check_call(args)
    out = DIST / f"LDR-Setup-{ver}.exe"
    say(f"\nInstaller ready: {out}  ({out.stat().st_size / 1048576:.0f} MB)")
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--python-zip", help="zip containing a 'python/' folder with a 64-bit python.org Python " + PY_TAG)
    ap.add_argument("--reuse-python", action="store_true", help="keep build/stage/python from the last build")
    a = ap.parse_args()
    ver = version()
    sign_cmd = os.environ.get("LDR_SIGN_CMD", "").strip()
    say(f"Building LDR-Setup-{ver}.exe" + (" (signed)" if sign_cmd else " (NOT code-signed - Windows may warn)"))
    STAGE.mkdir(parents=True, exist_ok=True)
    stage_app()
    if not (a.reuse_python and (STAGE / "python" / "pythonw.exe").exists()):
        stage_python(a.python_zip)
    stage_ocr()
    if sign_cmd:
        sign_binaries(sign_cmd)
    compile_installer(ver, sign_cmd)


if __name__ == "__main__":
    main()
