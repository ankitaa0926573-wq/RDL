"""
Start the Library Document Repository server.

    python run_server.py            (add --open to open the browser)

* Listens on all network interfaces (0.0.0.0) on the port in ldr_config.ini
  (default 8080): http://localhost:8080 on this computer and
  http://<this-computer's-IP>:8080 from every computer on the library LAN.
* This file is a small SUPERVISOR: it starts the web server as a child process,
  restarts it if it ever crashes, and installs software updates that the
  administrator approved inside LDR (with automatic rollback if the new version
  does not start).
"""
import configparser
import hashlib
import json
import os
import shutil
import subprocess
import sys
import threading
import time
import zipfile
from datetime import datetime
from pathlib import Path

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
os.chdir(BASE)
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "ldr_project.settings")

ALREADY_RUNNING = 3     # exit code used by start_ldr.bat
RESTART_FOR_UPDATE = 75  # child exit code: "please install the staged update"
PROTECTED = {"data", ".venv", "venv", "python", "ocr", "build", "staticfiles", "ldr_config.ini", ".git", "dist", "release_keys", "website", "release_settings.ini", "publish_release.bat"}


# --------------------------------------------------------------------------- helpers
def read_config():
    cfg = configparser.ConfigParser()
    cfg.read(os.environ.get("LDR_CONFIG", BASE / "ldr_config.ini"), encoding="utf-8")
    port = cfg.getint("server", "port", fallback=8080)
    data = Path(cfg.get("paths", "data_dir", fallback="data"))
    data = data if data.is_absolute() else BASE / data
    return port, data


def redirect_output_if_background(data_dir):
    """pythonw.exe (background service) has no console: send output to a log file."""
    if sys.stdout is None or sys.stderr is None:
        log_dir = data_dir / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        fh = open(log_dir / "server_console.log", "a", encoding="utf-8", buffering=1)
        sys.stdout = sys.stdout or fh
        sys.stderr = sys.stderr or fh


def port_in_use(port):
    import socket

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(1)
        return s.connect_ex(("127.0.0.1", port)) == 0


def say(msg):
    print(f"[LDR {datetime.now():%Y-%m-%d %H:%M:%S}] {msg}", flush=True)


# =========================================================================== CHILD
def parent_watchdog(ppid):
    """Exit if the supervisor disappears (e.g. service stopped), so no orphan keeps the port."""
    while True:
        time.sleep(5)
        alive = True
        if os.name == "nt":
            import ctypes

            h = ctypes.windll.kernel32.OpenProcess(0x00100000, False, ppid)  # SYNCHRONIZE
            if not h:
                alive = False
            else:
                alive = ctypes.windll.kernel32.WaitForSingleObject(h, 0) == 0x102  # WAIT_TIMEOUT
                ctypes.windll.kernel32.CloseHandle(h)
        else:
            try:
                os.kill(ppid, 0)
            except OSError:
                alive = False
        if not alive:
            os._exit(0)


def scheduler():
    """Every 15 minutes: run the daily jobs when due (retention, integrity, backup, update check)."""
    import logging

    log = logging.getLogger("ldr")
    time.sleep(20)
    try:  # Windows: fetch the built-in OCR once if this installation does not have it yet
        from repository.services.ocr_setup import ensure_builtin_ocr

        ensure_builtin_ocr(background=True)
    except Exception:
        log.exception("Built-in OCR check failed")
    while True:
        try:
            from django.db import close_old_connections

            close_old_connections()
            from repository.services.maintenance import daily_jobs

            res = daily_jobs()
            if res:
                log.info("Daily jobs: %s", res)
        except Exception:
            log.exception("Scheduled job failed")
        time.sleep(15 * 60)


def run_child():
    import django

    django.setup()
    from django.conf import settings
    from django.core.management import call_command

    host = settings.CONFIG.get("server", "host")
    port = settings.CONFIG.getint("server", "port")
    threads = settings.CONFIG.getint("server", "threads")

    call_command("migrate", interactive=False, verbosity=0)
    call_command("collectstatic", interactive=False, verbosity=0)
    # fail fast (so a bad update is rolled back) instead of serving broken pages
    call_command("check", verbosity=0)
    from django.urls import get_resolver

    get_resolver().url_patterns  # imports every view module
    try:
        from repository.services.updates import record_last_result

        record_last_result()
    except Exception:
        pass

    from repository.netinfo import lan_addresses

    line = "=" * 66
    print(line)
    print(f"  LDR - Library Document Repository v{settings.LDR_VERSION} is running")
    print(line)
    print(f"  On this computer : http://localhost:{port}")
    for ip in lan_addresses():
        print(f"  On the library LAN: http://{ip}:{port}")
    print(f"  Data folder       : {settings.DATA_DIR}")
    if "--background" not in sys.argv:
        print("  Keep this window open. Press Ctrl+C to stop the server.")
        print("  TIP: run ldr_service.bat once to run LDR in the background")
        print("       (no window, starts automatically with the computer).")
    print(line, flush=True)

    ppid = int(os.environ.get("LDR_SUPERVISOR_PID", "0"))
    if ppid:
        threading.Thread(target=parent_watchdog, args=(ppid,), daemon=True).start()
    threading.Thread(target=scheduler, daemon=True, name="ldr-scheduler").start()
    if "--open" in sys.argv:
        import webbrowser

        threading.Timer(2, lambda: webbrowser.open(f"http://localhost:{port}")).start()

    from waitress import serve

    from ldr_project.wsgi import application

    serve(application, host=host, port=port, threads=threads, max_request_body_size=1024 * 1024 * 1024,
          channel_timeout=300, ident="LDR")


# =========================================================================== SUPERVISOR: updates
def program_files(root: Path):
    """Relative paths of the application's program files (user data excluded)."""
    out = []
    for p in root.rglob("*"):
        if not p.is_file():
            continue
        rel = p.relative_to(root)
        if rel.parts[0] in PROTECTED or "__pycache__" in rel.parts or rel.name.startswith("file:memorydb"):
            continue
        out.append(rel)
    return out


def _sha(p: Path):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def _pip_install(req_file: Path):
    exe = Path(sys.executable)
    if exe.name.lower() == "pythonw.exe":
        exe = exe.with_name("python.exe")
    r = subprocess.run([str(exe), "-m", "pip", "install", "-q", "-r", str(req_file)],
                       capture_output=True, text=True, cwd=BASE)
    if r.returncode != 0:
        raise RuntimeError("Installing required packages failed (internet needed?): " + (r.stderr or r.stdout)[-400:])


def install_pending_update(data_dir: Path):
    """Swap program files for the staged release. Returns state needed for rollback (or None)."""
    pending_path = data_dir / "updates" / "pending.json"
    if not pending_path.exists():
        return None
    pending = json.loads(pending_path.read_text(encoding="utf-8"))
    src = Path(pending["source_dir"])
    say(f"Installing update {pending['from_version']} -> {pending['version']} ...")
    state = {"pending": pending, "rollback_dir": None, "requirements_changed": False}
    try:
        manifest = json.loads((src / "RELEASE_MANIFEST.json").read_text(encoding="utf-8"))
        files = manifest["files"]
        for rel, digest in files.items():  # re-check: nothing changed since it was verified
            if _sha(src / rel) != digest:
                raise RuntimeError(f"Staged file changed after verification: {rel}")
        rb = data_dir / "updates" / "rollback" / f"{pending['from_version']}_{datetime.now():%Y%m%d_%H%M%S}"
        rb.mkdir(parents=True)
        old_files = program_files(BASE)
        for rel in old_files:
            (rb / rel).parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(BASE / rel, rb / rel)
        state["rollback_dir"] = str(rb)
        old_req = (BASE / "requirements.txt").read_bytes() if (BASE / "requirements.txt").exists() else b""
        new_set = {Path(r) for r in files}
        for rel in old_files:  # remove program files that no longer exist in the new version
            if rel not in new_set and rel.parts[0] not in PROTECTED:
                (BASE / rel).unlink(missing_ok=True)
        for rel in files:
            target = BASE / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src / rel, target)
        for name in ("RELEASE_MANIFEST.json", "RELEASE_SIGNATURE.txt"):
            if (src / name).exists():
                shutil.copy2(src / name, BASE / name)
        if (BASE / "requirements.txt").read_bytes() != old_req:
            state["requirements_changed"] = True
            say("Installing new required packages ...")
            _pip_install(BASE / "requirements.txt")
    except Exception as exc:
        rollback(state, data_dir, f"{exc}")
        return None
    return state


def rollback(state, data_dir: Path, reason: str):
    pending = state["pending"]
    say(f"UPDATE FAILED - rolling back to {pending['from_version']}: {reason}")
    rb = Path(state["rollback_dir"]) if state.get("rollback_dir") else None
    if rb and rb.exists():
        for rel in program_files(BASE):
            if not (rb / rel).exists():
                (BASE / rel).unlink(missing_ok=True)
        for p in rb.rglob("*"):
            if p.is_file():
                target = BASE / p.relative_to(rb)
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(p, target)
        if state.get("requirements_changed"):
            try:
                _pip_install(BASE / "requirements.txt")
            except Exception as exc:
                say(f"Warning: could not reinstall old packages: {exc}")
    db = pending.get("database")
    backup = pending.get("backup")
    if db and backup and Path(backup).exists():  # undo any database changes
        with zipfile.ZipFile(backup) as zf:
            if "database/ldr.sqlite3" in zf.namelist():
                for suffix in ("-wal", "-shm"):
                    Path(db + suffix).unlink(missing_ok=True)
                with zf.open("database/ldr.sqlite3") as fsrc, open(db, "wb") as fdst:
                    shutil.copyfileobj(fsrc, fdst)
    finish(data_dir, pending, ok=False, message=reason)


def finish(data_dir: Path, pending, ok, message=""):
    upd = data_dir / "updates"
    (upd / "last_result.json").write_text(json.dumps({
        "ok": ok, "version": pending["version"], "from_version": pending["from_version"],
        "message": message or ("Installed successfully" if ok else ""), "at": datetime.now().isoformat(),
        "requested_by": pending.get("requested_by"),
    }, indent=1), encoding="utf-8")
    (upd / "pending.json").unlink(missing_ok=True)
    shutil.rmtree(Path(pending["source_dir"]).parent if Path(pending["source_dir"]).parent.name != "staging"
                  else pending["source_dir"], ignore_errors=True)
    # keep only the 3 most recent rollback copies
    rbs = sorted((upd / "rollback").glob("*")) if (upd / "rollback").exists() else []
    for old in rbs[:-3]:
        shutil.rmtree(old, ignore_errors=True)
    say(("Update to " + pending["version"] + " installed.") if ok else "Previous version restored.")


# =========================================================================== SUPERVISOR: main loop
def start_child(extra_args):
    env = dict(os.environ, LDR_SUPERVISED="1", LDR_SUPERVISOR_PID=str(os.getpid()))
    return subprocess.Popen([sys.executable, str(BASE / "run_server.py"), "--child", *extra_args], cwd=BASE, env=env)


def http_ok(port):
    """True when the login page really works (not just an open port)."""
    import urllib.error
    import urllib.request

    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/login/", timeout=10) as r:
            return r.status == 200
    except urllib.error.HTTPError:
        return False
    except OSError:
        return None  # not listening yet


def wait_until_up(child, port, timeout=120):
    t0 = time.time()
    while time.time() - t0 < timeout:
        if child.poll() is not None:
            return False
        ok = http_ok(port)
        if ok is True:
            return True
        if ok is False and time.time() - t0 > 20:  # serving errors after warm-up
            return False
        time.sleep(1)
    return False


def keep_awake():
    """Windows: tell Windows this computer is a server - do not go to sleep while LDR runs.
    (The screen may still turn off; that is fine.) Lasts as long as this process lives."""
    if os.name != "nt":
        return
    try:
        import ctypes

        ES_CONTINUOUS, ES_SYSTEM_REQUIRED, ES_AWAYMODE_REQUIRED = 0x80000000, 0x00000001, 0x00000040
        if not ctypes.windll.kernel32.SetThreadExecutionState(ES_CONTINUOUS | ES_SYSTEM_REQUIRED | ES_AWAYMODE_REQUIRED):
            ctypes.windll.kernel32.SetThreadExecutionState(ES_CONTINUOUS | ES_SYSTEM_REQUIRED)
        say("Keep-awake on: this computer will not sleep while LDR is running.")
    except Exception as exc:  # never stop the server because of this
        say(f"Keep-awake not available: {exc}")


def supervise():
    port, data_dir = read_config()
    redirect_output_if_background(data_dir)
    if port_in_use(port):
        print(f"LDR is already running (in the background) at http://localhost:{port}", flush=True)
        if "--open" in sys.argv:
            import webbrowser

            webbrowser.open(f"http://localhost:{port}")
        sys.exit(ALREADY_RUNNING)

    keep_awake()
    passthrough = [a for a in sys.argv[1:] if a in ("--background", "--open")]
    crashes = []
    while True:
        state = install_pending_update(data_dir)
        child = start_child(passthrough)
        passthrough = [a for a in passthrough if a != "--open"]  # open the browser only once
        if state:  # just installed an update: make sure the new version really starts
            if wait_until_up(child, port):
                finish(data_dir, state["pending"], ok=True)
            else:
                say("New version did not start.")
                if child.poll() is None:
                    child.terminate()
                    child.wait(30)
                rollback(state, data_dir, "The new version failed to start, so the previous version was restored")
                continue
        try:
            rc = child.wait()
        except KeyboardInterrupt:
            child.terminate()
            try:
                child.wait(15)
            except subprocess.TimeoutExpired:
                child.kill()
            say("LDR stopped.")
            return
        if rc == RESTART_FOR_UPDATE:
            say("Restarting to install the update ...")
            continue
        if rc == 0:
            return
        now = time.time()
        crashes = [t for t in crashes if now - t < 300] + [now]
        wait = min(60, 5 * len(crashes))
        say(f"Server stopped unexpectedly (code {rc}); restarting in {wait} s ...")
        time.sleep(wait)


if __name__ == "__main__":
    if "--child" in sys.argv:
        _port, _data = read_config()
        redirect_output_if_background(_data)
        run_child()
    else:
        try:
            supervise()
        except KeyboardInterrupt:
            pass
