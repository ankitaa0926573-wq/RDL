import io
from decimal import Decimal
import shutil
import tempfile
from datetime import date, timedelta

from django.conf import settings
from django.core.exceptions import ValidationError
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import TestCase, override_settings
from django.urls import reverse
from django.utils import timezone

from .defaults import load_defaults
from .models import (
    AccessRequest,
    BulkImport,
    InvoiceRecord,
    AuditLog,
    Category,
    Confidentiality,
    DisposalRecord,
    Document,
    DocumentFile,
    Role,
    SiteSettings,
    Status,
    User,
)
from .services import lifecycle as L
from .services import maintenance as M
from .services.audit import verify_chain

TMP = tempfile.mkdtemp()


def make_pdf(text="Invoice No 4521 from Allied Book Agency for Rs 45,000"):
    """Tiny valid PDF with real text."""
    from pypdf import PdfWriter
    from pypdf.generic import DecodedStreamObject, DictionaryObject, NameObject

    w = PdfWriter()
    page = w.add_blank_page(612, 792)
    font = DictionaryObject({
        NameObject("/Type"): NameObject("/Font"), NameObject("/Subtype"): NameObject("/Type1"),
        NameObject("/BaseFont"): NameObject("/Helvetica"),
    })
    page[NameObject("/Resources")] = DictionaryObject({
        NameObject("/Font"): DictionaryObject({NameObject("/F1"): w._add_object(font)})
    })
    stream = DecodedStreamObject()
    stream.set_data(f"BT /F1 12 Tf 72 720 Td ({text}) Tj ET".encode())
    page[NameObject("/Contents")] = w._add_object(stream)
    buf = io.BytesIO()
    w.write(buf)
    return buf.getvalue()


@override_settings(MEDIA_ROOT=TMP, BACKUP_DIR=settings.BACKUP_DIR.__class__(TMP) / "backups")
class WorkflowTests(TestCase):
    @classmethod
    def tearDownClass(cls):
        super().tearDownClass()
        shutil.rmtree(TMP, ignore_errors=True)

    def setUp(self):
        (settings.BACKUP_DIR.__class__(TMP) / "backups").mkdir(parents=True, exist_ok=True)
        load_defaults()
        s = SiteSettings.load()
        s.setup_completed = True
        s.save()
        self.admin = User.objects.create_user("admin", password="x", role=Role.ADMIN, is_superuser=True, is_staff=True)
        self.sup = User.objects.create_user("super", password="x", role=Role.SUPER_LIBRARIAN, first_name="Super")
        self.sup2 = User.objects.create_user("super2", password="x", role=Role.SUPER_LIBRARIAN)
        self.cat_user = User.objects.create_user("cat", password="x", role=Role.CATALOGUER)
        self.tech = User.objects.create_user("tech", password="x", role=Role.TECHNICAL)
        self.viewer = User.objects.create_user("viewer", password="x", role=Role.AUTHORIZED)
        self.inv = Category.objects.get(code="INV")
        self.agr = Category.objects.get(code="AGR")

    def _register(self, client, title="Invoice from Allied Book Agency", category=None):
        category = category or self.inv
        r = client.post(reverse("document_new"), {
            "title": title, "category": category.pk, "source_type": "PHYSICAL",
            "received_from": "Allied Book Agency", "received_date": date.today().isoformat(),
            "reference_number": "INV-4521", "physical_location": "Cabinet A / File 3",
            "confidentiality": "",
        })
        self.assertEqual(r.status_code, 302, getattr(r, "context", None) and r.context["form"].errors)
        return Document.objects.latest("id")

    def test_full_seven_phase_lifecycle(self):
        c = self.client
        c.force_login(self.tech)
        # Phase 1
        doc = self._register(c)
        self.assertTrue(doc.doc_id.startswith(f"LDR-{timezone.localdate().year}-"))
        self.assertEqual(doc.status, Status.RECEIVED)
        self.assertEqual(doc.custodian, self.tech)
        self.assertIsNotNone(doc.expiry_date)  # 8-year retention from category
        # Phase 2
        pdf = SimpleUploadedFile("invoice.pdf", make_pdf(), content_type="application/pdf")
        r = c.post(reverse("document_upload", args=[doc.pk]), {"files": [pdf]})
        self.assertEqual(r.status_code, 302)
        doc.refresh_from_db()
        self.assertEqual(doc.files.count(), 1)
        self.assertIn("Allied", doc.extracted_text)
        self.assertEqual(len(doc.files.first().sha256), 64)
        c.post(reverse("document_digitized", args=[doc.pk]))
        doc.refresh_from_db()
        self.assertEqual(doc.status, Status.DIGITIZED)
        # view-only staff cannot do metadata; working staff can
        c.force_login(self.viewer)
        self.assertEqual(c.get(reverse("document_metadata", args=[doc.pk])).status_code, 403)
        # Phase 3
        c.force_login(self.cat_user)
        r = c.post(reverse("document_metadata", args=[doc.pk]), {
            "title": doc.title, "category": self.inv.pk, "description": "Book purchase invoice",
            "keywords": "books, purchase", "document_year": "2025-26", "language": "English",
            "custodian": self.tech.pk, "confidentiality": "GENERAL", "received_from": "Allied Book Agency",
            "amount": "45000", "submit": "1",
        })
        self.assertEqual(r.status_code, 302)
        doc.refresh_from_db()
        self.assertEqual(doc.status, Status.PENDING_APPROVAL)
        # super librarian got a notification
        self.assertTrue(self.sup.notifications.filter(message__contains=doc.doc_id).exists())
        # Phase 4: cataloguer cannot approve
        r = c.post(reverse("document_decide", args=[doc.pk]), {"decision": "approve"})
        self.assertEqual(r.status_code, 403)
        c.force_login(self.sup)
        c.post(reverse("document_decide", args=[doc.pk]), {"decision": "return", "remarks": "Add vendor GST no."})
        doc.refresh_from_db()
        self.assertEqual(doc.status, Status.RETURNED)
        c.force_login(self.cat_user)
        c.post(reverse("document_submit", args=[doc.pk]))
        c.force_login(self.sup)
        c.post(reverse("document_decide", args=[doc.pk]), {"decision": "approve", "remarks": "Verified"})
        doc.refresh_from_db()
        self.assertEqual(doc.status, Status.ACTIVE)
        self.assertEqual(doc.approved_by, self.sup)
        # metadata locked
        c.force_login(self.cat_user)
        r = c.get(reverse("document_metadata", args=[doc.pk]))
        self.assertEqual(r.status_code, 302)
        # Phase 5: viewer can open general doc & download is logged
        c.force_login(self.viewer)
        self.assertEqual(c.get(doc.get_absolute_url()).status_code, 200)
        f = doc.files.first()
        r = c.get(reverse("file_download", args=[f.pk]))
        self.assertEqual(r.status_code, 200)
        self.assertTrue(AuditLog.objects.filter(action="DOWNLOADED", document=doc, username="viewer").exists())
        # Search finds text inside the PDF
        r = c.get(reverse("document_list"), {"q": "Allied"})
        self.assertContains(r, doc.doc_id)
        # Phase 6: expire it, daily job flags review
        Document.objects.filter(pk=doc.pk).update(expiry_date=timezone.localdate() - timedelta(days=1))
        M.retention_check()
        doc.refresh_from_db()
        self.assertEqual(doc.status, Status.UNDER_REVIEW)
        c.force_login(self.sup)
        c.post(reverse("retention_review", args=[doc.pk]), {"decision": "DISPOSE", "remarks": "Audit complete"})
        # Phase 7
        c.post(reverse("disposal_request", args=[doc.pk]), {"method": "DELETE", "reason": "Retention period over; audited"})
        doc.refresh_from_db()
        self.assertEqual(doc.status, Status.DISPOSAL_REQUESTED)
        rec = DisposalRecord.objects.get(document=doc)
        # same person cannot approve (four-eyes)
        c.post(reverse("disposal_decide", args=[rec.pk]), {"decision": "approve", "confirm": doc.doc_id})
        rec.refresh_from_db()
        self.assertEqual(rec.state, DisposalRecord.State.REQUESTED)
        c.force_login(self.sup2)
        path = f.file.path
        r = c.post(reverse("disposal_decide", args=[rec.pk]), {"decision": "approve", "confirm": doc.doc_id})
        rec.refresh_from_db()
        doc.refresh_from_db()
        self.assertEqual(rec.state, DisposalRecord.State.APPROVED)
        self.assertEqual(doc.status, Status.DISPOSED)
        self.assertTrue(rec.certificate_number.startswith("DSP-"))
        import os

        self.assertFalse(os.path.exists(path))
        self.assertEqual(rec.manifest()[0]["sha256"], f.sha256)
        self.assertEqual(c.get(reverse("disposal_certificate", args=[rec.pk])).status_code, 200)
        # Audit chain intact
        ok, n, _ = verify_chain()
        self.assertTrue(ok)
        self.assertGreater(n, 10)

    def test_confidential_access_request(self):
        c = self.client
        c.force_login(self.cat_user)
        doc = self._register(c, "AMC agreement with vendor", self.agr)
        self.assertEqual(doc.confidentiality, Confidentiality.CONFIDENTIAL)
        L.add_file(doc, SimpleUploadedFile("agr.pdf", make_pdf("Confidential agreement")), self.cat_user)
        doc.description, doc.document_year = "AMC", "2025"
        doc.save()
        L.submit_for_approval(doc, self.cat_user)
        L.approve(doc, self.sup)
        f = doc.files.first()
        c.force_login(self.tech)
        r = c.get(doc.get_absolute_url())
        self.assertContains(r, "Send permission request")
        self.assertEqual(c.get(reverse("file_download", args=[f.pk])).status_code, 403)
        self.assertTrue(AuditLog.objects.filter(action="ACCESS_DENIED", username="tech").exists())
        # confidential text not searchable for non-super users
        r = c.get(reverse("document_list"), {"q": "Confidential agreement"})
        self.assertNotContains(r, doc.doc_id)
        c.post(reverse("access_request", args=[doc.pk]), {"purpose": "NAAC criterion 4"})
        ar = AccessRequest.objects.get()
        c.force_login(self.sup)
        c.post(reverse("access_decide", args=[ar.pk]), {"decision": "approve"})
        c.force_login(self.tech)
        self.assertEqual(c.get(reverse("file_download", args=[f.pk])).status_code, 200)

    def test_tamper_detection(self):
        self.client.force_login(self.tech)
        self._register(self.client)
        ok, _, _ = verify_chain()
        self.assertTrue(ok)
        AuditLog.objects.filter(pk=AuditLog.objects.order_by("id").first().pk).update(details="edited")
        ok, _, bad = verify_chain()
        self.assertFalse(ok)

    def test_fixity_and_backup(self):
        doc = L.register_document(Document(title="Minutes", category=Category.objects.get(code="MIN")), self.cat_user)
        df, _ = L.add_file(doc, SimpleUploadedFile("m.txt", b"minutes of meeting"), self.cat_user)
        self.assertTrue(df.verify_fixity())
        with open(df.file.path, "ab") as fh:
            fh.write(b"tampered")
        self.assertFalse(df.verify_fixity())
        z = M.make_backup()
        import zipfile

        names = zipfile.ZipFile(z).namelist()
        self.assertIn("database/ldr.sqlite3", names)
        self.assertTrue(any(n.startswith("repository_files/") for n in names))

    def test_pages_render_for_each_role(self):
        doc = L.register_document(Document(title="Policy", category=Category.objects.get(code="POL")), self.cat_user)
        for u in (self.admin, self.sup, self.cat_user, self.tech, self.viewer):
            self.client.force_login(u)
            for name in ("dashboard", "document_list", "access_requests", "notifications", "profile", "help"):
                self.assertEqual(self.client.get(reverse(name)).status_code, 200, (u.username, name))
        self.client.force_login(self.admin)
        for name in ("approvals", "retention", "disposals", "audit_log", "reports", "users", "categories",
                     "site_settings", "user_new", "category_new"):
            self.assertEqual(self.client.get(reverse(name)).status_code, 200, name)
        self.assertEqual(self.client.get(doc.get_absolute_url()).status_code, 200)
        self.client.force_login(self.viewer)
        self.assertEqual(self.client.get(reverse("audit_log")).status_code, 403)
        # viewer cannot see work-in-progress documents
        self.assertEqual(self.client.get(doc.get_absolute_url()).status_code, 403)


class SetupTests(TestCase):
    def test_setup_wizard(self):
        from .middleware import SetupRequiredMiddleware

        SetupRequiredMiddleware._done = False
        r = self.client.get("/")
        self.assertRedirects(r, reverse("setup"))
        r = self.client.post(reverse("setup"), {
            "library_name": "Central Library", "institution_name": "Test University", "id_prefix": "CL",
            "admin_username": "librarian", "admin_full_name": "Head Librarian", "password1": "Strong#Pass2026",
            "password2": "Strong#Pass2026", "load_defaults": "on",
        })
        self.assertRedirects(r, reverse("dashboard"))
        self.assertTrue(User.objects.get(username="librarian").is_admin_role)
        self.assertGreater(Category.objects.count(), 10)


def make_xlsx():
    import openpyxl

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Stock"
    ws.append(["Item", "Qty", "Rate"])
    ws.append(["Books", 45, 1013.33])
    ws.append(["Journals", 12, 2500])
    ws["D1"] = "Total"
    ws["D2"] = "=B2*C2"
    wb.create_sheet("Notes")["A1"] = "Second sheet"
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def make_docx():
    import docx

    d = docx.Document()
    d.add_heading("Library Committee Minutes", 1)
    d.add_paragraph("Meeting held on 12 August 2025.")
    t = d.add_table(rows=1, cols=2)
    t.rows[0].cells[0].text = "Budget"
    t.rows[0].cells[1].text = "Rs 5,00,000"
    buf = io.BytesIO()
    d.save(buf)
    return buf.getvalue()


@override_settings(MEDIA_ROOT=TMP)
class ViewerVersioningTests(TestCase):
    def setUp(self):
        load_defaults()
        s = SiteSettings.load()
        s.setup_completed = True
        s.save()
        self.sup = User.objects.create_user("super", password="x", role=Role.SUPER_LIBRARIAN)
        self.cat = User.objects.create_user("cat", password="x", role=Role.CATALOGUER)
        self.doc = L.register_document(Document(title="Stock register", category=Category.objects.get(code="STK"),
                                                description="d", document_year="2025"), self.cat)
        self.xl, _ = L.add_file(self.doc, SimpleUploadedFile("stock.xlsx", make_xlsx()), self.cat)
        self.wd, _ = L.add_file(self.doc, SimpleUploadedFile("minutes.docx", make_docx()), self.cat)
        self.csvf, _ = L.add_file(self.doc, SimpleUploadedFile("list.csv", b"name,qty\nA,1\nB,2\n"), self.cat)

    def test_viewers_render(self):
        self.client.force_login(self.cat)
        r = self.client.get(reverse("file_view", args=[self.xl.pk]))
        self.assertContains(r, "Journals")
        self.assertContains(r, "Notes")  # second sheet tab
        self.assertContains(r, "=B2*C2")  # formula shown when no cached value
        r = self.client.get(reverse("file_view", args=[self.wd.pk]))
        self.assertContains(r, "Library Committee Minutes")
        self.assertContains(r, "5,00,000")
        r = self.client.get(reverse("file_view", args=[self.csvf.pk]))
        self.assertContains(r, "<td title=\"B\">B</td>", html=False)
        self.assertEqual(self.client.get(reverse("file_edit", args=[self.xl.pk])).status_code, 200)
        self.assertEqual(self.client.get(reverse("file_edit", args=[self.wd.pk])).status_code, 200)

    def test_edit_in_workflow_creates_current_version(self):
        import json

        import openpyxl

        self.client.force_login(self.cat)
        r = self.client.post(reverse("file_edit", args=[self.xl.pk]), {
            "change_note": "Corrected quantity", "edits": json.dumps({"Stock": {"2,2": "50", "5,1": "Newspapers"}})})
        self.assertEqual(r.status_code, 302)
        new = DocumentFile.objects.get(previous=self.xl)
        self.assertTrue(new.is_current)
        self.xl.refresh_from_db()
        self.assertFalse(self.xl.is_current)
        ws = openpyxl.load_workbook(new.file.path)["Stock"]
        self.assertEqual(ws["B2"].value, 50)
        self.assertEqual(ws["A5"].value, "Newspapers")
        self.assertEqual(ws["D2"].value, "=B2*C2")
        # word edit
        r = self.client.post(reverse("file_edit", args=[self.wd.pk]), {
            "change_note": "Fixed date", "edits": json.dumps({"p1": "Meeting held on 14 August 2025."}),
            "appended": "Action: renew subscriptions"})
        neww = DocumentFile.objects.get(previous=self.wd)
        import docx

        texts = [p.text for p in docx.Document(neww.file.path).paragraphs]
        self.assertIn("Meeting held on 14 August 2025.", texts)
        self.assertIn("Action: renew subscriptions", texts)
        # change note is mandatory
        r = self.client.post(reverse("file_edit", args=[self.csvf.pk]), {"change_note": "", "edits": json.dumps({"Sheet1": {"2,2": "9"}})})
        self.assertFalse(DocumentFile.objects.filter(previous=self.csvf).exists())

    def test_edit_of_approved_record_needs_approval(self):
        import json

        L.submit_for_approval(self.doc, self.cat)
        L.approve(self.doc, self.sup)
        self.client.force_login(self.cat)
        self.client.post(reverse("file_edit", args=[self.csvf.pk]), {
            "change_note": "Added row", "edits": json.dumps({"Sheet1": {"4,1": "C", "4,2": "3"}})})
        new = DocumentFile.objects.get(previous=self.csvf)
        self.assertTrue(new.pending_approval)
        self.assertFalse(new.is_current)
        self.csvf.refresh_from_db()
        self.assertTrue(self.csvf.is_current)  # approved version stays official
        # second edit blocked while pending
        with self.assertRaises(ValidationError):
            L.add_version(self.csvf, b"x,y\n", "list.csv", "again", self.cat)
        # super librarian approves
        self.client.force_login(self.sup)
        self.client.post(reverse("version_decide", args=[new.pk]), {"decision": "approve"})
        new.refresh_from_db()
        self.csvf.refresh_from_db()
        self.assertTrue(new.is_current)
        self.assertFalse(new.pending_approval)
        self.assertFalse(self.csvf.is_current)
        self.assertTrue(AuditLog.objects.filter(action="VERSION_APPROVED").exists())
        # upload-new-version path + reject
        self.client.force_login(self.cat)
        self.client.post(reverse("file_new_version", args=[self.wd.pk]),
                         {"change_note": "Signed copy", "file": SimpleUploadedFile("minutes_signed.docx", make_docx() + b"")})
        # identical content is refused
        self.assertFalse(DocumentFile.objects.filter(previous=self.wd).exists())
        self.client.post(reverse("file_new_version", args=[self.wd.pk]),
                         {"change_note": "Signed copy", "file": SimpleUploadedFile("minutes_signed.pdf", make_pdf("signed"))})
        nv = DocumentFile.objects.get(previous=self.wd)
        self.client.force_login(self.sup)
        self.client.post(reverse("version_decide", args=[nv.pk]), {"decision": "reject"})
        self.assertFalse(DocumentFile.objects.filter(pk=nv.pk).exists())
        self.wd.refresh_from_db()
        self.assertTrue(self.wd.is_current)


class UpdateTests(TestCase):
    """Release signing/verification used by the in-app updater."""

    def _release(self, version, key, tamper=False):
        import base64
        import hashlib
        import json
        import zipfile

        tmp = tempfile.mkdtemp()
        files = {"ldr_project/settings.py": b"LDR_VERSION = 'x'\n", "README.md": b"hello\n"}
        manifest = {"product": "LDR", "version": version, "files": {k: hashlib.sha256(v).hexdigest() for k, v in files.items()}}
        mb = json.dumps(manifest, sort_keys=True).encode()
        sig = base64.b64encode(key.sign(mb)).decode()
        zp = f"{tmp}/LDR-{version}.zip"
        with zipfile.ZipFile(zp, "w") as zf:
            for k, v in files.items():
                zf.writestr(f"LDR-{version}/{k}", v + (b"evil" if tamper and k == "README.md" else b""))
            zf.writestr(f"LDR-{version}/RELEASE_MANIFEST.json", mb)
            zf.writestr(f"LDR-{version}/RELEASE_SIGNATURE.txt", sig)
        return zp

    def setUp(self):
        from cryptography.hazmat.primitives import serialization as S
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

        self.key = Ed25519PrivateKey.generate()
        self.pub = self.key.public_key().public_bytes(S.Encoding.PEM, S.PublicFormat.SubjectPublicKeyInfo).decode()
        self.admin = User.objects.create_user("admin", password="x", role=Role.ADMIN)
        self.tmpdata = tempfile.mkdtemp()

    def _stage(self, zp):
        from pathlib import Path
        from unittest import mock

        from . import update_source
        from .services import updates as U

        with mock.patch.object(update_source, "PUBLIC_KEY_PEM", self.pub), \
                override_settings(DATA_DIR=Path(self.tmpdata), BACKUP_DIR=Path(self.tmpdata) / "b", MEDIA_ROOT=TMP):
            (Path(self.tmpdata) / "b").mkdir(exist_ok=True)
            return U.stage_update(Path(zp), self.admin)

    def test_valid_release_is_staged(self):
        import json
        from pathlib import Path

        m = self._stage(self._release("99.0.0", self.key))
        self.assertEqual(m["version"], "99.0.0")
        pending = json.loads((Path(self.tmpdata) / "updates" / "pending.json").read_text())
        self.assertEqual(pending["version"], "99.0.0")
        self.assertTrue(Path(pending["backup"]).exists())
        self.assertTrue(AuditLog.objects.filter(action="UPDATE_STARTED").exists())

    def test_tampered_release_rejected(self):
        with self.assertRaisesMessage(ValidationError, "damaged or modified"):
            self._stage(self._release("99.0.0", self.key, tamper=True))

    def test_wrong_signer_rejected(self):
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

        with self.assertRaisesMessage(ValidationError, "signature"):
            self._stage(self._release("99.0.0", Ed25519PrivateKey.generate()))

    def test_older_version_rejected(self):
        with self.assertRaisesMessage(ValidationError, "not newer"):
            self._stage(self._release("0.0.1", self.key))

    def test_version_compare(self):
        from .services.updates import is_newer

        self.assertTrue(is_newer("1.10.0", "1.9.9"))
        self.assertFalse(is_newer("1.2.0", "1.2.0"))


class StaffWorkflowRetentionTests(TestCase):
    """Library Staff complete phases 1-3; the approver decides retention at Phase 4."""

    def setUp(self):
        load_defaults()
        s = SiteSettings.load()
        s.setup_completed = True
        s.save()
        self.staff = User.objects.create_user("staff", password="x", role=Role.LIBRARY_STAFF)
        self.admin = User.objects.create_user("admin", password="x", role=Role.ADMIN)

    def _ready_doc(self):
        c = self.client
        c.force_login(self.staff)
        c.post(reverse("document_new"), {"title": "Annual report 2026", "category": Category.objects.get(code="ANR").pk,
                                          "source_type": "DIGITAL", "received_date": date.today().isoformat(),
                                          "received_from": "Registrar"})
        doc = Document.objects.latest("id")
        with override_settings(MEDIA_ROOT=TMP):
            c.post(reverse("document_upload", args=[doc.pk]), {"files": [SimpleUploadedFile("r.txt", b"annual report")]})
            r = c.post(reverse("document_digitized", args=[doc.pk]))
            self.assertEqual(r.status_code, 302)
            page = c.get(reverse("document_metadata", args=[doc.pk]))
            self.assertEqual(page.status_code, 200)
            self.assertNotContains(page, 'name="retention_years"')  # retention is the approver's decision
            c.post(reverse("document_metadata", args=[doc.pk]), {
                "title": doc.title, "category": doc.category_id, "description": "Annual report", "document_year": "2025-26",
                "language": "English", "custodian": self.staff.pk, "confidentiality": "GENERAL", "submit": "1"})
        doc.refresh_from_db()
        self.assertEqual(doc.status, Status.PENDING_APPROVAL)
        self.assertTrue(self.admin.notifications.exists())
        return doc

    def test_staff_completes_phases_and_admin_sets_years(self):
        doc = self._ready_doc()
        self.client.force_login(self.admin)
        with override_settings(MEDIA_ROOT=TMP):
            self.client.post(reverse("document_decide", args=[doc.pk]), {"decision": "approve", "retention": "10"})
        doc.refresh_from_db()
        self.assertEqual(doc.status, Status.ACTIVE)
        self.assertFalse(doc.permanent)
        self.assertEqual(doc.retention_years, 10)
        self.assertEqual(doc.expiry_date.year, doc.received_date.year + 10)
        self.assertTrue(AuditLog.objects.filter(action="APPROVED", details__contains="retain 10 years").exists())

    def test_admin_sets_permanent_and_date(self):
        doc = self._ready_doc()
        self.client.force_login(self.admin)
        with override_settings(MEDIA_ROOT=TMP):
            self.client.post(reverse("document_decide", args=[doc.pk]), {"decision": "approve", "retention": "permanent"})
        doc.refresh_from_db()
        self.assertTrue(doc.permanent)
        self.assertIsNone(doc.expiry_date)
        doc2 = self._ready_doc()
        self.client.force_login(self.admin)
        until = date.today().replace(year=date.today().year + 3)
        with override_settings(MEDIA_ROOT=TMP):
            self.client.post(reverse("document_decide", args=[doc2.pk]),
                             {"decision": "approve", "retention": "date", "retention_until": until.isoformat()})
        doc2.refresh_from_db()
        self.assertEqual(doc2.expiry_date, until)

    def test_staff_cannot_approve_or_request_disposal(self):
        doc = self._ready_doc()
        self.assertEqual(self.client.post(reverse("document_decide", args=[doc.pk]), {"decision": "approve"}).status_code, 403)
        self.assertFalse(self.staff.can_request_disposal)


class V120FeatureTests(TestCase):
    """Permission-required access, bulk upload, backup permission, invoice register."""

    def setUp(self):
        load_defaults()
        s = SiteSettings.load()
        s.setup_completed = True
        s.save()
        self.admin = User.objects.create_user("admin", password="x", role=Role.ADMIN)
        self.sup = User.objects.create_user("super", password="x", role=Role.SUPER_LIBRARIAN)
        self.staff = User.objects.create_user("staff", password="x", role=Role.LIBRARY_STAFF)
        self.other = User.objects.create_user("other", password="x", role=Role.LIBRARY_STAFF)

    def _approved_doc(self, access):
        with override_settings(MEDIA_ROOT=TMP):
            doc = L.register_document(Document(title="Vendor agreement", category=Category.objects.get(code="POL"),
                                               description="d", document_year="2025"), self.staff)
            L.add_file(doc, SimpleUploadedFile("a.pdf", make_pdf("agreement")), self.staff)
            L.submit_for_approval(doc, self.staff)
            self.client.force_login(self.sup)
            self.client.post(reverse("document_decide", args=[doc.pk]), {"decision": "approve", "access": access})
        doc.refresh_from_db()
        return doc

    def test_permission_required_flow(self):
        doc = self._approved_doc("CONFIDENTIAL")
        self.assertEqual(doc.confidentiality, Confidentiality.CONFIDENTIAL)
        self.assertTrue(AuditLog.objects.filter(action="APPROVED", details__contains="permission required").exists())
        f = doc.files.first()
        self.client.force_login(self.other)
        page = self.client.get(doc.get_absolute_url())
        self.assertContains(page, "Send permission request")
        self.assertContains(page, "a.pdf")  # file name visible, content locked
        with override_settings(MEDIA_ROOT=TMP):
            r = self.client.get(reverse("file_view", args=[f.pk]))
            self.assertEqual(r.status_code, 403)
            self.assertContains(r, "Send permission request", status_code=403)
            r = self.client.get(reverse("file_download", args=[f.pk]))
            self.assertEqual(r.status_code, 403)
        self.client.post(reverse("access_request", args=[doc.pk]), {"purpose": "Audit"})
        ar = AccessRequest.objects.get(document=doc)
        self.assertTrue(self.sup.notifications.filter(message__contains="Permission request").exists())
        self.client.force_login(self.sup)
        self.client.post(reverse("access_decide", args=[ar.pk]), {"decision": "approve", "days": "3"})
        ar.refresh_from_db()
        self.assertEqual((ar.valid_until - ar.decided_at).days, 3)
        self.client.force_login(self.other)
        with override_settings(MEDIA_ROOT=TMP):
            self.assertEqual(self.client.get(reverse("file_download", args=[f.pk])).status_code, 200)

    def test_open_access_set_at_approval(self):
        doc = self._approved_doc("GENERAL")
        self.client.force_login(self.other)
        with override_settings(MEDIA_ROOT=TMP):
            self.assertEqual(self.client.get(reverse("file_download", args=[doc.files.first().pk])).status_code, 200)

    def test_backup_permission(self):
        self.client.force_login(self.staff)
        self.assertEqual(self.client.get(reverse("backups")).status_code, 403)
        self.client.force_login(self.sup)  # super librarian manages staff accounts
        r = self.client.post(reverse("user_edit", args=[self.staff.pk]), {
            "username": "staff", "role": "STAFF", "can_backup": "on", "is_active": "on", "first_name": "S"})
        self.assertEqual(r.status_code, 302)
        self.staff.refresh_from_db()
        self.assertTrue(self.staff.can_backup)
        # super librarian cannot create administrators
        r = self.client.post(reverse("user_new"), {"username": "x", "role": "ADMIN", "password": "Strong#Pass2026", "is_active": "on"})
        self.assertFalse(User.objects.filter(username="x").exists())
        self.client.force_login(self.staff)
        with override_settings(BACKUP_DIR=settings.BACKUP_DIR.__class__(tempfile.mkdtemp())):
            self.assertEqual(self.client.get(reverse("backups")).status_code, 200)
            r = self.client.post(reverse("backup_now"))
            self.assertEqual(r.status_code, 302)
        self.assertTrue(AuditLog.objects.filter(action="BACKUP", username="staff").exists())

    def _zip(self, rows_override=None, drop_file=False):
        import zipfile

        import openpyxl

        from .services import bulk as B

        wb = openpyxl.load_workbook(io.BytesIO(B.build_template()))
        ws = wb["Documents"]
        if rows_override is not None:
            for (col, val) in rows_override:
                ws[col] = val
        buf = io.BytesIO()
        wb.save(buf)
        z = io.BytesIO()
        with zipfile.ZipFile(z, "w") as zf:
            zf.writestr("metadata.xlsx", buf.getvalue())
            zf.writestr("minutes_2025_08_12.pdf", make_pdf("minutes"))
            if not drop_file:
                zf.writestr("invoice_KLBH_389.pdf", make_pdf("invoice"))
        return SimpleUploadedFile("batch.zip", z.getvalue(), content_type="application/zip")

    def test_bulk_upload_validation_and_import(self):
        from .models import BulkImport, InvoiceRecord
        from .services import bulk as B

        self.client.force_login(self.staff)
        self.assertEqual(self.client.get(reverse("bulk_template")).status_code, 200)
        self.assertEqual(self.client.get(reverse("bulk_sample")).status_code, 200)
        with override_settings(DATA_DIR=settings.DATA_DIR.__class__(tempfile.mkdtemp())):
            # missing file -> invalid, nothing imported
            self.client.post(reverse("bulk_upload"), {"zipfile": self._zip(drop_file=True)})
            bad = BulkImport.objects.latest("id")
            self.assertEqual(bad.state, BulkImport.State.INVALID)
            self.assertIn("not in the ZIP", bad.report)
            # good batch
            self.client.post(reverse("bulk_upload"), {"zipfile": self._zip()})
            b = BulkImport.objects.latest("id")
            self.assertEqual(b.state, BulkImport.State.VALIDATED)
            self.assertEqual(b.total_rows, 2)
            with override_settings(MEDIA_ROOT=TMP):
                B.start_import(b, submit_for_approval=True, background=False)
        b.refresh_from_db()
        self.assertEqual((b.state, b.imported, b.failed), (BulkImport.State.DONE, 2, 0))
        docs = Document.objects.order_by("id")
        self.assertEqual(docs.count(), 2)
        self.assertTrue(all(d.status == Status.PENDING_APPROVAL for d in docs))
        inv = InvoiceRecord.objects.get()
        self.assertEqual(inv.no_of_books, 597)  # 61584-62180
        self.assertEqual(int(inv.amount), 303974)
        self.assertEqual(inv.document.reference_number, "KLBH/IN/389/2025-26")
        # bulk approval by super librarian
        self.client.force_login(self.sup)
        with override_settings(MEDIA_ROOT=TMP):
            self.client.post(reverse("approve_selected"), {"ids": [d.pk for d in docs], "retention": "10", "access": "CONFIDENTIAL"})
        self.assertTrue(all(d.status == Status.ACTIVE and d.retention_years == 10 and d.confidentiality == "CONFIDENTIAL"
                            for d in Document.objects.all()))

    def test_invoice_register_import_select_edit_export(self):
        import json

        import openpyxl

        from .models import InvoiceRecord

        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "2025-26"
        ws.append(["Index of Library Book Purchase Invoice Details (2025-2026)"])
        ws.append(["Sl No", "Source", None, "Bill No.", "Bill Date", "Invoice Price"])
        ws.append([1, "Book Paradise ", "61356-61360", 10008, "02.04.2025", 7364])
        ws.append([2, "KL Book House ", " 61374-61380", "KLBH/IN/77/2025-26", "14.05.2025", 35180])
        ws.append([3, "IELTS ", " 61383-61452", "Donated by IELTS", "04.06.2025", "Donated "])
        ws.append([None, None, None, None, "Total", "=SUM(F3:F5)"])
        buf = io.BytesIO()
        wb.save(buf)
        self.client.force_login(self.staff)
        self.client.post(reverse("invoice_import"), {"workbook": SimpleUploadedFile("index.xlsx", buf.getvalue())})
        self.assertEqual(InvoiceRecord.objects.count(), 3)
        bp = InvoiceRecord.objects.get(vendor="Book Paradise")
        self.assertEqual((bp.financial_year, bp.no_of_books, int(bp.amount)), ("2025-26", 5, 7364))
        self.assertEqual(InvoiceRecord.objects.get(vendor="IELTS").acquisition_type, "DONATION")
        r = self.client.get(reverse("invoices"), {"fy": "2025-26"})
        self.assertContains(r, "42,544.00")  # 7364 + 35180
        self.assertContains(r, "82")  # books 5 + 7 + 70
        # selected export
        kl = InvoiceRecord.objects.get(vendor="KL Book House")
        for fmt in ("xlsx", "pdf", "docx"):
            resp = self.client.get(reverse("invoice_export", args=[fmt]), {"ids": f"{bp.pk},{kl.pk}"})
            self.assertEqual(resp.status_code, 200, fmt)
            self.assertGreater(len(resp.content), 1000)
        x = openpyxl.load_workbook(io.BytesIO(self.client.get(reverse("invoice_export", args=["xlsx"]), {"ids": f"{bp.pk},{kl.pk}"}).content))
        self.assertEqual(x["Invoices"].max_row, 6)  # 2 title rows + header + 2 rows + total
        # inline edit
        r = self.client.post(reverse("invoice_save"), data=json.dumps({"changes": {str(bp.pk): {"amount": "7400", "po_number": "PO/12"}},
                             "new": [{"vendor": "Amazon.in", "amount": "515", "invoice_date": "15-11-2025", "accession_range": "61500"}]}),
                             content_type="application/json")
        self.assertTrue(r.json()["ok"], r.json())
        bp.refresh_from_db()
        self.assertEqual((int(bp.amount), bp.po_number), (7400, "PO/12"))
        az = InvoiceRecord.objects.get(vendor="Amazon.in")
        self.assertEqual((az.financial_year, az.no_of_books), ("2025-26", 1))
        self.assertTrue(AuditLog.objects.filter(action="INVOICE_CHANGE", details__contains="7364").exists())
        # re-import does not duplicate
        buf.seek(0)
        self.client.post(reverse("invoice_import"), {"workbook": SimpleUploadedFile("index.xlsx", buf.getvalue())})
        self.assertEqual(InvoiceRecord.objects.filter(vendor="KL Book House").count(), 1)

    def test_accession_parser(self):
        from .models import parse_accession_range

        self.assertEqual(parse_accession_range("61356-61360")[0], 5)
        self.assertEqual(parse_accession_range("35944-46")[0], 3)
        self.assertEqual(parse_accession_range("61373")[0], 1)
        self.assertEqual(parse_accession_range("100-105, 110")[0], 7)
        self.assertIsNone(parse_accession_range("Donated")[0])


SAMPLE_INVOICE = """K L BOOK HOUSE
No 12, 3rd Cross, Gandhinagar, Bengaluru
TAX INVOICE
Invoice No : KLBH/IN 77/2025-26 Date : 16-08-2025
P.O. No : PO/FY25-26/222 Dated : 08-07-2025
Sl ISBN Title Qty Currency Price Amount
1 9789352135172 Data Structures in C 2 Rs 450.00 900.00
2 9780071808552 Database System Concepts 3 Rs 1,200.00 3,600.00
3 9789386551 Operating Systems Principles 1 Rs 750.00 750.00
4 9789353163 Computer Networks Top Down 4 Rs 500.00 2,000.00
Total No. of Books : 10
Total 7,250.00
Less Discount 10% 725.00
NET AMOUNT 6,525.00
Rupees Six Thousand Five Hundred Twenty Five Only
"""


def make_text_pdf(text):
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas

    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    y = 800
    for line in text.splitlines():
        c.drawString(40, y, line)
        y -= 16
    c.save()
    return buf.getvalue()


class V130InvoiceReadingTests(TestCase):
    """1.3.0: permission required also for the uploader, invoices read automatically, built-in OCR."""

    def setUp(self):
        load_defaults()
        s = SiteSettings.load()
        s.setup_completed = True
        s.save()
        self.sup = User.objects.create_user("super", password="x", role=Role.SUPER_LIBRARIAN)
        self.staff = User.objects.create_user("staff", password="x", role=Role.LIBRARY_STAFF)

    def test_uploader_needs_permission_too(self):
        with override_settings(MEDIA_ROOT=TMP):
            doc = L.register_document(Document(title="Agreement", category=Category.objects.get(code="POL"),
                                               description="d", document_year="2025"), self.staff)
            L.add_file(doc, SimpleUploadedFile("a.pdf", make_pdf("agreement")), self.staff)
            L.submit_for_approval(doc, self.staff)
            L.approve(doc, self.sup, access="CONFIDENTIAL")
            doc.refresh_from_db()
            self.assertEqual((doc.created_by, doc.custodian), (self.staff, self.staff))
            self.assertFalse(L.can_open(self.staff, doc))
            self.client.force_login(self.staff)
            f = doc.files.first()
            self.assertEqual(self.client.get(reverse("file_download", args=[f.pk])).status_code, 403)
            self.assertEqual(self.client.get(reverse("file_view", args=[f.pk])).status_code, 403)
            self.assertTrue(L.can_open(self.sup, doc))

    def test_reader_on_text(self):
        from .services.invoice_reader import _tidy_vendor, extract

        r = extract(SAMPLE_INVOICE)
        self.assertEqual(r["invoice_no"], "KLBH/IN 77/2025-26")
        self.assertEqual(r["invoice_date"], date(2025, 8, 16))
        self.assertEqual(r["po_number"], "PO/FY25-26/222")
        self.assertEqual(r["po_date"], date(2025, 7, 8))
        self.assertEqual((r["no_of_titles"], r["no_of_books"]), (4, 10))
        self.assertEqual(str(r["amount"]), "6525.00")
        self.assertIn("words", r["how"]["amount"])
        self.assertEqual(_tidy_vendor("4 MPP HOUSE"), "MPP House")
        # a vendor already in the register is recognised even when spaced differently
        self.assertEqual(extract(SAMPLE_INVOICE, ["KL Book House"])["vendor"], "KL Book House")

    def test_upload_read_review(self):
        from unittest import mock

        from .services import invoice_jobs as J

        self.client.force_login(self.staff)
        real = J.start_upload
        with override_settings(MEDIA_ROOT=TMP, DATA_DIR=settings.DATA_DIR.__class__(TMP)), \
                mock.patch.object(J, "start_upload", lambda b, submit_for_approval=True: real(b, submit_for_approval, background=False)):
            r = self.client.post(reverse("invoice_upload"), {
                "files": [SimpleUploadedFile("kl_77.pdf", make_text_pdf(SAMPLE_INVOICE))], "submit": "1"})
        batch = BulkImport.objects.get(kind="invoices")
        self.assertRedirects(r, reverse("invoice_upload_detail", args=[batch.pk]))
        self.assertEqual((batch.state, batch.imported, batch.failed), ("DONE", 1, 0))
        rec = InvoiceRecord.objects.get()
        self.assertEqual((rec.invoice_no, rec.no_of_titles, rec.no_of_books, str(rec.amount), rec.financial_year),
                         ("KLBH/IN 77/2025-26", 4, 10, "6525.00", "2025-26"))
        self.assertTrue(rec.needs_review)
        self.assertEqual(rec.source, "auto")
        doc = rec.document
        self.assertEqual(doc.status, "PENDING_APPROVAL")  # metadata filled from the invoice, so it could be submitted
        self.assertEqual((doc.reference_number, doc.document_year, doc.document_date), ("KLBH/IN 77/2025-26", "2025-26", date(2025, 8, 16)))
        self.assertIn("10 volumes", doc.description)
        page = self.client.get(reverse("invoice_upload_detail", args=[batch.pk]))
        self.assertContains(page, "KLBH/IN 77/2025-26")
        self.assertContains(page, "6,525.00")
        self.assertContains(self.client.get(reverse("invoices")), "read automatically and should be checked")
        with override_settings(MEDIA_ROOT=TMP):
            rv = self.client.get(reverse("invoice_review", args=[rec.pk]))
        self.assertContains(rv, "How each value was found")
        self.assertEqual(rec.vendor, "K L Book House")
        self.assertEqual(rec.material_type, "BOOKS")  # ISBNs on the invoice
        self.assertEqual(doc.material_type, "BOOKS")
        data = {"vendor": "K.L. Book House", "material_type": "BOOKS", "invoice_no": rec.invoice_no, "invoice_date": "2025-08-16", "po_number": rec.po_number,
                "po_date": "2025-07-08", "accession_range": "", "no_of_books": "10", "no_of_titles": "4", "amount": "6525.00",
                "acquisition_type": "PURCHASE", "financial_year": "2025-26", "remarks": ""}
        self.client.post(reverse("invoice_review", args=[rec.pk]), data)
        rec.refresh_from_db()
        self.assertFalse(rec.needs_review)
        self.assertEqual((rec.vendor, rec.reviewed_by), ("K.L. Book House", self.staff))
        # reading the same document again does not create a second register entry
        with override_settings(MEDIA_ROOT=TMP):
            J.read_into_register(doc, self.staff)
        self.assertEqual(InvoiceRecord.objects.count(), 1)

    def test_excel_invoice(self):
        import openpyxl

        from .services.invoice_reader import read_invoice

        wb = openpyxl.Workbook()
        ws = wb.active
        for row in SAMPLE_INVOICE.splitlines():
            ws.append([row])
        buf = io.BytesIO()
        wb.save(buf)
        res = read_invoice(buf.getvalue(), "inv.xlsx")
        inv = res["invoices"][0]
        self.assertEqual((inv["invoice_no"], inv["no_of_books"], str(inv["amount"])), ("KLBH/IN 77/2025-26", 10, "6525.00"))

    def test_ocr_package_checksum(self):
        from .services import ocr_setup as O

        bad = settings.DATA_DIR.__class__(TMP) / "bad.zip"
        bad.write_bytes(b"not the real package")
        with self.assertRaises(ValueError):
            O.install_from_zip(bad)


class V140InvoiceTypeTests(TestCase):
    """1.4.0: invoices uploaded the ordinary way are read; Books / Databases / Journals / Magazines / Misc."""

    def setUp(self):
        load_defaults()
        s = SiteSettings.load()
        s.setup_completed = True
        s.save()
        self.sup = User.objects.create_user("super", password="x", role=Role.SUPER_LIBRARIAN)
        self.staff = User.objects.create_user("staff", password="x", role=Role.LIBRARY_STAFF)
        self.inv = Category.objects.get(code="INV")

    def test_guess_material(self):
        from .services.invoice_reader import guess_material

        self.assertEqual(guess_material("Annual subscription 2025 Journal of Law ISSN 0019-5731")[0], "JOURNALS")
        self.assertEqual(guess_material("Renewal of online database access J-Gate, IP based")[0], "DATABASES")
        self.assertEqual(guess_material("India Today magazine 52 issues")[0], "MAGAZINES")
        self.assertEqual(guess_material("Toner cartridge 2 nos")[0], "MISC")
        self.assertEqual(guess_material(SAMPLE_INVOICE, 4)[0], "BOOKS")

    def test_register_form_has_invoice_for(self):
        self.client.force_login(self.staff)
        r = self.client.get(reverse("document_new"))
        self.assertContains(r, 'name="material_type"')
        self.assertContains(r, "Journals")

    def test_ordinary_upload_is_read_and_typed(self):
        self.client.force_login(self.staff)
        with override_settings(MEDIA_ROOT=TMP):
            r = self.client.post(reverse("document_new"), {
                "title": "Journal subscription invoice", "category": self.inv.pk, "material_type": "JOURNALS",
                "source_type": "PHYSICAL", "received_date": "2025-08-20"})
            doc = Document.objects.get(title="Journal subscription invoice")
            self.assertEqual(doc.material_type, "JOURNALS")
            self.client.post(reverse("document_upload", args=[doc.pk]),
                             {"files": [SimpleUploadedFile("inv.pdf", make_text_pdf(SAMPLE_INVOICE))]})
        rec = InvoiceRecord.objects.get(document=doc)
        self.assertEqual(rec.material_type, "JOURNALS")  # the staff member's choice wins over the guess
        self.assertEqual((rec.no_of_books, str(rec.amount)), (10, "6525.00"))
        page = self.client.get(reverse("invoices"), {"material": "JOURNALS"})
        self.assertContains(page, "KLBH/IN 77/2025-26")
        self.assertContains(page, "Invoice type-wise")
        self.assertNotContains(self.client.get(reverse("invoices"), {"material": "BOOKS"}), "KLBH/IN 77/2025-26")
        with override_settings(MEDIA_ROOT=TMP):
            for fmt in ("xlsx", "pdf", "docx"):
                self.assertEqual(self.client.get(reverse("invoice_export", args=[fmt])).status_code, 200)

    def test_catch_up_existing_invoice_documents(self):
        from .services import invoice_jobs as J

        with override_settings(MEDIA_ROOT=TMP):
            doc = L.register_document(Document(title="Old invoice", category=self.inv), self.staff)
            L.add_file(doc, SimpleUploadedFile("old.pdf", make_text_pdf(SAMPLE_INVOICE)), self.staff)
            self.assertEqual(list(J.unread_invoice_documents()), [doc])
            self.client.force_login(self.staff)
            self.assertContains(self.client.get(reverse("invoices")), "not in this register yet")
            J.read_unread_documents(self.staff, background=False)
        self.assertEqual(InvoiceRecord.objects.filter(document=doc).count(), 1)
        self.assertEqual(J.unread_invoice_documents().count(), 0)
        doc.refresh_from_db()
        self.assertEqual(doc.material_type, "BOOKS")


class V141ScanSafetyTests(TestCase):
    def test_isbn_is_never_an_amount(self):
        from .models import sane_amount
        from .services.invoice_reader import money_values

        self.assertEqual(money_values("13 9781484276471 APR R1499.00 2 15.0% 2,548.50"), [Decimal("1499.00"), Decimal("15.0"), Decimal("2548.50")])
        self.assertIsNone(sane_amount(9781484276471))
        self.assertEqual(sane_amount("163582.54"), Decimal("163582.54"))
        load_defaults()
        u = User.objects.create_user("s", password="x", role=Role.LIBRARY_STAFF)
        r = InvoiceRecord.objects.create(vendor="X", amount=9781484276471, invoice_no=None, created_by=u)
        r.refresh_from_db()
        self.assertEqual((r.amount, r.invoice_no), (None, ""))

    def test_vendor_from_footer_and_signature(self):
        from .services.invoice_reader import _find_vendor

        text = "INVOICE\nfs BOOK PARADISE a 'eal\nRegd Office : 400/1, 4th Cross, Jayanagar\n* BOOK PARADISE ="
        self.assertEqual(_find_vendor(text, [])[0], "Book Paradise")
        self.assertEqual(_find_vendor("UN Keep Learning\nTerms And Conditions: For KL BOOK HOUSE", [])[0], "KL Book House")
