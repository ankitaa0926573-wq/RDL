"""Clear impossible amounts (e.g. an ISBN read as the invoice total from a faint scan).
They made every page that lists documents fail with 'Server Error (500)'."""
from django.db import migrations

LIMIT = 9999999999


def repair(apps, schema_editor):
    with schema_editor.connection.cursor() as c:
        for table in ("repository_document", "repository_invoicerecord"):
            c.execute(f"UPDATE {table} SET amount = NULL WHERE amount > %s OR amount < %s", [LIMIT, -LIMIT])
        c.execute("UPDATE repository_invoicerecord SET needs_review = %s WHERE amount IS NULL AND source = 'auto'", [True])


class Migration(migrations.Migration):
    dependencies = [("repository", "0006_material_type")]
    operations = [migrations.RunPython(repair, migrations.RunPython.noop)]
