"""
Built-in OCR.

LDR carries its own copy of Tesseract OCR (Apache-2.0 licence) in the ``ocr/tesseract``
folder of the application, so scanned invoices and documents can be read without
installing anything separately.

Installations that do not yet have the folder fetch it once, automatically, from the
same website the updates come from (``downloads/LDR-OCR-win64.zip``). The file's SHA-256
is fixed below - this source file is part of the signed release - so a tampered
download is refused.
"""
import hashlib
import logging
import os
import re
import shutil
import threading
import urllib.request
import zipfile
from pathlib import Path

from django.conf import settings

log = logging.getLogger("ldr")

OCR_DIR = Path(settings.BASE_DIR) / "ocr" / "tesseract"
OCR_EXE = OCR_DIR / "tesseract.exe"
OCR_ZIP_NAME = "LDR-OCR-win64.zip"
OCR_ZIP_SHA256 = "e59f5d68426e9e2e6019ef8909cdc59a8e938f607dea6d5e53ecee832b45cb61"
OCR_ZIP_SIZE_MB = 42

_state = {"running": False, "message": "", "error": ""}
_lock = threading.Lock()


def bundled_exe():
    """Path of the built-in tesseract.exe (Windows) if present."""
    if os.name == "nt" and OCR_EXE.exists() and (OCR_DIR / "tessdata" / "eng.traineddata").exists():
        return OCR_EXE
    return None


OCR_PART_COUNT = 6  # published as small pieces .001 ... .006 (about 7 MB each) - easy to upload on GitHub's website


def part_names():
    return [f"{OCR_ZIP_NAME}.{i:03d}" for i in range(1, OCR_PART_COUNT + 1)]


def downloads_url():
    from .updates import update_url

    base = (update_url() or "").strip()
    if not base:
        return ""
    return base.rsplit("/", 1)[0] + "/downloads/"


def zip_url():
    d = downloads_url()
    return d + part_names()[0] if d else ""


def status():
    from .extract import _tesseract

    tess = _tesseract()
    return {
        "available": tess is not None,
        "builtin": bundled_exe() is not None,
        "windows": os.name == "nt",
        "installing": _state["running"],
        "message": _state["message"],
        "error": _state["error"],
        "url": zip_url(),
    }


def install_from_zip(zip_path):
    """Check and unpack LDR-OCR-win64.zip into <LDR>/ocr/tesseract."""
    h = hashlib.sha256()
    with open(zip_path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    if h.hexdigest() != OCR_ZIP_SHA256:
        raise ValueError("The OCR package failed the integrity check (checksum mismatch) and was not installed.")
    target_root = OCR_DIR.parent
    tmp = target_root / "_installing"
    shutil.rmtree(tmp, ignore_errors=True)
    tmp.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_path) as zf:
        for name in zf.namelist():
            p = Path(name)
            if p.is_absolute() or ".." in p.parts or not name.startswith("tesseract/"):
                raise ValueError("Unexpected file in OCR package: " + name)
        zf.extractall(tmp)
    if OCR_DIR.exists():
        shutil.rmtree(OCR_DIR, ignore_errors=True)
    os.replace(tmp / "tesseract", OCR_DIR)
    shutil.rmtree(tmp, ignore_errors=True)
    log.info("Built-in OCR installed in %s", OCR_DIR)


def _fetch(url, out, append=False):
    req = urllib.request.Request(url, headers={"User-Agent": f"LDR/{settings.LDR_VERSION}"})
    with urllib.request.urlopen(req, timeout=60) as r, open(out, "ab" if append else "wb") as fh:
        shutil.copyfileobj(r, fh, 1 << 20)


def download_and_install():
    base = downloads_url()
    if not base:
        raise ValueError("No update website is set, so the OCR package cannot be downloaded. "
                         "Copy the 'ocr' folder from the LDR download into the LDR folder instead.")
    dest = Path(settings.DATA_DIR) / "updates"
    dest.mkdir(parents=True, exist_ok=True)
    part = dest / (OCR_ZIP_NAME + ".part")
    _state["message"] = "Downloading OCR package (about %d MB)…" % OCR_ZIP_SIZE_MB
    sources = [[base + n for n in part_names()], [base + OCR_ZIP_NAME]]
    gh = re.match(r"https://([^./]+)\.github\.io/([^/]+)/", base)
    if gh:  # also accepted as a GitHub Release file (Releases allow large files)
        sources.append([f"https://github.com/{gh.group(1)}/{gh.group(2)}/releases/latest/download/{OCR_ZIP_NAME}"])
    errors = []
    try:
        for urls in sources:
            try:
                for i, u in enumerate(urls):
                    _state["message"] = f"Downloading OCR package (part {i + 1} of {len(urls)})…"
                    _fetch(u, part, append=i > 0)
                _state["message"] = "Installing OCR…"
                install_from_zip(part)
                return
            except Exception as exc:
                errors.append(f"{urls[0].rsplit('/', 1)[-1]}: {exc}")
        raise ValueError("The OCR package could not be downloaded from the LDR website (" + "; ".join(errors) + "). "
                         "Copy the 'ocr' folder from the LDR download into the LDR folder instead.")
    finally:
        try:
            part.unlink()
        except OSError:
            pass


def ensure_builtin_ocr(background=True):
    """Windows: if no OCR is available, fetch and install the built-in one. Safe to call often."""
    if os.name != "nt" or not settings.OCR_ENABLED:
        return False
    from .extract import _tesseract

    if _tesseract() is not None:
        return False
    with _lock:
        if _state["running"]:
            return True
        _state.update(running=True, error="", message="Starting…")

    def _job():
        try:
            download_and_install()
            _state["message"] = "Built-in OCR installed."
        except Exception as exc:
            log.warning("Built-in OCR could not be installed: %s", exc)
            _state["error"] = str(exc)
            _state["message"] = ""
        finally:
            _state["running"] = False

    if background:
        threading.Thread(target=_job, daemon=True, name="ldr-ocr-setup").start()
    else:
        _job()
    return True
