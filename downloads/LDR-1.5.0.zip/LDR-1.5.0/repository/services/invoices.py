"""
Invoice register: import of an existing "Index of Purchase Invoices" workbook,
statistics, and Excel / PDF / Word reports.
"""
import datetime as dt
import io
import re
from decimal import Decimal, InvalidOperation

from django.db.models import Count, Q, Sum
from django.utils import timezone

from ..models import AcquisitionType, InvoiceRecord, MaterialType, SiteSettings, financial_year_of, parse_accession_range

FY_RE = re.compile(r"(20\d\d)\s*[-–]\s*(20)?(\d\d)")


# ----------------------------------------------------------------------- parsing helpers
def parse_date(value):
    if value in (None, ""):
        return None
    if isinstance(value, dt.datetime):
        return value.date()
    if isinstance(value, dt.date):
        return value
    s = str(value).strip()
    for fmt in ("%d.%m.%Y", "%d-%m-%Y", "%d/%m/%Y", "%Y-%m-%d", "%d.%m.%y", "%d-%m-%y", "%d/%m/%y", "%d %b %Y", "%d %B %Y"):
        try:
            return dt.datetime.strptime(s, fmt).date()
        except ValueError:
            continue
    return None


def parse_amount(value):
    if value in (None, ""):
        return None
    if isinstance(value, (int, float, Decimal)):
        return Decimal(str(value)).quantize(Decimal("0.01"))
    s = re.sub(r"[^\d.\-]", "", str(value))
    if not s or s in ("-", "."):
        return None
    try:
        return Decimal(s).quantize(Decimal("0.01"))
    except InvalidOperation:
        return None


def guess_type(*texts):
    t = " ".join(str(x or "") for x in texts).lower()
    if "donat" in t or "gift" in t:
        return AcquisitionType.DONATION
    if "complimentary" in t or "free" in t:
        return AcquisitionType.COMPLIMENTARY
    if "no bill" in t:
        return AcquisitionType.OTHER
    return AcquisitionType.PURCHASE


def fy_from_text(text):
    m = FY_RE.search(str(text or ""))
    if not m:
        return ""
    return f"{m.group(1)}-{m.group(3)}"


def clean_text(v):
    if v is None:
        return ""
    if isinstance(v, float) and v == int(v):
        v = int(v)
    return re.sub(r"\s+", " ", str(v)).strip()


# ----------------------------------------------------------------------- import of an existing index
HEADER_MAP = {
    "vendor": ("source", "vendor", "supplier", "publisher", "agency"),
    "accession_range": ("acc", "accession"),
    "invoice_no": ("bill no", "invoice no", "bill number", "invoice number", "bill", "invoice"),
    "invoice_date": ("bill date", "invoice date", "date"),
    "amount": ("price", "amount", "value", "total"),
    "po_number": ("po no", "po number", "purchase order", "p.o"),
    "po_date": ("po date",),
    "no_of_titles": ("titles", "no of titles"),
    "no_of_books": ("books", "volumes", "copies", "no of books"),
    "remarks": ("remark", "note"),
}


def _field_for(label):
    l = label.lower().replace(".", "").strip()
    if not l:
        return None
    if "date" in l:
        return "po_date" if (l.startswith("po") or "purchase order" in l) else "invoice_date"
    if any(k in l for k in ("price", "amount", "value", "cost")) or l == "total":
        return "amount"
    if l.startswith("acc") or "accession" in l:
        return "accession_range"
    if any(k in l for k in ("source", "vendor", "supplier", "agency", "publisher")):
        return "vendor"
    if l.startswith("po") or "purchase order" in l:
        return "po_number"
    if "bill" in l or "invoice" in l:
        return "invoice_no"
    if "title" in l:
        return "no_of_titles"
    if any(k in l for k in ("book", "volume", "copies")):
        return "no_of_books"
    if "remark" in l or "note" in l:
        return "remarks"
    if l in ("invoice for", "material", "material type", "item type", "resource type", "category", "kind"):
        return "material_type"
    return None


def material_of(value, sheet_name=""):
    """'Journals', 'e-database', 'Magazine' ... -> MaterialType code. Book index sheets default to Books."""
    t = f"{clean_text(value)} ".lower()
    for code, words in (("DATABASES", ("database", "e-resource", "online")), ("JOURNALS", ("journal", "periodical")),
                        ("MAGAZINES", ("magazine", "newspaper")), ("MISC", ("misc", "other", "general")),
                        ("BOOKS", ("book",))):
        if any(w in t for w in words):
            return code
    s = (sheet_name or "").lower()
    for code, w in (("JOURNALS", "journal"), ("DATABASES", "database"), ("MAGAZINES", "magazine")):
        if w in s:
            return code
    return MaterialType.BOOKS


def _match_header(cells):
    """Return {field: column_index} if this row looks like a header row."""
    found = {}
    for idx, val in enumerate(cells):
        f = _field_for(clean_text(val))
        if f and f not in found:
            found[f] = idx
    if "vendor" in found and ("invoice_no" in found or "amount" in found):
        # some registers leave the accession column header empty (right after Source)
        nxt = found["vendor"] + 1
        if "accession_range" not in found and nxt < len(cells) and clean_text(cells[nxt]) == "" \
                and nxt not in found.values():
            found["accession_range"] = nxt
        return found
    return None


def import_index_workbook(fileobj, user, document=None):
    """Import every sheet of an invoice index workbook. Returns a summary dict."""
    import openpyxl

    wb = openpyxl.load_workbook(fileobj, data_only=True)
    created, skipped, sheets = 0, 0, []
    for ws in wb.worksheets:
        sheet_fy = fy_from_text(ws.title)
        header = None
        n_sheet = 0
        for row in ws.iter_rows(values_only=True):
            cells = list(row)
            if not any(c not in (None, "") for c in cells):
                continue
            title_fy = fy_from_text(" ".join(clean_text(c) for c in cells if c))
            h = _match_header(cells)
            if h:
                header = h
                continue
            if header is None:
                if title_fy:
                    sheet_fy = sheet_fy or title_fy
                continue

            def get(field):
                i = header.get(field)
                return cells[i] if i is not None and i < len(cells) else None

            vendor = clean_text(get("vendor"))
            if not vendor or vendor.lower() in ("total", "grand total") or "continue" in vendor.lower():
                continue
            inv_no = clean_text(get("invoice_no"))
            raw_amount = get("amount")
            inv_date = parse_date(get("invoice_date"))
            acc = clean_text(get("accession_range"))
            amount = parse_amount(raw_amount) if not isinstance(raw_amount, str) or re.search(r"\d", raw_amount or "") else None
            acq = guess_type(raw_amount if isinstance(raw_amount, str) else "", inv_no, vendor)
            if acq != AcquisitionType.PURCHASE and amount == 0:
                amount = None
            # the register's own year (sheet / title) wins; otherwise derive it from the bill date
            fy = sheet_fy or financial_year_of(inv_date)
            books, norm = parse_accession_range(acc)
            exists = InvoiceRecord.objects.filter(
                financial_year=fy, vendor__iexact=vendor, invoice_no=inv_no, accession_range=norm or acc
            ).exists()
            if exists:
                skipped += 1
                continue
            titles = get("no_of_titles")
            given_books = get("no_of_books")
            InvoiceRecord.objects.create(
                document=document,
                financial_year=fy,
                vendor=vendor,
                invoice_no=inv_no,
                invoice_date=inv_date,
                po_number=clean_text(get("po_number")),
                po_date=parse_date(get("po_date")),
                accession_range=norm or acc,
                no_of_titles=int(titles) if isinstance(titles, (int, float)) else None,
                no_of_books=int(given_books) if isinstance(given_books, (int, float)) else books,
                amount=amount,
                acquisition_type=acq,
                material_type=material_of(get("material_type"), sheet_name=ws.title),
                remarks=clean_text(get("remarks")),
                created_by=user,
            )
            created += 1
            n_sheet += 1
        if n_sheet:
            sheets.append(f"{ws.title}: {n_sheet}")
    return {"created": created, "skipped": skipped, "sheets": sheets}


# ----------------------------------------------------------------------- filtering & statistics
def filtered(params, ids=None):
    qs = InvoiceRecord.objects.select_related("document")
    if ids:
        return qs.filter(pk__in=ids)
    fy = params.get("fy", "")
    if fy:
        qs = qs.filter(financial_year=fy)
    vendor = params.get("vendor", "")
    if vendor:
        qs = qs.filter(vendor__iexact=vendor)
    if params.get("review"):
        qs = qs.filter(needs_review=True)
    mat = params.get("material", "")
    if mat:
        qs = qs.filter(material_type="" if mat == "NONE" else mat)
    typ = params.get("type", "")
    if typ:
        qs = qs.filter(acquisition_type=typ)
    q = (params.get("q") or "").strip()
    if q:
        qs = qs.filter(Q(vendor__icontains=q) | Q(invoice_no__icontains=q) | Q(po_number__icontains=q)
                       | Q(accession_range__icontains=q) | Q(remarks__icontains=q))
    d1, d2 = parse_date(params.get("from")), parse_date(params.get("to"))
    if d1:
        qs = qs.filter(invoice_date__gte=d1)
    if d2:
        qs = qs.filter(invoice_date__lte=d2)
    return qs


def totals(qs):
    agg = qs.aggregate(n=Count("id"), books=Sum("no_of_books"), titles=Sum("no_of_titles"), amount=Sum("amount"))
    agg["vendors"] = qs.values("vendor").distinct().count()
    agg["purchases"] = qs.filter(acquisition_type=AcquisitionType.PURCHASE).count()
    agg["donations"] = qs.exclude(acquisition_type=AcquisitionType.PURCHASE).count()
    for k in ("books", "titles", "amount"):
        agg[k] = agg[k] or 0
    return agg


def by_vendor(qs):
    return list(qs.values("vendor").annotate(n=Count("id"), books=Sum("no_of_books"), amount=Sum("amount"))
                .order_by("-amount", "vendor"))


def by_material(qs):
    """Books / databases / journals / magazines / miscellaneous - in that order, with totals."""
    labels = dict(MaterialType.choices)
    rows = {r["material_type"]: r for r in qs.values("material_type").annotate(
        n=Count("id"), books=Sum("no_of_books"), titles=Sum("no_of_titles"), amount=Sum("amount"))}
    out = []
    for code in [c for c, _ in MaterialType.choices] + [""]:
        r = rows.get(code)
        if r or code:
            r = r or {"n": 0, "books": 0, "titles": 0, "amount": 0}
            out.append({"code": code or "NONE", "label": labels.get(code, "Not set"), "n": r["n"],
                        "books": r["books"] or 0, "titles": r["titles"] or 0, "amount": r["amount"] or 0})
    return out


def by_year(qs):
    return list(qs.values("financial_year").annotate(n=Count("id"), books=Sum("no_of_books"), amount=Sum("amount"),
                                                     vendors=Count("vendor", distinct=True))
                .order_by("-financial_year"))


def describe_filters(params, ids=None):
    if ids:
        return f"{len(ids)} selected invoices"
    bits = []
    if params.get("fy"):
        bits.append(f"Financial year {params['fy']}")
    if params.get("vendor"):
        bits.append(f"Vendor: {params['vendor']}")
    if params.get("type"):
        bits.append(dict(AcquisitionType.choices).get(params["type"], params["type"]))
    if params.get("from") or params.get("to"):
        bits.append(f"Dates {params.get('from') or '…'} to {params.get('to') or '…'}")
    if params.get("q"):
        bits.append(f"Search '{params['q']}'")
    if params.get("review"):
        bits.append("Read automatically - to be checked")
    if params.get("material"):
        bits.append(dict(MaterialType.choices).get(params["material"], "Invoice type not set"))
    return "; ".join(bits) or "All invoices"


def money(v):
    if v in (None, ""):
        return ""
    v = Decimal(v)
    # Indian digit grouping 12,34,567.00
    s = f"{v:.2f}"
    whole, frac = s.split(".")
    neg = whole.startswith("-")
    whole = whole.lstrip("-")
    if len(whole) > 3:
        head, tail = whole[:-3], whole[-3:]
        groups = []
        while len(head) > 2:
            groups.insert(0, head[-2:])
            head = head[:-2]
        if head:
            groups.insert(0, head)
        whole = ",".join(groups + [tail])
    return ("-" if neg else "") + whole + "." + frac


COLUMNS = [
    ("Sl", None), ("FY", "financial_year"), ("Vendor / source", "vendor"), ("Accession no(s).", "accession_range"),
    ("Books", "no_of_books"), ("Titles", "no_of_titles"), ("Invoice no.", "invoice_no"), ("Invoice date", "invoice_date"),
    ("PO no.", "po_number"), ("PO date", "po_date"), ("Amount (Rs)", "amount"), ("Type", "acquisition_type"),
    ("Invoice for", "material_type"),
]


def _cell(rec, attr):
    v = getattr(rec, attr)
    if attr == "acquisition_type":
        return rec.get_acquisition_type_display()
    if attr == "material_type":
        return rec.get_material_type_display() if rec.material_type else ""
    if isinstance(v, dt.date):
        return v.strftime("%d-%m-%Y")
    return "" if v is None else v


# ----------------------------------------------------------------------- exports
def export_excel(qs, title):
    import openpyxl
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    from openpyxl.utils import get_column_letter

    site = SiteSettings.load()
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Invoices"
    thin = Side(style="thin", color="BBBBBB")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    head_fill = PatternFill("solid", fgColor="0F5C63")
    ws.append([f"{site.institution_name or site.library_name} - Index of Purchase Invoices"])
    ws.append([title + f"  (generated {timezone.localdate():%d-%m-%Y})"])
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=len(COLUMNS))
    ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=len(COLUMNS))
    ws["A1"].font = Font(bold=True, size=14)
    ws["A2"].font = Font(italic=True, color="555555")
    ws.append([c[0] for c in COLUMNS])
    for c in ws[3]:
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = head_fill
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        c.border = border
    first = 4
    for i, rec in enumerate(qs, 1):
        row = [i] + [_cell(rec, a) for _, a in COLUMNS[1:]]
        if rec.amount is not None:
            row[10] = float(rec.amount)
        ws.append(row)
    last = ws.max_row
    ws.append(["", "", "", "Total", f"=SUM(E{first}:E{last})" if last >= first else 0,
               f"=SUM(F{first}:F{last})" if last >= first else 0, "", "", "", "",
               f"=SUM(K{first}:K{last})" if last >= first else 0, "", ""])
    for c in ws[ws.max_row]:
        c.font = Font(bold=True)
    for row in ws.iter_rows(min_row=3, max_row=ws.max_row):
        for c in row:
            c.border = border
    for r in range(first, ws.max_row + 1):
        ws.cell(r, 11).number_format = "#,##,##0.00"
    widths = [5, 10, 32, 18, 8, 8, 22, 12, 14, 12, 15, 14, 18]
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.freeze_panes = "A4"

    # summary sheet
    sm = wb.create_sheet("Summary")
    t = totals(qs)
    sm.append(["Summary", title])
    sm["A1"].font = Font(bold=True, size=13)
    for label, val in (("Number of invoices", t["n"]), ("Number of vendors", t["vendors"]), ("Total books (volumes)", t["books"]),
                       ("Total titles", t["titles"]), ("Total amount (Rs)", float(t["amount"])),
                       ("Purchases", t["purchases"]), ("Donations / other", t["donations"])):
        sm.append([label, val])
    sm.append([])
    sm.append(["Summary by invoice type (books / databases / journals / magazines / miscellaneous)"])
    sm.cell(sm.max_row, 1).font = Font(bold=True)
    sm.append(["Invoice for", "Invoices", "Titles", "Books / volumes", "Amount (Rs)"])
    for c in sm[sm.max_row]:
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = head_fill
    for m in by_material(qs):
        sm.append([m["label"], m["n"], m["titles"], m["books"], float(m["amount"])])
    sm.append([])
    sm.append(["Vendor-wise summary"])
    sm.cell(sm.max_row, 1).font = Font(bold=True)
    sm.append(["Vendor", "Invoices", "Books", "Amount (Rs)"])
    for c in sm[sm.max_row]:
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = head_fill
    for v in by_vendor(qs):
        sm.append([v["vendor"], v["n"], v["books"] or 0, float(v["amount"] or 0)])
    sm.append([])
    sm.append(["Year-wise summary"])
    sm.cell(sm.max_row, 1).font = Font(bold=True)
    sm.append(["Financial year", "Invoices", "Books", "Amount (Rs)", "Vendors"])
    for c in sm[sm.max_row]:
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = head_fill
    for y in by_year(qs):
        sm.append([y["financial_year"], y["n"], y["books"] or 0, float(y["amount"] or 0), y["vendors"]])
    sm.column_dimensions["A"].width = 36
    for col in "BCDE":
        sm.column_dimensions[col].width = 15
    for row in sm.iter_rows():
        for c in row:
            if isinstance(c.value, float):
                c.number_format = "#,##,##0.00"
    out = io.BytesIO()
    wb.save(out)
    return out.getvalue()


def export_pdf(qs, title):
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.lib.units import mm
    from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

    site = SiteSettings.load()
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=landscape(A4), leftMargin=12 * mm, rightMargin=12 * mm,
                            topMargin=12 * mm, bottomMargin=12 * mm, title="Invoice report")
    styles = getSampleStyleSheet()
    small = styles["BodyText"].clone("small", fontSize=7.5, leading=9)
    story = [Paragraph(f"<b>{site.institution_name or site.library_name}</b> - Index of Purchase Invoices", styles["Title"]),
             Paragraph(f"{title} &nbsp;·&nbsp; generated {timezone.localdate():%d-%m-%Y}", styles["Normal"]), Spacer(1, 6)]
    t = totals(qs)
    summary = [["Invoices", "Vendors", "Books", "Titles", "Total amount (Rs)"],
               [t["n"], t["vendors"], t["books"], t["titles"], money(t["amount"])]]
    st = Table(summary, hAlign="LEFT")
    st.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#0F5C63")),
                            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white), ("FONTSIZE", (0, 0), (-1, -1), 9),
                            ("GRID", (0, 0), (-1, -1), 0.4, colors.grey), ("FONTNAME", (0, 1), (-1, 1), "Helvetica-Bold")]))
    story += [st, Spacer(1, 8)]
    data = [[c[0] for c in COLUMNS]]
    for i, rec in enumerate(qs, 1):
        row = [i] + [_cell(rec, a) for _, a in COLUMNS[1:]]
        row[2] = Paragraph(str(row[2]), small)
        row[10] = money(rec.amount) if rec.amount is not None else ""
        data.append(row)
    data.append(["", "", "", "Total", t["books"], t["titles"] or "", "", "", "", "", money(t["amount"]), "", ""])
    widths = [7, 13, 50, 27, 12, 12, 34, 18, 22, 18, 25, 18, 20]
    tbl = Table(data, colWidths=[w * mm for w in widths], repeatRows=1)
    tbl.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#0F5C63")), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTSIZE", (0, 0), (-1, -1), 7.5), ("GRID", (0, 0), (-1, -1), 0.3, colors.grey),
        ("ROWBACKGROUNDS", (0, 1), (-1, -2), [colors.white, colors.HexColor("#F3F6F7")]),
        ("ALIGN", (4, 1), (5, -1), "RIGHT"), ("ALIGN", (10, 1), (10, -1), "RIGHT"),
        ("FONTNAME", (0, -1), (-1, -1), "Helvetica-Bold"), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ]))
    story += [tbl, Spacer(1, 10), Paragraph("<b>Summary by invoice type</b>", styles["Heading4"])]
    md = [["Invoice for", "Invoices", "Titles", "Books / volumes", "Amount (Rs)"]] + [
        [m["label"], m["n"], m["titles"], m["books"], money(m["amount"])] for m in by_material(qs)]
    mt = Table(md, colWidths=[55 * mm, 22 * mm, 22 * mm, 28 * mm, 35 * mm], hAlign="LEFT", repeatRows=1)
    mt.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#0F5C63")),
                            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white), ("FONTSIZE", (0, 0), (-1, -1), 8),
                            ("GRID", (0, 0), (-1, -1), 0.3, colors.grey), ("ALIGN", (1, 1), (-1, -1), "RIGHT")]))
    story += [mt, Spacer(1, 8), Paragraph("<b>Vendor-wise summary</b>", styles["Heading4"])]
    vd = [["Vendor", "Invoices", "Books", "Amount (Rs)"]] + [
        [v["vendor"], v["n"], v["books"] or 0, money(v["amount"] or 0)] for v in by_vendor(qs)]
    vt = Table(vd, colWidths=[80 * mm, 22 * mm, 22 * mm, 35 * mm], hAlign="LEFT", repeatRows=1)
    vt.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#0F5C63")),
                            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white), ("FONTSIZE", (0, 0), (-1, -1), 8),
                            ("GRID", (0, 0), (-1, -1), 0.3, colors.grey), ("ALIGN", (1, 1), (-1, -1), "RIGHT")]))
    story.append(vt)
    doc.build(story)
    return buf.getvalue()


def export_word(qs, title):
    import docx
    from docx.enum.section import WD_ORIENT
    from docx.shared import Mm, Pt

    site = SiteSettings.load()
    d = docx.Document()
    sec = d.sections[0]
    sec.orientation = WD_ORIENT.LANDSCAPE
    sec.page_width, sec.page_height = Mm(297), Mm(210)
    for m in ("left_margin", "right_margin", "top_margin", "bottom_margin"):
        setattr(sec, m, Mm(12))
    d.add_heading(f"{site.institution_name or site.library_name} - Index of Purchase Invoices", 1)
    d.add_paragraph(f"{title} · generated {timezone.localdate():%d-%m-%Y}")
    t = totals(qs)
    p = d.add_paragraph()
    p.add_run(f"Invoices: {t['n']}   Vendors: {t['vendors']}   Books: {t['books']}   Titles: {t['titles']}   "
              f"Total amount: Rs {money(t['amount'])}").bold = True
    table = d.add_table(rows=1, cols=len(COLUMNS))
    table.style = "Light Grid Accent 1"
    for i, (h, _) in enumerate(COLUMNS):
        table.rows[0].cells[i].text = h
    for i, rec in enumerate(qs, 1):
        cells = table.add_row().cells
        vals = [i] + [_cell(rec, a) for _, a in COLUMNS[1:]]
        vals[10] = money(rec.amount) if rec.amount is not None else ""
        for j, v in enumerate(vals):
            cells[j].text = str(v)
    cells = table.add_row().cells
    cells[3].text, cells[4].text, cells[5].text, cells[10].text = "Total", str(t["books"]), str(t["titles"] or ""), money(t["amount"])
    for row in table.rows:
        for c in row.cells:
            for par in c.paragraphs:
                for r in par.runs:
                    r.font.size = Pt(8)
    d.add_heading("Summary by invoice type", 2)
    mt = d.add_table(rows=1, cols=5)
    mt.style = "Light Grid Accent 1"
    for i, h in enumerate(("Invoice for", "Invoices", "Titles", "Books / volumes", "Amount (Rs)")):
        mt.rows[0].cells[i].text = h
    for m in by_material(qs):
        c = mt.add_row().cells
        c[0].text, c[1].text, c[2].text, c[3].text, c[4].text = (m["label"], str(m["n"]), str(m["titles"]),
                                                                 str(m["books"]), money(m["amount"]))
    d.add_heading("Vendor-wise summary", 2)
    vt = d.add_table(rows=1, cols=4)
    vt.style = "Light Grid Accent 1"
    for i, h in enumerate(("Vendor", "Invoices", "Books", "Amount (Rs)")):
        vt.rows[0].cells[i].text = h
    for v in by_vendor(qs):
        c = vt.add_row().cells
        c[0].text, c[1].text, c[2].text, c[3].text = v["vendor"], str(v["n"]), str(v["books"] or 0), money(v["amount"] or 0)
    out = io.BytesIO()
    d.save(out)
    return out.getvalue()
