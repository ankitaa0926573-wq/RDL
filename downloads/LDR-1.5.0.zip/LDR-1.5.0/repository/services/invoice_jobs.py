"""
Reads uploaded invoice files into the invoice register.

* read_into_register(doc, user)  - read every current file of a document, create/update
  the register entries (marked "needs review") and fill blank document metadata.
* create_upload_batch / start_upload - "Upload invoices" page: many PDFs / images /
  Excel files at once; each becomes an INV document, is OCR'd once, read, catalogued
  and (optionally) submitted for approval, in the background.
"""
import json
import logging
import os
import threading
from datetime import date
from decimal import Decimal

from django.conf import settings
from django.core.exceptions import ValidationError
from django.core.files.uploadedfile import SimpleUploadedFile
from django.db import close_old_connections, transaction
from django.utils import timezone

from ..models import (Action, BulkImport, MaterialType, Category, Confidentiality, Document, FileRole, InvoiceRecord, SourceType,
                      financial_year_of)
from . import lifecycle as L
from .audit import audit, notify
from .invoice_reader import ReaderError, read_invoice

log = logging.getLogger("ldr")

READ_FIELDS = ["vendor", "invoice_no", "invoice_date", "po_number", "po_date", "no_of_titles", "no_of_books", "amount"]
INVOICE_EXT = {"pdf", "jpg", "jpeg", "png", "tif", "tiff", "bmp", "webp", "xlsx", "xlsm", "xls", "csv", "docx"}


def _jsonable(v):
    if isinstance(v, (date,)):
        return v.isoformat()
    if isinstance(v, Decimal):
        return str(v)
    if isinstance(v, tuple):
        return list(v)
    return v


def _clean(inv):
    return {k: _jsonable(v) for k, v in inv.items() if k != "how"} | {"how": inv.get("how", {})}


def known_vendors():
    return list(InvoiceRecord.objects.exclude(vendor="").values_list("vendor", flat=True).distinct())


def invoice_category():
    return Category.objects.filter(code__iexact="INV").first() or Category.objects.filter(name__icontains="invoice").first()


def is_invoice_document(doc):
    cat = doc.category
    return bool(cat and (cat.code.upper() == "INV" or "invoice" in cat.name.lower() or "bill" in cat.name.lower()))


# ----------------------------------------------------------------------------- reading
def read_document_files(doc):
    """OCR/read every current master file. Returns (invoices, notes, errors)."""
    vendors = known_vendors()
    lang = settings.OCR_LANGUAGES or "eng"
    invoices, notes, errors = [], [], []
    files = doc.files.filter(role=FileRole.MASTER, is_current=True, purged=False).order_by("id")
    for df in files:
        ext = df.original_name.rsplit(".", 1)[-1].lower() if "." in df.original_name else ""
        if ext not in INVOICE_EXT:
            continue
        try:
            with df.file.open("rb") as fh:
                data = fh.read()
            stored = df.extracted_text if df.ocr_applied else None
            res = read_invoice(data, df.original_name, vendors, lang, stored_text=stored)
        except ReaderError as exc:
            errors.append(f"{df.original_name}: {exc}")
            continue
        except Exception as exc:  # a damaged file never stops the rest
            log.exception("invoice reading failed for %s", df.original_name)
            errors.append(f"{df.original_name}: could not be read ({exc.__class__.__name__})")
            continue
        if not df.extracted_text and res.get("text"):  # OCR now available: make the file searchable too
            df.extracted_text = res["text"][:500_000]
            df.save(update_fields=["extracted_text"])
            L.refresh_text(doc)
        for inv in res["invoices"]:
            inv["file"] = df.original_name
            invoices.append(inv)
        notes += [f"{df.original_name}: {n}" for n in res["notes"]]
    return invoices, notes, errors


def _group(invoices):
    """One register entry per invoice number; when a file holds several versions of the
    same invoice the last one is used and the others are kept as alternatives."""
    groups = {}
    for inv in invoices:
        key = (inv.get("invoice_no") or "").upper() or f"#{len(groups)}"
        groups.setdefault(key, []).append(inv)
    return [(g[-1], g[:-1]) for g in groups.values()]


def _summary(inv):
    bits = []
    if inv.get("invoice_no"):
        bits.append(f"Invoice {inv['invoice_no']}")
    if inv.get("vendor"):
        bits.append(f"from {inv['vendor']}")
    if inv.get("invoice_date"):
        bits.append(f"dated {inv['invoice_date']:%d-%m-%Y}")
    if inv.get("po_number"):
        bits.append(f"against PO {inv['po_number']}" + (f" ({inv['po_date']:%d-%m-%Y})" if inv.get("po_date") else ""))
    s = " ".join(bits)
    if inv.get("material_type"):
        s = f"{dict(MaterialType.choices).get(inv['material_type'], '')} invoice: " + s
    counts = []
    if inv.get("no_of_titles"):
        counts.append(f"{inv['no_of_titles']} titles")
    if inv.get("no_of_books"):
        counts.append(f"{inv['no_of_books']} volumes")
    if inv.get("amount") is not None:
        counts.append(f"amount Rs {inv['amount']:,.2f}")
    if counts:
        s += ": " + ", ".join(counts)
    return s + "."


def _fill_document(doc, inv, user, request=None):
    """Fill blank document metadata from what was read (never overwrites what staff typed)."""
    if not doc.is_editable:
        if not doc.material_type and inv.get("material_type"):  # classification only - safe after approval
            Document.objects.filter(pk=doc.pk).update(material_type=inv["material_type"])
        return []
    changed = []
    pairs = [("received_from", inv.get("vendor")), ("reference_number", inv.get("invoice_no")),
             ("document_date", inv.get("invoice_date")), ("amount", inv.get("amount"))]
    for field, val in pairs:
        if val not in (None, "") and getattr(doc, field) in (None, ""):
            setattr(doc, field, val)
            changed.append(field)
    if not doc.material_type and inv.get("material_type"):
        doc.material_type = inv["material_type"]
        changed.append("material_type")
    if not doc.document_year and inv.get("invoice_date"):
        doc.document_year = financial_year_of(inv["invoice_date"])
        changed.append("document_year")
    if not doc.description:
        doc.description = _summary(inv)
        changed.append("description")
    if doc.title.lower().startswith("invoice - ") and inv.get("invoice_no"):
        doc.title = f"Invoice {inv['invoice_no']} - {inv.get('vendor') or 'vendor not read'}"[:300]
        changed.append("title")
    if changed:
        if "document_date" in changed and not doc.permanent:
            doc.expiry_date = None  # recalculated from the invoice date
        if user.can_catalogue:
            L.save_metadata(doc, user, changed, request)
        else:
            doc.save()
            audit(Action.METADATA, request, user=user, document=doc, details="Read from invoice: " + ", ".join(changed))
    return changed


def read_into_register(doc, user, request=None):
    """Read the document's invoice file(s) into the register. Returns a result dict."""
    invoices, notes, errors = read_document_files(doc)
    result = {"records": [], "notes": notes, "errors": errors, "filled": []}
    if not invoices:
        return result
    for inv, alternatives in _group(invoices):
        fields = {k: inv.get(k) for k in READ_FIELDS}
        for k in ("vendor", "invoice_no", "po_number"):  # text columns are never NULL
            fields[k] = fields[k] or ""
        if not fields["vendor"]:
            fields["vendor"] = doc.received_from or "Vendor not read"
        material = doc.material_type or inv.get("material_type") or ""
        info = {"read": _clean(inv), "alternatives": [_clean(a) for a in alternatives], "notes": notes,
                "read_at": timezone.now().isoformat(), "read_by": user.username}
        rec, how = None, ""
        if fields["invoice_no"]:
            rec = InvoiceRecord.objects.filter(document=doc, invoice_no__iexact=fields["invoice_no"]).first()
            if not rec:  # entered earlier from the index workbook: link instead of duplicating
                rec = InvoiceRecord.objects.filter(document__isnull=True, invoice_no__iexact=fields["invoice_no"],
                                                   vendor__iexact=fields["vendor"]).first()
                how = "linked to existing register entry" if rec else ""
            dup = (InvoiceRecord.objects.filter(invoice_no__iexact=fields["invoice_no"], vendor__iexact=fields["vendor"],
                                                document__isnull=False).exclude(document=doc).select_related("document").first())
            if dup:
                info["duplicate_of"] = dup.document.doc_id
        if not rec:
            rec = InvoiceRecord.objects.filter(document=doc, invoice_no="", source="auto").first()
        with transaction.atomic():
            if rec is None:
                rec = InvoiceRecord(document=doc, created_by=user, source="auto", needs_review=True,
                                    material_type=material, **fields)
                how = "added to register"
            else:
                compare = {}
                for k, v in fields.items():
                    old = getattr(rec, k)
                    if v in (None, ""):
                        continue
                    if old in (None, "") or (rec.source == "auto" and rec.needs_review):
                        setattr(rec, k, v)
                    elif str(old) != str(v):
                        compare[k] = {"register": _jsonable(old), "invoice": _jsonable(v)}
                if compare:
                    info["differences"] = compare
                if material and (not rec.material_type or doc.material_type or (rec.source == "auto" and rec.needs_review)):
                    rec.material_type = material
                rec.document = doc
                rec.needs_review = True
                how = how or "register entry updated"
            if rec.invoice_date and (rec.source == "auto" or not rec.financial_year):
                rec.financial_year = financial_year_of(rec.invoice_date)
            rec.read_info = json.dumps(info, default=str)
            rec.save()
        audit(Action.INVOICE_CHANGE, request, user=user, document=doc,
              details=f"Invoice read automatically ({inv.get('confidence')}): {_summary(inv)} -> register #{rec.pk} {how}")
        result["records"].append({"pk": rec.pk, "how": how, "confidence": inv.get("confidence"),
                                  "material_type": rec.material_type, "material": rec.get_material_type_display(),
                                  "duplicate_of": info.get("duplicate_of"), **{k: _jsonable(fields[k]) for k in READ_FIELDS}})
        if len(result["records"]) == 1:
            result["filled"] = _fill_document(doc, inv, user, request)
    return result


# ----------------------------------------------------------------------------- "Upload invoices" batch
def create_upload_batch(files, user, department=None, access=None, material=""):
    stamp = timezone.localtime().strftime("%Y%m%d_%H%M%S")
    folder = settings.DATA_DIR / "bulk" / f"invoices_{stamp}_{user.pk}"
    folder.mkdir(parents=True, exist_ok=True)
    rows, problems = [], []
    for i, f in enumerate(files, 1):
        name = os.path.basename(f.name)
        ext = name.rsplit(".", 1)[-1].lower() if "." in name else ""
        if ext not in INVOICE_EXT:
            problems.append({"row": i, "title": name, "error": f".{ext} files cannot be read as invoices"})
            continue
        target = folder / f"{i:03d}_{name}"
        with open(target, "wb") as fh:
            for chunk in f.chunks():
                fh.write(chunk)
        rows.append({"row": i, "title": name, "path": str(target)})
    batch = BulkImport.objects.create(
        created_by=user, kind="invoices", file_name=f"{len(rows)} invoice file(s)", stored_path=str(folder),
        state=BulkImport.State.VALIDATED, total_rows=len(rows),
        report=json.dumps({"rows": rows, "problems": problems,
                           "department": department.pk if department else None, "access": access or "",
                           "material": material or ""}),
    )
    return batch


def run_upload(batch_id):
    batch = BulkImport.objects.get(pk=batch_id)
    user = batch.created_by
    data = json.loads(batch.report)
    rows, results = data["rows"], []
    cat = invoice_category()
    batch.state = BulkImport.State.RUNNING
    batch.save(update_fields=["state"])
    for row in rows:
        res = {"row": row["row"], "title": row["title"]}
        try:
            if cat is None:
                raise ValidationError("There is no 'Invoices & Bills' (INV) category. Add one under Categories.")
            with open(row["path"], "rb") as fh:
                content = fh.read()
            with transaction.atomic():
                doc = Document(title=f"Invoice - {row['title']}"[:300], category=cat,
                               department_id=data.get("department"), source_type=SourceType.PHYSICAL,
                               received_date=timezone.localdate(), custodian=user)
                doc.confidentiality = data.get("access") or cat.default_confidentiality or Confidentiality.GENERAL
                doc.material_type = data.get("material") or ""
                L.register_document(doc, user)
                L.add_file(doc, SimpleUploadedFile(row["title"], content), user)
                L.mark_digitized(doc, user)
            res.update(doc_id=doc.doc_id, pk=doc.pk)
            read = read_into_register(doc, user)
            doc.refresh_from_db()
            res["records"] = read["records"]
            res["errors"] = read["errors"]
            res["notes"] = read["notes"]
            if not read["records"]:
                res["status"] = "stored - details not read"
            elif batch.submit_for_approval and not L.metadata_missing(doc):
                L.submit_for_approval(doc, user, notify_approvers=False)
                res["status"] = "submitted"
            else:
                res["status"] = "read - in workflow"
            batch.imported += 1
        except Exception as exc:
            log.exception("invoice upload row failed")
            res["status"] = "failed"
            res["error"] = "; ".join(exc.messages) if isinstance(exc, ValidationError) else f"{exc.__class__.__name__}: {exc}"
            batch.failed += 1
        finally:
            try:
                os.remove(row["path"])
            except OSError:
                pass
        results.append(res)
        batch.processed += 1
        batch.report = json.dumps(data | {"results": results}, default=str)
        batch.save(update_fields=["processed", "imported", "failed", "report"])
    try:
        os.rmdir(batch.stored_path)
    except OSError:
        pass
    batch.state = BulkImport.State.DONE
    batch.finished_at = timezone.now()
    batch.save()
    audit(Action.BULK_IMPORT, user=user, details=f"Invoice upload #{batch.pk}: {batch.imported} stored, "
                                                 f"{batch.failed} failed of {batch.total_rows}")
    notify([user], f"Invoice upload finished: {batch.imported} of {batch.total_rows} read. Please check the values.",
           link=f"/invoices/upload/{batch.pk}/", level="success")
    submitted = sum(1 for r in results if r.get("status") == "submitted")
    if submitted:
        notify(L.approvers(), f"{submitted} invoices from {user.display_name()} are awaiting approval.",
               link="/approvals/", level="warning")
    return batch


def start_upload(batch, submit_for_approval=True, background=True):
    batch.submit_for_approval = submit_for_approval
    batch.state = BulkImport.State.RUNNING
    batch.save(update_fields=["submit_for_approval", "state"])
    if not background:
        return run_upload(batch.pk)

    def _job(pk):
        try:
            run_upload(pk)
        except Exception:
            log.exception("invoice upload batch failed")
            BulkImport.objects.filter(pk=pk).update(state=BulkImport.State.FAILED, finished_at=timezone.now())
        finally:
            close_old_connections()

    threading.Thread(target=_job, args=(batch.pk,), daemon=True, name=f"ldr-invoices-{batch.pk}").start()
    return batch


# ----------------------------------------------------------------------------- invoices uploaded the ordinary way
def unread_invoice_documents():
    """Invoice documents that have a file but are not yet in the invoice register."""
    cats = [c.pk for c in Category.objects.all() if c.code.upper() == "INV" or "invoice" in c.name.lower()
            or "bill" in c.name.lower()]
    return (Document.objects.filter(category_id__in=cats, invoices__isnull=True, files__role=FileRole.MASTER,
                                    files__is_current=True, files__purged=False)
            .exclude(status="DISPOSED").distinct().order_by("id"))


_catchup = {"running": False, "done": 0, "total": 0, "found": 0, "failed": []}


def catchup_status():
    return dict(_catchup)


def read_unread_documents(user, background=True):
    """Read every invoice document that is not in the register yet (e.g. uploaded with 'Register document')."""
    if _catchup["running"]:
        return False
    docs = [d for d in unread_invoice_documents() if L.can_open(user, d)]
    _catchup.update(running=True, done=0, total=len(docs), found=0, failed=[])

    def _job(ids):
        try:
            for pk in ids:
                doc = Document.objects.get(pk=pk)
                try:
                    res = read_into_register(doc, user)
                    _catchup["found"] += len(res["records"])
                    if not res["records"]:
                        _catchup["failed"].append(f"{doc.doc_id}: " + ("; ".join(res["errors"]) or "no invoice details found"))
                except Exception as exc:
                    log.exception("reading %s failed", doc.doc_id)
                    _catchup["failed"].append(f"{doc.doc_id}: {exc.__class__.__name__}")
                _catchup["done"] += 1
        finally:
            _catchup["running"] = False
            close_old_connections()
        if _catchup["found"]:
            notify([user], f"{_catchup['found']} invoices were read into the invoice register. Please check them.",
                   link="/invoices/?review=1", level="success")

    ids = [d.pk for d in docs]
    if background:
        threading.Thread(target=_job, args=(ids,), daemon=True, name="ldr-invoice-catchup").start()
    else:
        _job(ids)
    return True
