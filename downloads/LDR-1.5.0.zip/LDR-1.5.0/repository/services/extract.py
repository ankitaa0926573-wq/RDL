"""
Phase 2 - Digitization helpers.

* Extracts text from PDF, Word, Excel, CSV and text files so documents are
  full-text searchable.
* If Tesseract OCR is installed, scanned images and image-only PDFs are OCR'd
  and a *searchable PDF access copy* is produced next to the untouched
  preservation master (OAIS: AIP master + DIP access copy).

Every optional dependency is imported lazily; the system keeps working (without
OCR) on machines where Tesseract is not installed.
"""
import io
import logging
import shutil

from django.conf import settings

log = logging.getLogger("ldr")

IMAGE_EXT = {"jpg", "jpeg", "png", "tif", "tiff", "bmp", "gif", "webp"}
MAX_TEXT = 500_000


def _tesseract():
    if not settings.OCR_ENABLED:
        return None
    try:
        import pytesseract
    except ImportError:
        return None
    from .ocr_setup import OCR_DIR, bundled_exe

    builtin = None if settings.TESSERACT_CMD else bundled_exe()
    if settings.TESSERACT_CMD:
        pytesseract.pytesseract.tesseract_cmd = settings.TESSERACT_CMD
    elif builtin:  # LDR's own built-in OCR (ocr\tesseract folder)
        import os

        pytesseract.pytesseract.tesseract_cmd = str(builtin)
        os.environ["TESSDATA_PREFIX"] = str(OCR_DIR / "tessdata")
    else:
        found = shutil.which("tesseract")
        if not found:
            for candidate in (
                r"C:\Program Files\Tesseract-OCR\tesseract.exe",
                r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
            ):
                import os

                if os.path.exists(candidate):
                    found = candidate
                    break
        if not found:
            return None
        pytesseract.pytesseract.tesseract_cmd = found
    try:
        pytesseract.get_tesseract_version()
    except Exception:
        return None
    return pytesseract


def ocr_available():
    return _tesseract() is not None


def _pdf_text(data):
    from pypdf import PdfReader

    reader = PdfReader(io.BytesIO(data))
    parts = []
    for page in reader.pages:
        try:
            parts.append(page.extract_text() or "")
        except Exception:
            parts.append("")
    return PAGE_BREAK.join(parts), len(reader.pages)


def _docx_text(data):
    import docx

    d = docx.Document(io.BytesIO(data))
    parts = [p.text for p in d.paragraphs]
    for table in d.tables:
        for row in table.rows:
            parts.append(" | ".join(c.text for c in row.cells))
    return "\n".join(parts)


def _xlsx_text(data):
    import openpyxl

    wb = openpyxl.load_workbook(io.BytesIO(data), read_only=True, data_only=True)
    parts = []
    for ws in wb.worksheets:
        parts.append(f"[{ws.title}]")
        for row in ws.iter_rows(values_only=True):
            vals = [str(v) for v in row if v is not None]
            if vals:
                parts.append(" | ".join(vals))
            if len(parts) > 20000:
                break
    return "\n".join(parts)


PAGE_BREAK = "\n\f\n"  # separates pages in stored text (lets the invoice reader work page by page)


def prepare_page(img):
    """Same clean-up for every scanned page (upload OCR and the invoice reader must see identical text)."""
    from PIL import Image, ImageOps

    try:
        img = ImageOps.exif_transpose(img)
    except Exception:
        pass
    img = img.convert("L")
    if max(img.size) < 1600:  # small photos/scans: upscale for better recognition
        f = 1600 / max(img.size)
        img = img.resize((int(img.width * f), int(img.height * f)), Image.LANCZOS)
    return img


def _reading_score(img, tess):
    """How well a page reads in this orientation: confident words of 3+ characters (quick, on a small copy)."""
    small = img.copy()
    small.thumbnail((1600, 1600))
    try:
        d = tess.image_to_data(small, config="--psm 6", output_type=tess.Output.DICT)
    except Exception:
        return 0
    return sum(1 for w, c in zip(d.get("text", []), d.get("conf", []))
               if len(str(w).strip()) >= 3 and float(c) >= 70)


def upright(img, tess):
    """Turn a scanned page the right way up (sideways / upside-down scans). Returns (image, degrees).
    Orientation detection (OSD) is checked against a quick test read, because it is often wrong on
    dot-matrix / faint invoices - a page is only turned if it really reads better that way."""
    import re as _re

    rot = None
    try:
        osd = tess.image_to_osd(img, config="--psm 0 -c min_characters_to_try=5")
        m = _re.search(r"Rotate:\s*(\d+)", osd)
        conf = _re.search(r"Orientation confidence:\s*([\d.]+)", osd)
        rot = int(m.group(1)) if m else 0
        if rot and conf and float(conf.group(1)) >= 15:  # very sure: trust it
            return img.rotate(-rot, expand=True), rot
    except Exception:
        pass
    candidates = [0, rot] if rot else ([0] if rot == 0 else [0, 90, 270, 180])
    if rot == 0:
        return img, 0
    scores = {r: _reading_score(img.rotate(-r, expand=True) if r else img, tess) for r in candidates}
    best = max(candidates, key=lambda r: (scores[r], r == 0))
    return (img.rotate(-best, expand=True) if best else img), best


def _ocr_images(images, tess):
    """OCR a list of PIL images. Returns (text, searchable_pdf_bytes)."""
    from pypdf import PdfReader, PdfWriter

    texts = []
    writer = PdfWriter()
    lang = settings.OCR_LANGUAGES or "eng"
    for img in images:
        img, _rot = upright(prepare_page(img), tess)
        texts.append(tess.image_to_string(img, lang=lang, config="--psm 6"))
        pdf_bytes = tess.image_to_pdf_or_hocr(img, extension="pdf", lang=lang)
        for p in PdfReader(io.BytesIO(pdf_bytes)).pages:
            writer.add_page(p)
    out = io.BytesIO()
    writer.write(out)
    return PAGE_BREAK.join(texts), out.getvalue()


def process_file(data, filename):
    """
    Returns dict(text=str, pages=int|None, ocr=bool, searchable_pdf=bytes|None, note=str)
    """
    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    result = {"text": "", "pages": None, "ocr": False, "searchable_pdf": None, "note": ""}
    try:
        if ext == "pdf":
            text, pages = _pdf_text(data)
            result["pages"] = pages
            result["text"] = text
            if len(text.strip()) < 5 * max(pages, 1):
                tess = _tesseract()
                if tess:
                    import pypdfium2 as pdfium

                    pdf = pdfium.PdfDocument(data)
                    images = [pdf[i].render(scale=300 / 72).to_pil() for i in range(min(len(pdf), 200))]
                    ocr_text, spdf = _ocr_images(images, tess)
                    result.update(text=ocr_text, ocr=True, searchable_pdf=spdf, note="Scanned PDF - OCR applied")
                else:
                    result["note"] = "Scanned PDF - install Tesseract OCR to make it searchable"
        elif ext in IMAGE_EXT:
            from PIL import Image, ImageSequence

            tess = _tesseract()
            if tess:
                im = Image.open(io.BytesIO(data))
                frames = [f.copy() for f in ImageSequence.Iterator(im)][:200]
                ocr_text, spdf = _ocr_images(frames, tess)
                result.update(
                    text=ocr_text, ocr=True, searchable_pdf=spdf, pages=len(frames),
                    note="Image - OCR applied, searchable PDF created",
                )
            else:
                result["note"] = "Image stored - install Tesseract OCR to make it searchable"
        elif ext == "docx":
            result["text"] = _docx_text(data)
        elif ext in ("xlsx", "xlsm"):
            result["text"] = _xlsx_text(data)
        elif ext in ("txt", "csv", "md", "xml", "json", "html", "htm"):
            result["text"] = data.decode("utf-8", errors="replace")
    except Exception as exc:  # never block an upload because extraction failed
        log.exception("Text extraction failed for %s", filename)
        result["note"] = f"Text extraction failed: {exc.__class__.__name__}"
    result["text"] = (result["text"] or "")[:MAX_TEXT]
    return result
