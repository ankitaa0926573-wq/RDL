"""
Invoice reader: pulls the key facts out of a vendor invoice so the invoice register
and reports fill themselves.

Reads PDF (text or scanned), images (JPG/PNG/TIFF, any rotation), Excel/CSV and Word.
Scanned pages are OCR'd with Tesseract; sideways pages are rotated automatically.

For every invoice found in the file it returns:
  vendor, invoice_no, invoice_date, po_number, po_date,
  no_of_titles (line items), no_of_books (total quantity / volumes), amount (net total)
plus notes about how each value was found, so a person can verify it.

One PDF can hold more than one invoice (e.g. original + revised copy); pages are
split on "Page 1 of N" markers and each part is read separately.
"""
import difflib
import io
import logging
import re
from datetime import date, datetime
from decimal import Decimal, InvalidOperation

from .extract import PAGE_BREAK, _tesseract, prepare_page, upright

log = logging.getLogger("ldr")

MONTHS = {m: i for i, m in enumerate(
    ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"], 1)}
DATE_PATTERNS = [
    (re.compile(r"\b(\d{1,2})\s*[/\-.]\s*(\d{1,2})\s*[/\-.]\s*(\d{4}|\d{2})\b"), "dmy"),
    (re.compile(r"\b(\d{1,2})\s*[\-\s.]\s*([A-Za-z]{3,9})\s*[\-\s.,]\s*(\d{4}|\d{2})\b"), "dMy"),
    (re.compile(r"\b(\d{4})\s*[/\-.]\s*(\d{1,2})\s*[/\-.]\s*(\d{1,2})\b"), "ymd"),
]
MONEY_RE = re.compile(r"(?<![\d.])(\d{1,3}(?:,\d{2,3})+(?:\.\d{1,2})?|\d+\.\d{1,2}|\d{3,})(?![\d])")


class ReaderError(Exception):
    pass


# ----------------------------------------------------------------------- text from files
def _ocr_image(img, tess, lang="eng"):
    """OCR one page image, fixing rotation first. Returns (text, rotation)."""
    img, rot = upright(prepare_page(img), tess)
    return tess.image_to_string(img, lang=lang, config="--psm 6"), rot


def pages_from_file(data, filename, ocr_lang="eng"):
    """Return (list_of_page_texts, notes). Raises ReaderError if nothing can be read."""
    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    notes = []
    if ext == "pdf":
        from pypdf import PdfReader

        reader = PdfReader(io.BytesIO(data))
        texts = [(p.extract_text() or "") for p in reader.pages]
        need_ocr = [i for i, t in enumerate(texts) if len(t.strip()) < 40]
        if need_ocr:
            tess = _tesseract()
            if not tess:
                if len(need_ocr) == len(texts):
                    raise ReaderError("This invoice is a scanned image. OCR (Tesseract) is not installed on the LDR "
                                      "server yet, so it cannot be read. Super Librarian: Settings > Install built-in OCR, then press 'Read details' again.")
                notes.append(f"{len(need_ocr)} scanned page(s) skipped - OCR not installed")
            else:
                import pypdfium2 as pdfium

                pdf = pdfium.PdfDocument(data)
                rotated = 0
                for i in need_ocr[:60]:
                    img = pdf[i].render(scale=300 / 72).to_pil()
                    texts[i], rot = _ocr_image(img, tess, ocr_lang)
                    rotated += bool(rot)
                notes.append(f"OCR used on {len(need_ocr)} scanned page(s)" + (f", {rotated} turned upright" if rotated else ""))
        return texts, notes
    if ext in ("jpg", "jpeg", "png", "tif", "tiff", "bmp", "gif", "webp"):
        from PIL import Image, ImageSequence

        tess = _tesseract()
        if not tess:
            raise ReaderError("Images need OCR (Tesseract), which is not installed on the LDR server. "
                              "Super Librarian: Settings > Install built-in OCR, then try again.")
        im = Image.open(io.BytesIO(data))
        texts = []
        for frame in list(ImageSequence.Iterator(im))[:60]:
            t, _ = _ocr_image(frame.copy(), tess, ocr_lang)
            texts.append(t)
        notes.append("OCR used")
        return texts, notes
    if ext in ("xlsx", "xlsm", "xls", "csv"):
        from .viewer import sheets

        lines = []
        for sh in sheets(data, ext):
            for row in sh["rows"]:
                cells = [str(c).strip() for c in row if str(c).strip()]
                if cells:
                    lines.append(" | ".join(cells))
        return ["\n".join(lines)], ["read from spreadsheet cells"]
    if ext == "docx":
        import docx

        d = docx.Document(io.BytesIO(data))
        lines = [p.text for p in d.paragraphs]
        for t in d.tables:
            for r in t.rows:
                lines.append(" | ".join(c.text.strip() for c in r.cells))
        return ["\n".join(lines)], ["read from Word document"]
    if ext in ("txt", "eml"):
        return [data.decode("utf-8", errors="replace")], []
    raise ReaderError(f".{ext} files cannot be read as invoices (use PDF, image, Excel or Word).")


# ----------------------------------------------------------------------- splitting multi-invoice files
PAGE_OF = re.compile(r"page\s*(?:no\.?)?\s*[:\-]*\s*(?:page\s*)?(\d{1,3})\s*(?:of|/)\s*(\d{1,3})", re.I)


def segments(pages):
    """Group pages into invoices using 'Page x of N' markers. Returns list of (first_page, last_page, text)."""
    marks = []
    for t in pages:
        m = PAGE_OF.findall(t)
        marks.append((int(m[-1][0]), int(m[-1][1])) if m else None)
    if not any(marks):
        return [(1, len(pages), "\n".join(pages))]
    groups, cur = [], []
    for i, mk in enumerate(marks):
        if mk and mk[0] == 1 and cur:
            groups.append(cur)
            cur = []
        cur.append(i)
    if cur:
        groups.append(cur)
    return [(g[0] + 1, g[-1] + 1, "\n".join(pages[i] for i in g)) for g in groups]


# ----------------------------------------------------------------------- value helpers
def parse_any_date(s):
    for rx, kind in DATE_PATTERNS:
        for m in rx.finditer(s):
            try:
                if kind == "dmy":
                    d, mo, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
                elif kind == "ymd":
                    y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
                else:
                    d, y = int(m.group(1)), int(m.group(3))
                    mo = MONTHS.get(m.group(2)[:3].lower())
                    if not mo:
                        continue
                if y < 100:
                    y += 2000
                if 1990 <= y <= 2100:
                    return date(y, mo, d), m.start(), m.end()
            except ValueError:
                continue
    return None


def to_decimal(s):
    s = s.replace(",", "").strip()
    try:
        return Decimal(s).quantize(Decimal("0.01"))
    except InvalidOperation:
        return None


MAX_AMOUNT = Decimal("9999999999")  # Rs 999 crore - anything larger is an ISBN / phone / account number


def money_values(line):
    vals = []
    for m in MONEY_RE.finditer(line):
        raw = m.group(1)
        if re.fullmatch(r"\d{8,}", raw):  # long bare digit runs are codes (ISBN, phone, account, GSTIN parts)
            continue
        v = to_decimal(raw)
        if v is not None and v <= MAX_AMOUNT:
            vals.append(v)
    return vals


def fuzzy_word(token, target, cutoff=0.7):
    return difflib.SequenceMatcher(None, token.lower(), target).ratio() >= cutoff


SMALL = {"zero": 0, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8, "nine": 9,
         "ten": 10, "eleven": 11, "twelve": 12, "thirteen": 13, "fourteen": 14, "fifteen": 15, "sixteen": 16,
         "seventeen": 17, "eighteen": 18, "nineteen": 19, "twenty": 20, "thirty": 30, "forty": 40, "fourty": 40,
         "fifty": 50, "sixty": 60, "seventy": 70, "eighty": 80, "ninety": 90}
SCALE = {"hundred": 100, "thousand": 1000, "lakh": 100000, "lakhs": 100000, "lac": 100000, "lacs": 100000,
         "crore": 10000000, "crores": 10000000}


def words_to_number(text):
    """'One Lakh Fifty Thousand Three Fifty Four' -> 150354 ; 'Fifteen Lacs Four Hundred Seven' -> 1500407."""
    vocab = list(SMALL) + list(SCALE)
    words = []
    for w in re.findall(r"[a-z]+", text.lower()):  # OCR: "Une" -> one, "Saxty" -> sixty
        if w not in SMALL and w not in SCALE and len(w) >= 3:
            close = difflib.get_close_matches(w, vocab, n=1, cutoff=0.75)
            w = close[0] if close else w
        words.append(w)
    total, current, last_small = 0, 0, None
    used = False
    for w in words:
        if w in SMALL:
            v = SMALL[w]
            # "three fifty four" = 3 hundred 54 (spoken style)
            if last_small is not None and last_small < 10 and v >= 20 and current % 100 == last_small:
                current = current - last_small + last_small * 100 + v
            else:
                current += v
            last_small = v
            used = True
        elif w in SCALE:
            s = SCALE[w]
            if s == 100:
                current = (current or 1) * 100
            else:
                total += (current or 1) * s
                current = 0
            last_small = None
            used = True
        elif w in ("and", "rupees", "rs", "only", "inr", "paise"):
            if w == "paise":
                break
            continue
    return (total + current) if used else None


# ----------------------------------------------------------------------- field extraction
INV_NO = re.compile(r"(?:invoice|inv|bill)\s*(?:no|number|num|#)[\s.:\-;]*([A-Z0-9][A-Z0-9/\-. ]{0,40}?)"
                    r"(?=\s*[_~=\-]*\s+(?:date|dated|dt)\b|\s{3,}|\s*\||$)", re.I | re.M)
PO_NO = re.compile(r"(?:\bp\.?\s*o\.?\s*(?:no|number|ref)\.?|order\s*/?\s*ref\.?\s*no\.?|purchase\s*order\s*(?:no\.?|number)?|"
                   r"supply\s*order\s*(?:no\.?)?|your\s*[o0g]rder\s*(?:no[s.]?)?|ref(?:e)?r?ence\s*no\.?)[\s.:\-;]*"
                   r"([A-Z0-9][A-Z0-9/\-. ]{1,40}?)"
                   r"(?=\s*[_~=\-]*\s+(?:date|dated|dt|ref)\b|\s{3,}|\s*\||$)", re.I | re.M)
TOTAL_BOOKS = re.compile(r"(?:(?:to)?tal\s*(?:no\.?|number)\s*of|no\.?\s*of)\s*(?:books?|vols?|volumes|copies)\s*[.:\-|]*\s*(\d{1,6})", re.I)
CARRIED = re.compile(r"carried|brought|c/f|b/f", re.I)


def _clean_code(s):
    s = re.sub(r"\s{2,}", " ", s.strip(" .:-;|"))
    return s[:60]


def _tidy_vendor(s):
    """'4 MPP HOUSE' / ', K.L. BOOK HOUSE' -> 'MPP House' / 'K.L. Book House' (OCR specks removed, acronyms kept)."""
    words = s.strip(" ,.;:-'&").split()
    while words and (not re.search(r"[A-Za-z]", words[0]) or re.search(r"\d", words[0])):
        words.pop(0)  # stray marks / logo fragments before the name
    out = []
    for w in words:
        core = re.sub(r"[^A-Za-z]", "", w)
        if core.isupper() and ("." in w or (len(core) <= 4 and not re.search(r"[AEIOU]", core))):
            out.append(w)  # MPP, K.L., S.B.
        else:
            out.append(w.capitalize() if w.isupper() or w.islower() else w)
    return " ".join(out)[:120]


def _find_vendor(text, known_vendors):
    flat = re.sub(r"[^a-z0-9]", "", text[:1500].lower())
    best = None
    for v in known_vendors:
        key = re.sub(r"[^a-z0-9]", "", v.lower())
        if len(key) >= 4 and key in flat:
            if best is None or len(key) > len(re.sub(r"[^a-z0-9]", "", best.lower())):
                best = v
    if best:
        return best, "matched a vendor already in the register"
    skip = re.compile(r"invoice|bill\b|bill\s*no|tax|gst|original|duplicate|copy|supply|phone|email|e-mail|www|address|registered|"
                      r"\bto\b|keep|\btin\b|\bpan\b|road|cross|layout|floor|bengaluru|bangalore|karnataka|"
                      r"p\.?\s*o\.?\s*no|order|dated?\b|\bno\s*[:.]|\bsl\b|qty|amount|total|\d{6}|"
                      r"universit|college|institut|library|librarian|registrar|\bdean\b|principal|"  # the buyer, not the vendor
                      r"particulars|\btitle\b|author|publisher|isbn|rate|price|carried|brought|forward|page|rupees", re.I)

    def candidate(line):
        if skip.search(line):
            return None
        c = re.sub(r"[^A-Za-z0-9&.,' -]", " ", line).strip()
        c = re.sub(r"\bE\.?\s*&\s*O\.?\s*E\.?|\b[Ff]or\b", " ", c)
        runs = re.findall(r"(?:(?<![A-Za-z])[A-Z][A-Z&.']*(?:[ ,]+|$))+", c)  # the capitalised name inside OCR noise
        if runs:
            c = max(runs, key=lambda r: len(re.sub(r"[^A-Za-z]", "", r)))
        c = re.sub(r"\s{2,}", " ", c).strip(" ,.'")
        letters = re.sub(r"[^A-Za-z]", "", c)
        words = [w for w in re.findall(r"[A-Za-z]{3,}", c)]
        if len(letters) >= 4 and words and not skip.search(c) and sum(ch.isupper() for ch in letters) >= 0.6 * len(letters):
            return c
        return None

    lines = text.splitlines()
    heads, foots = [], []
    starts = [0] + [i + 1 for i, l in enumerate(lines) if re.search(r"page\s*\d+\s*of|^\W*in[vu]o[il1]ce\W*$", l, re.I)]
    for st in sorted(set(starts)):  # the first lines of each page / invoice copy
        for l in lines[st:st + 12]:
            c = candidate(l)
            if c:
                heads.append(c)
                break
    for i, l in enumerate(lines):  # the printed name above "Regd. Office / PAN / Mob" footers
        if re.search(r"reg[dt]\.?\s*of+ice|registered\s*office|\bpan\s*no|\bmob\b|for\s+[A-Z]", l, re.I):
            for back in (1, 2):
                if i - back >= 0:
                    c = candidate(lines[i - back])
                    if c:
                        foots.append(c)
                        break
    for l in lines:  # signature block "For KL BOOK HOUSE" and "Cheque in favour of KL Book House"
        for m in re.finditer(r"\b[Ff][Oo][Rr]\s+((?:[A-Z][A-Z&.']*\s?){1,6})", l):
            if len(re.sub(r"[^A-Z]", "", m.group(1))) >= 4 and not skip.search(m.group(1)):
                foots.append(m.group(1).strip())
        m = re.search(r"in\s+favou?r\s+of\s+[\"']?([A-Z][A-Za-z&.' ]{3,40}?)(?=\s*[-–,(|]|\s{2,}|$)", l)
        if m and not skip.search(m.group(1)):
            foots.append(m.group(1).strip())
    if not heads and not foots:
        return "", "not found"

    def key(c):
        return re.sub(r"[^a-z]", "", _tidy_vendor(c).lower())

    def similar(a, b):
        return difflib.SequenceMatcher(None, key(a), key(b)).ratio() >= 0.72

    pool = heads + foots
    best, best_score = None, -1
    for c in pool:  # the name that repeats most (page headers + footer) wins; clean footer print breaks ties
        score = sum(1 for o in pool if similar(c, o)) + (0.5 if c in foots else 0) + (0.3 if c == pool[0] else 0)
        if score > best_score:
            best, best_score = c, score
    how = "taken from the invoice heading" if best in heads else "taken from the vendor's name printed at the foot"
    if best_score >= 2:
        how += " (repeated on several pages)"
    return _tidy_vendor(best), how


def _titles(text):
    serials = []
    for line in text.splitlines():
        m = re.match(r"^\s*[\[(|]?\s*(\d{1,4})\s*[\])|._:;,]*\s+(?=\S)", line)
        if not m:
            continue
        rest = line[m.end():]
        # an item row has an ISBN / code, a price and is not a heading or totals row
        if CARRIED.search(line) or re.search(r"total|amount in words|terms", line, re.I):
            continue
        if re.search(r"97[89][\d\- ]{9,14}|\b[A-Z0-9&\[\]]{4,}\b", rest) and money_values(rest):
            serials.append(int(m.group(1)))
    if not serials:
        return None, "item rows not recognised"
    uniq = sorted(set(serials))
    for v in reversed(uniq):  # highest serial that is backed by a plausible run of rows (ignores OCR garbage)
        below = sum(1 for x in uniq if x <= v)
        if below >= 0.6 * v:
            return v, f"highest item number on the invoice ({below} item rows read)"
    return len(uniq), f"{len(uniq)} item rows counted"


def _sum_quantities(text):
    """Add up the quantity column; each row is cross-checked as gross / unit price (fixes OCR misreads)."""
    qty_sum, rows = 0, 0
    for line in text.splitlines():
        if CARRIED.search(line) or re.search(r"total", line, re.I):
            continue
        rprice = re.search(r"(?<![A-Za-z])[RK]\d{2,5}[.,]\d\d.*\d\s*%", line)
        if not re.match(r"^\s*[\[(|]?\s*\d{1,4}", line) and not rprice:
            continue
        cur = re.search(r"(?:Rs\.?|INR|₹|£|\$|€|USD|EUR|GBP)\b|(?<![A-Za-z])[RK](?=\d{2,5}[.,]\d\d)", line)
        if not cur:
            continue
        q = None
        pct = re.search(r"(\d{1,2}(?:\.\d)?)\s*%", line)
        vals = money_values(re.sub(r"\d{1,2}(?:\.\d)?\s*%", " ", line[cur.end():]))
        m = re.search(r"(\d{1,4})\s*[|\])}]?\s*$", line[:cur.start()])
        text_q = int(m.group(1)) if m else None

        def near(a, b):
            return abs(a - b) <= max(Decimal("1"), b * Decimal("0.003"))

        if vals and vals[0] > 0 and pct and len(vals) >= 2:  # price, qty, discount %, amount  (dot-matrix invoices)
            price, amount = vals[0], vals[-1]
            disc = 1 - Decimal(pct.group(1)) / 100
            between = re.findall(r"(?<![\d.,])(\d{1,3})(?![\d.,%])", line[cur.end():pct.start()])
            for cand in [int(x) for x in between] + list(range(1, 51)):
                if 1 <= cand <= 999 and near(price * cand * disc, amount):
                    q = cand
                    break
        if q is None and vals and vals[0] > 0:
            price, rest = vals[0], vals[1:]
            if text_q and 1 <= text_q <= 999 and any(near(text_q * price, v) for v in rest):
                q = text_q  # printed quantity agrees with the row's amounts
            elif rest:
                r = int((rest[0] / price).to_integral_value())
                if 1 <= r <= 999 and near(r * price, rest[0]) and (r == 1 or len(rest) < 3 or any(
                        near(rest[0] * (1 - d / 100), a) or near(rest[0] - d, a) for d, a in [(rest[1], rest[2])])):
                    q = r  # quantity repaired from gross / unit price
        if q is None:
            q = text_q if text_q and text_q <= 999 else None
        if q:
            qty_sum += q
            rows += 1
    return qty_sum, rows


def _volumes(text, titles):
    hits = [int(x) for x in TOTAL_BOOKS.findall(text)]
    if hits:
        return hits[-1], "'Total No. of Books' line"
    m = re.findall(r"total\s*(?:qty|quantity)\s*[.:\-|]*\s*(\d{1,6})", text, re.I)
    if m:
        return int(m[-1]), "'Total Qty' line"
    # multi-page invoices: last 'Brought Forward' quantity + the rows after it
    bf = list(re.finditer(r"^.*brought\s*f[o0]rward.*$", text, re.I | re.M))
    base = None
    if bf:
        line = re.sub(r"(?:from\s*)?p[a-z]{2,3}e?\s*(?:no\.?)?\s*\d{1,3}", " ", bf[-1].group(0), flags=re.I)  # drop "FROM PAGE 3"
        line = re.sub(r"brought\s*f[o0]rward", " ", line, flags=re.I)
        ints = [int(x) for x in re.findall(r"(?<![\d,.])(\d{1,5})(?![\d,.])", line)]
        base = ints[0] if ints else None
    if base is not None:
        tail = text[bf[-1].end():]
        add, n = _sum_quantities(tail)
        return base + add, f"'Brought Forward' quantity ({base}) plus {n} item rows on the last page"
    qty_sum, rows = _sum_quantities(text)
    if rows and titles and rows >= 0.6 * titles:
        if rows < titles:  # some rows unreadable: assume one copy each for the missing rows
            return qty_sum + (titles - rows), f"quantity column added up ({rows} of {titles} rows read; missing rows counted as 1)"
        return qty_sum, f"quantity column added up ({rows} rows)"
    if titles:
        return titles, "assumed one copy per title (quantity column not readable)"
    return None, "not found"


def _amount(text):
    lines = text.splitlines()
    cands = []
    for i, line in enumerate(lines):
        low = line.lower()
        toks = re.findall(r"[a-z]+", low)
        is_net = bool(re.search(r"n[e3][tf]\s*(?:amount|amt|total|tota|payable)", low)) or (
            any(fuzzy_word(a, "net") for a in toks) and any(
                fuzzy_word(b, "total", 0.6) or fuzzy_word(b, "amount", 0.7) or fuzzy_word(b, "payable", 0.7) for b in toks))
        is_grand = "grand" in low or "payable" in low or "invoice total" in low or "bill amount" in low
        if (is_net or is_grand) and not CARRIED.search(line):
            vals = money_values(line) or (money_values(lines[i + 1]) if i + 1 < len(lines) else [])
            if vals:
                cands.append((3, vals[-1], f"'{line.strip()[:40]}' line"))
        elif re.search(r"\btotal\b", low) and not CARRIED.search(line) and "words" not in low:
            vals = [v for v in money_values(line) if v >= 10]
            if vals:
                cands.append((2, vals[-1], "'Total' line"))
    words_val = None
    m = re.search(r"(?:rupees|amount in words|rs\.)\s*[:\-.]*\s*([A-Za-z ,\-]{8,200}?)\s*(?:only|$|(?=[\d(]))", text, re.I | re.M)
    if m:
        words_val = words_to_number(m.group(1))
    if words_val:
        for rank, v, how in sorted(cands, key=lambda c: -c[0]):
            if abs(v - words_val) < 1:
                return v, how + ", confirmed by the amount in words"
    gross = max((c[1] for c in cands if c[0] == 2), default=None)
    if gross:  # a net total cannot be far above the invoice total: strip OCR noise digits ("91485643" -> "1485643")
        fixed = []
        for rank, v, how in cands:
            if rank == 3 and v > gross * Decimal("1.02"):
                digits = f"{v:.2f}"
                while len(digits) > 4 and to_decimal(digits) > gross * Decimal("1.02"):
                    digits = digits[1:]
                nv = to_decimal(digits)
                if nv and nv >= gross * Decimal("0.5"):
                    fixed.append((rank, nv, how + " (stray OCR digits removed)"))
                continue
            fixed.append((rank, v, how))
        cands = fixed
    if words_val:
        for rank, v, how in sorted(cands, key=lambda c: -c[0]):
            if abs(v - words_val) < 1:
                return v, how + ", confirmed by the amount in words"
    if cands:
        top = max(c[0] for c in cands)
        rank, v, how = [c for c in cands if c[0] == top][-1]  # the last net/grand total on the invoice
        note = how
        if words_val and abs(v - words_val) >= 1:
            note += f" (amount in words reads {words_val:,}; please check)"
        return v, note
    if words_val:  # no labelled total: use the printed figure that matches the amount in words
        near_vals = [v for line in lines for v in money_values(line) if abs(v - words_val) <= max(5, words_val * Decimal("0.002"))]
        if near_vals:
            return near_vals[-1], "figure matching the amount in words"
        return Decimal(words_val).quantize(Decimal("0.01")), "from the amount in words"
    return None, "not found"


MATERIAL_HINTS = [  # (type, words that point to it) - checked on the whole invoice text
    ("DATABASES", r"data\s*base|e-?resource|online\s+access|e-?journals?\s+package|platform\s+access|subscription\s+to\s+(?:the\s+)?online|"
                  r"user\s+licen[cs]e|ip\s+(?:based|authenticat)|remote\s+access|j-?gate|scopus|web\s+of\s+science|ebsco|proquest|"
                  r"delnet|n-?list|ieee\s+xplore|sciencedirect|springer\s*link|jstor|emerald\s+insight|e-?books?\s+package"),
    ("MAGAZINES", r"magazine|newspaper|news\s*paper|periodicals?\s+\(?general|weekly|fortnightly|daily\s+paper"),
    ("JOURNALS", r"journals?|periodicals?|volume\s+\d+\s*,?\s*issue|vol\.?\s*\d+\s*(?:no|issue)|subscription\s+(?:for|period)|"
                 r"issn|annual\s+subscription"),
]


def guess_material(text, titles=None):
    """Books / databases / journals / magazines / miscellaneous, from the words on the invoice."""
    low = text.lower()
    scores = {}
    for kind, rx in MATERIAL_HINTS:
        scores[kind] = len(re.findall(rx, low))
    isbns = len(re.findall(r"97[89][\d\- ]{9,14}", text))
    if isbns >= 2 or (isbns and not any(scores.values())):
        return "BOOKS", f"{isbns} ISBN numbers on the invoice"
    best = max(scores, key=scores.get)
    if scores[best]:
        return best, f"words such as '{re.search(dict(MATERIAL_HINTS)[best], low).group(0)}' on the invoice"
    if re.search(r"\bbooks?\b|author|publisher|edition", low) and titles:
        return "BOOKS", "book titles / authors listed"
    return "MISC", "no books, journals, magazines or databases recognised"


def extract(text, known_vendors=()):
    res, how = {}, {}
    res["vendor"], how["vendor"] = _find_vendor(text, known_vendors)
    m = INV_NO.search(text)
    if m:
        res["invoice_no"] = _clean_code(m.group(1))
        how["invoice_no"] = "'Invoice No.' label"
        d = parse_any_date(text[m.end(): m.end() + 60])
        if d:
            res["invoice_date"] = d[0]
            how["invoice_date"] = "date next to the invoice number"
    if "invoice_date" not in res:  # the date printed most often next to 'Date' (each page header repeats it)
        from collections import Counter

        found = []
        for m2 in re.finditer(r"(?:invoice\s*date|bill\s*date|\bdate)\s*[:\-.]*", text, re.I):
            before = text[max(0, m2.start() - 40): m2.start()].lower()
            if re.search(r"order|p\.?\s*o\b|due|delivery|ack", before):
                continue
            d = parse_any_date(text[m2.end(): m2.end() + 40])
            if d and 2000 <= d[0].year <= date.today().year + 1:
                found.append(d[0])
        if found:
            best, n = Counter(found).most_common(1)[0]
            res["invoice_date"] = best
            how["invoice_date"] = "'Date' on the invoice" + (f" (same on {n} pages)" if n > 1 else "")
    m = next((x for x in PO_NO.finditer(text) if re.search(r"\d", x.group(1))), None)  # a number, not a column heading
    if m:
        res["po_number"] = _clean_code(m.group(1))
        how["po_number"] = "'PO / Order No.' label"
        after = text[m.end(): m.end() + 120]
        d = parse_any_date(after)
        if d:
            res["po_date"], how["po_date"] = d[0], "date next to the PO number"
    res["no_of_titles"], how["no_of_titles"] = _titles(text)
    res["no_of_books"], how["no_of_books"] = _volumes(text, res["no_of_titles"])
    res["amount"], how["amount"] = _amount(text)
    res["material_type"], how["material_type"] = guess_material(text, res["no_of_titles"])
    if res.get("invoice_date") and res.get("po_date") and res["po_date"] > res["invoice_date"]:
        how["po_date"] += " (later than invoice date - check)"
    res["how"] = how
    found = sum(1 for k in ("vendor", "invoice_no", "invoice_date", "amount", "no_of_books") if res.get(k))
    res["confidence"] = "high" if found == 5 else "medium" if found >= 3 else "low"
    return res


def read_invoice(data, filename, known_vendors=(), ocr_lang="eng", stored_text=None):
    """Returns {"invoices": [ {fields..., pages:(a,b)} ], "notes": [...], "text": full_text}.
    ``stored_text`` = text already extracted at upload (pages separated by form feeds) - avoids a second OCR."""
    if stored_text and len(stored_text.strip()) > 40:
        pages, notes = list(stored_text.split(PAGE_BREAK)), ["used the text read (OCR) when the file was uploaded"]
    else:
        pages, notes = pages_from_file(data, filename, ocr_lang)
    full = "\n".join(pages)
    if len(full.strip()) < 20:
        raise ReaderError("No readable text was found in this file.")
    found = []
    for first, last, text in segments(pages):
        r = extract(text, known_vendors)
        r["pages"] = (first, last)
        found.append(r)
    if len(found) > 1:
        nos = {f.get("invoice_no") for f in found}
        if len(nos) == 1 and None not in nos:
            notes.append(f"This file contains {len(found)} versions of the same invoice "
                         f"(pages {', '.join(f'{f['pages'][0]}-{f['pages'][1]}' for f in found)}). "
                         "The last version is used; check which one is correct.")
    return {"invoices": found, "notes": notes, "text": full}
