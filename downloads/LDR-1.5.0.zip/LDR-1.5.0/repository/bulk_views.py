"""Bulk upload pages and bulk approval."""
from django.contrib import messages
from django.core.exceptions import ValidationError
from django.http import HttpResponse, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from .models import BulkImport, Document, Status
from .services import bulk as B
from .services import lifecycle as L
from .views import _errors, require


@require("can_register")
def bulk_upload(request):
    if request.method == "POST":
        up = request.FILES.get("zipfile")
        if not up or not up.name.lower().endswith(".zip"):
            messages.error(request, "Choose a .zip file containing the metadata Excel sheet and the document files.")
            return redirect("bulk_upload")
        batch = B.create_batch(up, request.user)
        return redirect("bulk_detail", batch.pk)
    mine = BulkImport.objects.all() if request.user.can_approve else BulkImport.objects.filter(created_by=request.user)
    return render(request, "repository/bulk_upload.html", {"batches": mine.select_related("created_by")[:20],
                                                           "columns": B.COLUMNS})


@require("can_register")
def bulk_detail(request, pk):
    batch = get_object_or_404(BulkImport, pk=pk)
    if batch.created_by_id != request.user.pk and not request.user.can_approve:
        return redirect("bulk_upload")
    import json

    data = json.loads(batch.report or "{}")
    return render(request, "repository/bulk_detail.html", {
        "b": batch, "rows": data.get("rows", []), "problems": data.get("problems", []),
        "results": data.get("results", []),
        "incomplete": [r for r in data.get("rows", []) if r.get("missing_meta")],
    })


@require("can_register")
@require_POST
def bulk_start(request, pk):
    batch = get_object_or_404(BulkImport, pk=pk, created_by=request.user, state=BulkImport.State.VALIDATED)
    B.start_import(batch, submit_for_approval=request.POST.get("submit") == "1")
    return redirect("bulk_detail", batch.pk)


@require("can_register")
def bulk_status(request, pk):
    b = get_object_or_404(BulkImport, pk=pk)
    return JsonResponse({"state": b.state, "processed": b.processed, "total": b.total_rows,
                         "imported": b.imported, "failed": b.failed})


@require("can_register")
def bulk_template(request):
    resp = HttpResponse(B.build_template(), content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    resp["Content-Disposition"] = 'attachment; filename="LDR_bulk_upload_template.xlsx"'
    return resp


@require("can_register")
def bulk_sample(request):
    resp = HttpResponse(B.build_sample_zip(), content_type="application/zip")
    resp["Content-Disposition"] = 'attachment; filename="LDR_bulk_upload_sample.zip"'
    return resp


@require("can_approve")
@require_POST
def approve_selected(request):
    ids = [int(x) for x in request.POST.getlist("ids") if x.isdigit()]
    docs = Document.objects.filter(pk__in=ids, status=Status.PENDING_APPROVAL)
    ok, failed = 0, []
    for doc in docs:
        try:
            L.approve(doc, request.user, request.POST.get("remarks", "") or "Bulk approval", request,
                      retention=request.POST.get("retention") or "default",
                      access=request.POST.get("access") or None)
            ok += 1
        except ValidationError as e:
            failed.append(f"{doc.doc_id}: {'; '.join(e.messages)}")
    if ok:
        messages.success(request, f"{ok} document(s) approved.")
    for f in failed:
        messages.error(request, f)
    if not ids:
        messages.warning(request, "Tick the documents you want to approve.")
    return redirect("approvals")
