from django import template

from ..services.invoices import money

register = template.Library()


@register.filter
def inr(value):
    """12345678.5 -> 1,23,45,678.50 (Indian digit grouping)."""
    if value in (None, ""):
        return ""
    try:
        return money(value)
    except Exception:
        return value


@register.filter
def dmy(value):
    """'2025-08-16' or a date -> 16-08-2025."""
    if not value:
        return ""
    from datetime import date

    try:
        d = value if isinstance(value, date) else date.fromisoformat(str(value)[:10])
        return d.strftime("%d-%m-%Y")
    except ValueError:
        return value
