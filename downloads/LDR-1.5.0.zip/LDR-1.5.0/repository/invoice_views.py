"""Invoice register, statistics and reports."""
import json

from django import forms
from django.contrib import messages
from django.core.exceptions import PermissionDenied
from django.http import HttpResponse, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.http import require_POST

from .forms import BootstrapMixin, DateInput
from .models import AcquisitionType, Action, Document, InvoiceRecord, parse_accession_range
from .services import invoices as I
from .services.audit import audit
from .views import require

EDITABLE = {
    "financial_year": "text", "vendor": "text", "accession_range": "text", "no_of_books": "int", "no_of_titles": "int",
    "invoice_no": "text", "invoice_date": "date", "po_number": "text", "po_date": "date", "amount": "money",
    "acquisition_type": "type", "material_type": "material", "remarks": "text",
}


class InvoiceForm(BootstrapMixin, forms.ModelForm):
    class Meta:
        model = InvoiceRecord
        fields = ["vendor", "material_type", "invoice_no", "invoice_date", "po_number", "po_date", "accession_range",
                  "no_of_books", "no_of_titles", "amount", "acquisition_type", "financial_year", "remarks"]
        widgets = {"invoice_date": DateInput(), "po_date": DateInput()}

    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self.fields["financial_year"].help_text = "Leave blank to calculate from the invoice date (April-March)"
        self._bootstrap()


def _ids(request):
    raw = request.GET.get("ids") or request.POST.get("ids") or ""
    return [int(x) for x in raw.split(",") if x.strip().isdigit()]


@require("can_register")
def register(request):
    params = request.GET
    qs = I.filtered(params)
    t = I.totals(qs)
    years = (InvoiceRecord.objects.exclude(financial_year="").values_list("financial_year", flat=True)
             .distinct().order_by("-financial_year"))
    vendors = InvoiceRecord.objects.values_list("vendor", flat=True).distinct().order_by("vendor")
    query = params.copy()
    return render(request, "repository/invoice_register.html", {
        "rows": qs.order_by("-financial_year", "invoice_date", "id"), "t": t, "years": years, "vendors": vendors,
        "types": AcquisitionType.choices, "params": params, "query": query.urlencode(),
        "by_vendor": I.by_vendor(qs), "by_year": I.by_year(qs), "describe": I.describe_filters(params),
        "can_edit": request.user.can_catalogue, "all_count": InvoiceRecord.objects.count(),
        "review_count": InvoiceRecord.objects.filter(needs_review=True).count(),
        "by_material": I.by_material(qs), "materials": __import__("repository.models", fromlist=["MaterialType"]).MaterialType.choices,
        "unread_docs": _unread_count(request.user), "catchup": _catchup(),
        "first_review": InvoiceRecord.objects.filter(needs_review=True).order_by("id").values_list("pk", flat=True).first(),
    })


@require("can_register")
def export(request, fmt):
    ids = _ids(request)
    qs = I.filtered(request.GET, ids).order_by("financial_year", "invoice_date", "id")
    title = I.describe_filters(request.GET, ids)
    stamp = timezone.localdate().strftime("%Y%m%d")
    if fmt == "xlsx":
        data, ctype = I.export_excel(qs, title), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    elif fmt == "pdf":
        data, ctype = I.export_pdf(qs, title), "application/pdf"
    elif fmt == "docx":
        data, ctype = I.export_word(qs, title), "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    else:
        raise PermissionDenied
    audit(Action.DOWNLOADED, request, details=f"Invoice report ({fmt}) - {title} - {qs.count()} invoices")
    resp = HttpResponse(data, content_type=ctype)
    resp["Content-Disposition"] = f'attachment; filename="invoice_report_{stamp}.{fmt}"'
    return resp


def _coerce(field, value):
    kind = EDITABLE[field]
    v = (value or "").strip()
    if kind == "text":
        return v
    if kind == "int":
        if not v:
            return None
        if not v.isdigit():
            raise ValueError(f"'{v}' is not a whole number")
        return int(v)
    if kind == "date":
        if not v:
            return None
        d = I.parse_date(v)
        if not d:
            raise ValueError(f"'{v}' is not a date (use DD-MM-YYYY)")
        return d
    if kind == "money":
        if not v:
            return None
        a = I.parse_amount(v)
        if a is None:
            raise ValueError(f"'{v}' is not an amount")
        return a
    if kind == "material":
        from .models import MaterialType

        if not v:
            return ""
        for code, label in MaterialType.choices:
            if v.upper() == code or label.lower().startswith(v.lower()) or v.lower().rstrip("s") in label.lower():
                return code
        raise ValueError(f"Invoice for must be one of: {', '.join(l for _, l in MaterialType.choices)}")
    if kind == "type":
        for code, label in AcquisitionType.choices:
            if v.upper() == code or v.lower() == label.lower() or label.lower().startswith(v.lower()):
                return code
        raise ValueError(f"Type must be one of: {', '.join(l for _, l in AcquisitionType.choices)}")
    return v


@require("can_catalogue")
@require_POST
def save_edits(request):
    """In-table editing: {"changes": {"<id>": {"field": "value"}}, "new": [{...}], "delete": [ids]}"""
    try:
        payload = json.loads(request.body.decode("utf-8"))
    except ValueError:
        return JsonResponse({"ok": False, "error": "Invalid data"}, status=400)
    errors, changed, created, deleted = [], 0, 0, 0
    for sid, fields in (payload.get("changes") or {}).items():
        rec = InvoiceRecord.objects.filter(pk=int(sid)).first()
        if not rec:
            continue
        before = {}
        for f, v in fields.items():
            if f not in EDITABLE:
                continue
            try:
                new = _coerce(f, v)
            except ValueError as e:
                errors.append(f"Row {sid}, {f}: {e}")
                continue
            before[f] = getattr(rec, f)
            setattr(rec, f, new)
            if f == "accession_range" and "no_of_books" not in fields:
                rec.no_of_books = parse_accession_range(new)[0]
        if before:
            if "invoice_date" in before and "financial_year" not in fields and rec.invoice_date:
                pass  # keep the register's year unless changed explicitly
            rec.save()
            changed += 1
            audit(Action.INVOICE_CHANGE, request, details=f"Invoice #{rec.pk} {rec.vendor} {rec.invoice_no}: "
                  + "; ".join(f"{k}: {before[k]} -> {getattr(rec, k)}" for k in before))
    for fields in payload.get("new") or []:
        if not (fields.get("vendor") or "").strip():
            continue
        rec = InvoiceRecord(created_by=request.user)
        ok = True
        for f, v in fields.items():
            if f in EDITABLE:
                try:
                    setattr(rec, f, _coerce(f, v))
                except ValueError as e:
                    errors.append(f"New row {fields.get('vendor')}: {e}")
                    ok = False
        if ok:
            rec.save()
            created += 1
            audit(Action.INVOICE_CHANGE, request, details=f"Added invoice #{rec.pk} {rec.vendor} {rec.invoice_no} {rec.amount}")
    for sid in payload.get("delete") or []:
        rec = InvoiceRecord.objects.filter(pk=int(sid)).first()
        if rec:
            audit(Action.INVOICE_CHANGE, request, details=f"Deleted invoice entry #{rec.pk} {rec.vendor} {rec.invoice_no} {rec.amount}")
            rec.delete()
            deleted += 1
    return JsonResponse({"ok": not errors, "errors": errors, "changed": changed, "created": created, "deleted": deleted})


@require("can_catalogue")
def import_index(request):
    if request.method == "POST" and request.FILES.get("workbook"):
        f = request.FILES["workbook"]
        if not f.name.lower().endswith((".xlsx", ".xlsm")):
            messages.error(request, "Please choose an Excel .xlsx file.")
            return redirect("invoice_import")
        try:
            res = I.import_index_workbook(f, request.user)
        except Exception as exc:
            messages.error(request, f"Could not read the workbook: {exc.__class__.__name__}")
            return redirect("invoice_import")
        audit(Action.INVOICE_CHANGE, request, details=f"Imported invoice index {f.name}: {res['created']} added, "
                                                      f"{res['skipped']} duplicates skipped ({', '.join(res['sheets'])})")
        messages.success(request, f"Imported {res['created']} invoices ({', '.join(res['sheets']) or 'none'}). "
                                  f"{res['skipped']} already in the register were skipped.")
        return redirect("invoices")
    return render(request, "repository/invoice_import.html")


@require("can_catalogue")
def invoice_edit(request, pk=None, doc_pk=None):
    rec = get_object_or_404(InvoiceRecord, pk=pk) if pk else None
    doc = get_object_or_404(Document, pk=doc_pk) if doc_pk else (rec.document if rec else None)
    initial = {}
    if doc and not rec:
        initial = {"vendor": doc.received_from, "invoice_no": doc.reference_number, "invoice_date": doc.document_date,
                   "amount": doc.amount, "material_type": doc.material_type}
    form = InvoiceForm(request.POST or None, instance=rec, initial=initial)
    if request.method == "POST" and form.is_valid():
        r = form.save(commit=False)
        if doc:
            r.document = doc
        if not rec:
            r.created_by = request.user
        r.save()
        audit(Action.INVOICE_CHANGE, request, document=doc,
              details=f"{'Updated' if rec else 'Added'} invoice details #{r.pk}: {r.vendor} {r.invoice_no} Rs {r.amount}")
        messages.success(request, "Invoice details saved.")
        return redirect(doc.get_absolute_url() if doc else "invoices")
    return render(request, "repository/simple_form.html", {
        "form": form, "title": ("Edit invoice details" if rec else "Add invoice details") + (f" · {doc.doc_id}" if doc else ""),
        "back": "invoices",
        "help": "These details feed the invoice register and statistics (number of invoices, books, amounts, vendors). "
                "No. of books is calculated from the accession range when left blank.",
    })


# ----------------------------------------------------------------------------- automatic reading
def _ocr_ok():
    from .services.extract import ocr_available

    return ocr_available()


@require("can_register")
def invoice_upload(request):
    from .models import BulkImport, Confidentiality, Department
    from .services import invoice_jobs as J

    if request.method == "POST":
        files = request.FILES.getlist("files")
        if not files:
            messages.error(request, "Choose one or more invoice files (PDF, scanned image or Excel).")
            return redirect("invoice_upload")
        dept = Department.objects.filter(pk=request.POST.get("department") or 0).first()
        access = request.POST.get("access") or ""
        if access not in dict(Confidentiality.choices):
            access = ""
        from .models import MaterialType

        material = request.POST.get("material") or ""
        if material not in dict(MaterialType.choices):
            material = ""
        batch = J.create_upload_batch(files, request.user, dept, access, material)
        if batch.total_rows:
            J.start_upload(batch, submit_for_approval=request.POST.get("submit") == "1")
        return redirect("invoice_upload_detail", batch.pk)
    mine = BulkImport.objects.filter(kind="invoices")
    if not request.user.can_approve:
        mine = mine.filter(created_by=request.user)
    return render(request, "repository/invoice_upload.html", {
        "ocr": _ocr_ok(), "batches": mine.select_related("created_by")[:15],
        "departments": Department.objects.all(), "access_choices": Confidentiality.choices,
        "materials": __import__("repository.models", fromlist=["MaterialType"]).MaterialType.choices,
        "has_category": J.invoice_category() is not None,
    })


@require("can_register")
def invoice_upload_detail(request, pk):
    from .models import BulkImport

    b = get_object_or_404(BulkImport, pk=pk, kind="invoices")
    if b.created_by_id != request.user.pk and not request.user.can_approve:
        return redirect("invoice_upload")
    data = json.loads(b.report or "{}")
    results = data.get("results", [])
    live = {r.pk: r for r in InvoiceRecord.objects.filter(
        pk__in=[rec["pk"] for res in results for rec in res.get("records", [])])}
    for res in results:  # show the register's current values (after any corrections), not the first reading
        kept = []
        for rec in res.get("records", []):
            cur = live.get(rec["pk"])
            if cur is None:
                continue
            rec.update(material=cur.get_material_type_display() if cur.material_type else "",
                       material_type=cur.material_type, vendor=cur.vendor, invoice_no=cur.invoice_no, invoice_date=cur.invoice_date, po_number=cur.po_number,
                       po_date=cur.po_date, no_of_titles=cur.no_of_titles, no_of_books=cur.no_of_books,
                       amount=str(cur.amount) if cur.amount is not None else None, needs_review=cur.needs_review)
            kept.append(rec)
        res["records"] = kept
    tot = {"titles": 0, "books": 0, "amount": 0, "n": 0}
    for r in results:
        for rec in r.get("records", []):
            tot["n"] += 1
            tot["titles"] += rec.get("no_of_titles") or 0
            tot["books"] += rec.get("no_of_books") or 0
            try:
                tot["amount"] += float(rec.get("amount") or 0)
            except ValueError:
                pass
    return render(request, "repository/invoice_upload_detail.html", {
        "b": b, "results": results, "problems": data.get("problems", []), "tot": tot, "ocr": _ocr_ok(),
        "ids": ",".join(str(rec["pk"]) for r in results for rec in r.get("records", [])),
    })


@require("can_register")
@require_POST
def invoice_read(request, doc_pk):
    """'Read details from invoice file' button on a document page."""
    from .services import invoice_jobs as J
    from .services.lifecycle import can_open

    doc = get_object_or_404(Document, pk=doc_pk)
    if not can_open(request.user, doc):
        raise PermissionDenied
    try:
        res = J.read_into_register(doc, request.user, request)
    except Exception as exc:
        messages.error(request, f"The invoice could not be read: {exc}")
        return redirect(doc.get_absolute_url())
    for e in res["errors"]:
        messages.error(request, e)
    if res["records"]:
        r = res["records"][0]
        extra = f" ({len(res['records'])} invoices found)" if len(res["records"]) > 1 else ""
        messages.success(request, f"Read{extra}: {r['vendor']} · invoice {r.get('invoice_no') or '?'} · "
                                  f"{r.get('no_of_titles') or '?'} titles · {r.get('no_of_books') or '?'} volumes · "
                                  f"Rs {r.get('amount') or '?'}. Please check the values.")
        return redirect("invoice_review", r["pk"])
    if not res["errors"]:
        messages.warning(request, "No invoice details were found in this document's files.")
    return redirect(doc.get_absolute_url())


@require("can_register")
def invoice_review(request, pk):
    """Check automatically read values against the invoice image and confirm them."""
    rec = get_object_or_404(InvoiceRecord.objects.select_related("document"), pk=pk)
    info = rec.info()
    doc = rec.document
    can_edit = request.user.can_catalogue
    if request.method == "POST" and can_edit:
        alt = request.POST.get("use_alternative")
        if alt is not None and alt.isdigit() and int(alt) < len(info.get("alternatives", [])):
            chosen = info["alternatives"][int(alt)]
            current = info.get("read")
            for f in ("vendor", "invoice_no", "invoice_date", "po_number", "po_date", "no_of_titles", "no_of_books", "amount"):
                v = chosen.get(f)
                if f in ("invoice_date", "po_date") and v:
                    v = I.parse_date(v)
                if v not in (None, ""):
                    setattr(rec, f, v)
            info["alternatives"][int(alt)] = current
            info["read"] = chosen
            rec.read_info = json.dumps(info, default=str)
            if rec.invoice_date:
                from .models import financial_year_of

                rec.financial_year = financial_year_of(rec.invoice_date)
            rec.save()
            audit(Action.INVOICE_CHANGE, request, document=doc,
                  details=f"Invoice #{rec.pk}: switched to version on pages {chosen.get('pages')}")
            messages.info(request, f"Using the version on pages {'-'.join(str(p) for p in chosen.get('pages', []))}.")
            return redirect("invoice_review", rec.pk)
        form = InvoiceForm(request.POST, instance=rec)
        if form.is_valid():
            before = {f: getattr(InvoiceRecord.objects.get(pk=rec.pk), f) for f in form.changed_data}
            r = form.save(commit=False)
            r.needs_review = False
            r.reviewed_by = request.user
            r.reviewed_at = timezone.now()
            r.save()
            audit(Action.INVOICE_CHANGE, request, document=doc,
                  details=f"Invoice #{r.pk} checked and confirmed ({r.vendor} {r.invoice_no} Rs {r.amount})"
                  + ("; corrected " + "; ".join(f"{k}: {before[k]} -> {getattr(r, k)}" for k in before) if before else ""))
            messages.success(request, "Invoice details confirmed.")
            nxt = InvoiceRecord.objects.filter(needs_review=True).exclude(pk=r.pk).order_by("id").first()
            if request.POST.get("next") == "1" and nxt:
                return redirect("invoice_review", nxt.pk)
            return redirect("invoices")
    else:
        form = InvoiceForm(instance=rec)
    preview = None
    if doc:
        from .services.lifecycle import can_open

        if can_open(request.user, doc):
            preview = doc.files.filter(role="MASTER", is_current=True, purged=False).order_by("id").first()
    read = info.get("read", {})
    labels = {"vendor": "Vendor", "invoice_no": "Invoice no.", "invoice_date": "Invoice date", "po_number": "PO number",
              "po_date": "PO date", "no_of_titles": "Titles (line items)", "no_of_books": "Volumes (quantity)",
              "amount": "Net amount"}
    how = [(labels[k], read.get(k), read.get("how", {}).get(k, "not found")) for k in labels]
    return render(request, "repository/invoice_review.html", {
        "page_range": range(min((preview.pages or 1) if preview else 0, 40)),
        "rec": rec, "form": form, "info": info, "how": how, "doc": doc, "preview": preview, "can_edit": can_edit,
        "pending": InvoiceRecord.objects.filter(needs_review=True).count(),
    })


def _unread_count(user):
    from .services import invoice_jobs as J

    return J.unread_invoice_documents().count() if user.can_catalogue else 0


def _catchup():
    from .services import invoice_jobs as J

    return J.catchup_status()


@require("can_catalogue")
@require_POST
def invoice_read_pending(request):
    """Read every invoice document that is not yet in the register (uploaded via 'Register document')."""
    from .services import invoice_jobs as J

    if J.read_unread_documents(request.user):
        messages.info(request, "Reading the invoice documents in the background. The register fills in as each one "
                               "is read (scanned invoices take up to a minute each) - refresh this page.")
    else:
        messages.info(request, "Already reading invoice documents - please wait.")
    return redirect("invoices")
