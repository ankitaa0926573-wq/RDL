LDR - Library Document Repository : installing on Windows
==========================================================

If Windows says "Smart App Control blocked a file that may be unsafe"
or "Windows protected your PC" when you open install_windows.bat:

Windows marks every file downloaded from the internet. LDR's installer is a
plain script that is not code-signed, so Smart App Control blocks it.
LDR itself is safe: every LDR release is checked against a digital signature
before it is installed or updated.

FIX (one time, takes 10 seconds)
  1. Delete the folder you unzipped.
  2. Right-click the downloaded LDR-x.y.z.zip  ->  Properties
  3. At the bottom of the General tab tick  [x] Unblock  ->  OK
  4. Unzip again (for example to C:\LDR) and run install_windows.bat
     (right-click -> Run as administrator).

Already unzipped? Instead of steps 1-3, open PowerShell and run
  Get-ChildItem -Recurse C:\LDR | Unblock-File
(use the folder where you unzipped LDR), then run install_windows.bat.

University / office PCs managed by an IT department
  If Windows still blocks LDR, ask IT to allow the LDR folder (for example
  C:\LDR) in their application-control policy (App Control for Business /
  WDAC / AppLocker). LDR runs with the official, signed Python from
  python.org.

After installation LDR updates itself from inside the application
(Settings & backup -> Software updates), so this is needed only once.
