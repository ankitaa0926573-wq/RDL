@echo off
title LDR - Library Document Repository
cd /d "%~dp0"
set PYEXE=python\python.exe
if not exist "%PYEXE%" set PYEXE=.venv\Scripts\python.exe
if not exist "%PYEXE%" (
  echo LDR is not installed yet. Run LDR-Setup.exe or install_windows.bat first.
  pause
  exit /b 1
)
"%PYEXE%" run_server.py --open
REM exit code 3 = LDR is already running in the background; the browser was opened.
if "%errorlevel%"=="3" exit /b 0
pause
