; LDR - Library Document Repository : Windows installer (Inno Setup 6)
; Built by tools/build_installer.py - do not run ISCC on this file by hand.
; Everything runs through signed Windows / Python programs - no .bat or .ps1 files are executed,
; so Windows Smart App Control has nothing unsigned to block once this Setup.exe is code-signed.

#ifndef AppVersion
  #define AppVersion "0.0.0"
#endif
#ifndef SourceDir
  #define SourceDir "..\build\stage"
#endif
#ifndef OutDir
  #define OutDir "..\dist"
#endif

#define TaskName "LDR Library Document Repository"
#define FwRule "LDR Library Document Repository"

[Setup]
AppId={{6F0C2E7B-1D4B-4C49-9A51-0B7C1A9E4D2F}
AppName=LDR - Library Document Repository
AppVersion={#AppVersion}
AppVerName=LDR - Library Document Repository {#AppVersion}
AppPublisher=LDR - Library Document Repository
AppPublisherURL=https://ankitaa0926573-wq.github.io/RDL/
DefaultDirName={sd}\LDR
DisableDirPage=auto
DisableProgramGroupPage=yes
DefaultGroupName=LDR - Library Document Repository
PrivilegesRequired=admin
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0
OutputDir={#OutDir}
OutputBaseFilename=LDR-Setup-{#AppVersion}
Compression=lzma2/ultra
SolidCompression=yes
LZMAUseSeparateProcess=yes
WizardStyle=modern
SetupIconFile=ldr.ico
UninstallDisplayIcon={app}\installer\ldr.ico
UninstallDisplayName=LDR - Library Document Repository
CloseApplications=no
RestartApplications=no
#ifdef SignTool
SignTool={#SignTool}
SignedUninstaller=yes
#endif

[Languages]
Name: "en"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "servermode"; Description: "Server mode: keep this computer and its network awake while plugged in (recommended for the LDR server)"
Name: "desktopicon"; Description: "Desktop shortcut that opens LDR in the browser"

[Files]
Source: "{#SourceDir}\app\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "{#SourceDir}\python\*"; DestDir: "{app}\python"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "{#SourceDir}\ocr\*"; DestDir: "{app}\ocr"; Flags: ignoreversion recursesubdirs createallsubdirs

[Dirs]
Name: "{app}\data"; Permissions: system-full admins-full

[Icons]
Name: "{group}\Open LDR"; Filename: "http://localhost:{code:GetPort}/"; IconFilename: "{app}\installer\ldr.ico"
Name: "{group}\LDR - restart server"; Filename: "{sys}\schtasks.exe"; Parameters: "/Run /TN ""{#TaskName}"""; IconFilename: "{app}\installer\ldr.ico"; Comment: "Starts LDR again (it normally starts by itself with Windows)"
Name: "{group}\Uninstall LDR"; Filename: "{uninstallexe}"
Name: "{commondesktop}\LDR - Library Document Repository"; Filename: "http://localhost:{code:GetPort}/"; IconFilename: "{app}\installer\ldr.ico"; Tasks: desktopicon

[Run]
; firewall: other library computers on the LAN can reach LDR
Filename: "{sys}\netsh.exe"; Parameters: "advfirewall firewall delete rule name=""{#FwRule}"""; Flags: runhidden; StatusMsg: "Opening the firewall for the library network..."
Filename: "{sys}\netsh.exe"; Parameters: "advfirewall firewall add rule name=""{#FwRule}"" dir=in action=allow protocol=TCP localport={code:GetPort}"; Flags: runhidden
; server mode (no sleep on AC power, lid close does nothing, network cards stay on)
Filename: "{sys}\powercfg.exe"; Parameters: "/change standby-timeout-ac 0"; Flags: runhidden; Tasks: servermode; StatusMsg: "Setting up server mode..."
Filename: "{sys}\powercfg.exe"; Parameters: "/change hibernate-timeout-ac 0"; Flags: runhidden; Tasks: servermode
Filename: "{sys}\powercfg.exe"; Parameters: "/setacvalueindex SCHEME_CURRENT SUB_BUTTONS LIDACTION 0"; Flags: runhidden; Tasks: servermode
Filename: "{sys}\powercfg.exe"; Parameters: "/setacvalueindex SCHEME_CURRENT SUB_SLEEP UNATTENDSLEEP 0"; Flags: runhidden; Tasks: servermode
Filename: "{sys}\powercfg.exe"; Parameters: "/setacvalueindex SCHEME_CURRENT 19cbb8fa-5279-450e-9fac-8a3d5fedd0c1 12bbebe6-58d6-4636-95bb-3217ef867c1a 0"; Flags: runhidden; Tasks: servermode
Filename: "{sys}\powercfg.exe"; Parameters: "/setactive SCHEME_CURRENT"; Flags: runhidden; Tasks: servermode
Filename: "{sys}\WindowsPowerShell\v1.0\powershell.exe"; Parameters: "-NoProfile -NonInteractive -Command ""Get-NetAdapter -Physical -ErrorAction SilentlyContinue | ForEach-Object {{ Disable-NetAdapterPowerManagement -Name $_.Name -NoRestart -ErrorAction SilentlyContinue }; if ((powercfg /a | Out-String) -match 'S0 Low Power Idle') {{ powercfg /change monitor-timeout-ac 0 }"""; Flags: runhidden; Tasks: servermode
; background service: starts with Windows (no login needed), restarts itself, no time limit
Filename: "{sys}\schtasks.exe"; Parameters: "/Create /TN ""{#TaskName}"" /XML ""{app}\installer\ldr_task.xml"" /F"; Flags: runhidden; StatusMsg: "Registering LDR as a background service..."; BeforeInstall: WriteTaskXml
Filename: "{sys}\WindowsPowerShell\v1.0\powershell.exe"; Parameters: "-NoProfile -NonInteractive -Command ""Register-ScheduledTask -TaskName '{#TaskName}' -Xml (Get-Content -Raw -LiteralPath '{app}\installer\ldr_task.xml') -Force | Out-Null"""; Flags: runhidden
Filename: "{sys}\schtasks.exe"; Parameters: "/Run /TN ""{#TaskName}"""; Flags: runhidden; StatusMsg: "Starting LDR..."
Filename: "{app}\installer\starting.html"; Description: "Open LDR in the browser now"; Flags: postinstall shellexec skipifsilent nowait

[UninstallRun]
Filename: "{sys}\schtasks.exe"; Parameters: "/End /TN ""{#TaskName}"""; Flags: runhidden; RunOnceId: "EndTask"
Filename: "{sys}\schtasks.exe"; Parameters: "/Delete /TN ""{#TaskName}"" /F"; Flags: runhidden; RunOnceId: "DelTask"
Filename: "{sys}\netsh.exe"; Parameters: "advfirewall firewall delete rule name=""{#FwRule}"""; Flags: runhidden; RunOnceId: "DelFw"
Filename: "{sys}\WindowsPowerShell\v1.0\powershell.exe"; Parameters: "-NoProfile -NonInteractive -Command ""Get-CimInstance Win32_Process -Filter \""Name='pythonw.exe' OR Name='python.exe'\"" | Where-Object {{ $_.ExecutablePath -like '{app}\python\*' } | ForEach-Object {{ Stop-Process -Id $_.ProcessId -Force }"""; Flags: runhidden; RunOnceId: "StopPy"

[UninstallDelete]
Type: filesandordirs; Name: "{app}\python"
Type: filesandordirs; Name: "{app}\staticfiles"

[Messages]
FinishedLabel=LDR has been installed and is starting in the background.%n%nIt starts automatically every time this computer is switched on - no window needs to stay open. Other computers in the library open it at http://<this computer's IP address>:8080 (shown on LDR's Settings page).

[Code]
const
  TaskName = '{#TaskName}';

function GetPort(Param: String): String;
var
  S: String;
begin
  Result := '8080';
  if FileExists(ExpandConstant('{app}\ldr_config.ini')) then
  begin
    S := GetIniString('server', 'port', '8080', ExpandConstant('{app}\ldr_config.ini'));
    if S <> '' then Result := S;
  end;
end;

procedure StopRunningLdr();
var
  Code: Integer;
begin
  Exec(ExpandConstant('{sys}\schtasks.exe'), '/End /TN "' + TaskName + '"', '', SW_HIDE, ewWaitUntilTerminated, Code);
  Exec(ExpandConstant('{sys}\WindowsPowerShell\v1.0\powershell.exe'),
    '-NoProfile -NonInteractive -Command "Get-CimInstance Win32_Process -Filter \"Name=''pythonw.exe'' OR Name=''python.exe''\" | ' +
    'Where-Object { $_.CommandLine -like ''*run_server.py*'' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }"',
    '', SW_HIDE, ewWaitUntilTerminated, Code);
  Sleep(1500);
end;

function PrepareToInstall(var NeedsRestart: Boolean): String;
begin
  StopRunningLdr();   { an older LDR in the same folder is updated in place; data and settings are kept }
  Result := '';
end;

function XmlEscape(S: String): String;
begin
  StringChangeEx(S, '&', '&amp;', True);
  StringChangeEx(S, '<', '&lt;', True);
  StringChangeEx(S, '>', '&gt;', True);
  Result := S;
end;

procedure WriteTaskXml();
var
  X: String;
  Lines: TArrayOfString;
begin
  X :=
    '<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">' + #13#10 +
    '  <RegistrationInfo><Description>LDR - Library Document Repository web server</Description></RegistrationInfo>' + #13#10 +
    '  <Triggers><BootTrigger><Enabled>true</Enabled></BootTrigger></Triggers>' + #13#10 +
    '  <Principals><Principal id="Author"><UserId>S-1-5-18</UserId><RunLevel>HighestAvailable</RunLevel></Principal></Principals>' + #13#10 +
    '  <Settings>' + #13#10 +
    '    <MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>' + #13#10 +
    '    <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>' + #13#10 +
    '    <StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>' + #13#10 +
    '    <AllowHardTerminate>true</AllowHardTerminate>' + #13#10 +
    '    <StartWhenAvailable>true</StartWhenAvailable>' + #13#10 +
    '    <RunOnlyIfNetworkAvailable>false</RunOnlyIfNetworkAvailable>' + #13#10 +
    '    <IdleSettings><StopOnIdleEnd>false</StopOnIdleEnd><RestartOnIdle>false</RestartOnIdle></IdleSettings>' + #13#10 +
    '    <AllowStartOnDemand>true</AllowStartOnDemand>' + #13#10 +
    '    <Enabled>true</Enabled><Hidden>false</Hidden><RunOnlyIfIdle>false</RunOnlyIfIdle><WakeToRun>false</WakeToRun>' + #13#10 +
    '    <ExecutionTimeLimit>PT0S</ExecutionTimeLimit>' + #13#10 +
    '    <Priority>7</Priority>' + #13#10 +
    '    <RestartOnFailure><Interval>PT1M</Interval><Count>999</Count></RestartOnFailure>' + #13#10 +
    '  </Settings>' + #13#10 +
    '  <Actions Context="Author"><Exec>' + #13#10 +
    '    <Command>' + XmlEscape(ExpandConstant('{app}\python\pythonw.exe')) + '</Command>' + #13#10 +
    '    <Arguments>"' + XmlEscape(ExpandConstant('{app}\run_server.py')) + '" --background</Arguments>' + #13#10 +
    '    <WorkingDirectory>' + XmlEscape(ExpandConstant('{app}')) + '</WorkingDirectory>' + #13#10 +
    '  </Exec></Actions>' + #13#10 +
    '</Task>' + #13#10;
  SetArrayLength(Lines, 1);
  Lines[0] := X;
  SaveStringsToUTF8File(ExpandConstant('{app}\installer\ldr_task.xml'), Lines, False);
end;

