@echo off
REM LDR background service manager - run LDR without a window, auto-start with Windows.
cd /d "%~dp0"
net session >nul 2>&1
if errorlevel 1 (
  echo Requesting administrator permission ...
  if "%~1"=="" (
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  ) else (
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -ArgumentList '%~1' -Verb RunAs"
  )
  exit /b
)
set ACTION=%1
if not "%ACTION%"=="" goto run

:menu
cls
title LDR - Background service manager
echo ================================================================
echo   LDR - Library Document Repository : background service
echo ================================================================
echo.
echo   1. Install / enable  (run in background, start automatically with Windows)
echo   2. Start
echo   3. Stop
echo   4. Restart  (use after changing ldr_config.ini or updating LDR)
echo   5. Status   (is it running? which address?)
echo   6. Remove background service
echo   7. Server mode: keep LDR working when the screen turns off / lid is closed
echo   0. Exit
echo.
choice /c 12345670 /n /m "Choose 1-7 or 0: "
if errorlevel 8 exit /b
if errorlevel 7 set ACTION=serverpower& goto run
if errorlevel 6 set ACTION=uninstall& goto run
if errorlevel 5 set ACTION=status& goto run
if errorlevel 4 set ACTION=restart& goto run
if errorlevel 3 set ACTION=stop& goto run
if errorlevel 2 set ACTION=start& goto run
if errorlevel 1 set ACTION=install& goto run

:run
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\windows_service.ps1" -Action %ACTION%
echo.
pause
