#!/usr/bin/env bash
# LDR - Library Document Repository : Linux installer (Ubuntu/Debian/Fedora)
# Usage:  bash install_linux.sh            (installs and registers a systemd service)
set -euo pipefail
cd "$(dirname "$(readlink -f "$0")")"
APP_DIR="$(pwd)"
echo "== LDR installer =="

if command -v apt-get >/dev/null; then
  echo "[1/5] Installing system packages (python3-venv, tesseract-ocr) ..."
  sudo apt-get update -qq
  sudo apt-get install -y -qq python3 python3-venv python3-pip tesseract-ocr >/dev/null
elif command -v dnf >/dev/null; then
  sudo dnf install -y -q python3 python3-pip tesseract >/dev/null
fi
python3 -c 'import sys; assert sys.version_info >= (3,10), "Python 3.10+ required"'

echo "[2/5] Creating Python environment ..."
[ -x .venv/bin/python ] || python3 -m venv .venv
echo "[3/5] Installing packages ..."
.venv/bin/pip install -q --upgrade pip
.venv/bin/pip install -q -r requirements.txt
echo "[4/5] Preparing database ..."
.venv/bin/python manage.py migrate --noinput
.venv/bin/python manage.py collectstatic --noinput >/dev/null
PORT=$(.venv/bin/python -c "import configparser;c=configparser.ConfigParser();c.read('ldr_config.ini');print(c.get('server','port',fallback='8080'))")
PORT=${PORT:-8080}

echo "[5/5] Registering system service (starts automatically at boot) ..."
sudo tee /etc/systemd/system/ldr.service >/dev/null <<UNIT
[Unit]
Description=LDR - Library Document Repository
After=network.target

[Service]
User=$(id -un)
WorkingDirectory=$APP_DIR
ExecStart=$APP_DIR/.venv/bin/python $APP_DIR/run_server.py
Restart=on-failure

[Install]
WantedBy=multi-user.target
UNIT
sudo systemctl daemon-reload
sudo systemctl enable --now ldr.service
if command -v ufw >/dev/null && sudo ufw status | grep -q active; then sudo ufw allow "$PORT"/tcp; fi

IP=$(hostname -I 2>/dev/null | awk '{print $1}')
echo
echo "LDR is running:"
echo "  this computer : http://localhost:$PORT"
echo "  library LAN   : http://${IP:-<server-ip>}:$PORT"
echo "Manage: sudo systemctl {status|restart|stop} ldr"
