from django.contrib import admin
from django.urls import include, path

admin.site.site_header = "LDR - Technical administration"

urlpatterns = [
    path("django-admin/", admin.site.urls),
    path("", include("repository.urls")),
]

handler403 = "repository.errors.forbidden"
handler404 = "repository.errors.not_found"
