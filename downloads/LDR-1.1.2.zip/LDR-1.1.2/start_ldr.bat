@echo off
title LDR - Library Document Repository
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo LDR is not installed yet. Run install_windows.bat first.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" run_server.py --open
REM exit code 3 = LDR is already running in the background; the browser was opened.
if "%errorlevel%"=="3" exit /b 0
pause
