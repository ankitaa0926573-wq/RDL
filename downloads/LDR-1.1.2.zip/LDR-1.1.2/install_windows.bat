@echo off
setlocal EnableDelayedExpansion
title LDR - Library Document Repository - Installer
cd /d "%~dp0"
echo ================================================================
echo   LDR - Library Document Repository : Windows installer
echo ================================================================
echo.

REM ---- 1. Find Python 3.10+ ----
set PY=
where py >nul 2>nul && (py -3 -c "import sys; sys.exit(0 if sys.version_info>=(3,10) else 1)" >nul 2>nul && set PY=py -3)
if not defined PY (
  where python >nul 2>nul && (python -c "import sys; sys.exit(0 if sys.version_info>=(3,10) else 1)" >nul 2>nul && set PY=python)
)
if not defined PY (
  echo [ERROR] Python 3.10 or newer was not found.
  echo.
  echo   1. Download Python from https://www.python.org/downloads/windows/
  echo   2. During installation TICK "Add python.exe to PATH"
  echo   3. Run this installer again.
  echo.
  pause
  exit /b 1
)
echo [1/5] Using Python: & %PY% --version

REM ---- 2. Virtual environment ----
if not exist ".venv\Scripts\python.exe" (
  echo [2/5] Creating private Python environment ...
  %PY% -m venv .venv || goto :fail
) else (
  echo [2/5] Python environment already exists.
)

REM ---- 3. Packages ----
echo [3/5] Installing required packages (needs internet, a few minutes) ...
".venv\Scripts\python.exe" -m pip install --upgrade pip >nul
".venv\Scripts\python.exe" -m pip install -r requirements.txt || goto :fail

REM ---- 4. Database ----
echo [4/5] Preparing the database ...
".venv\Scripts\python.exe" manage.py migrate --noinput || goto :fail
".venv\Scripts\python.exe" manage.py collectstatic --noinput >nul || goto :fail

REM ---- 5. Shortcuts and firewall ----
echo [5/5] Creating desktop shortcut and opening firewall port ...
for /f %%p in ('".venv\Scripts\python.exe" -c "import configparser;c=configparser.ConfigParser();c.read('ldr_config.ini');print(c.get('server','port',fallback='8080'))"') do set PORT=%%p
if "%PORT%"=="" set PORT=8080
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Desktop')+'\LDR Server.lnk');$s.TargetPath='%~dp0start_ldr.bat';$s.WorkingDirectory='%~dp0';$s.Description='Start Library Document Repository';$s.Save()" >nul 2>nul
netsh advfirewall firewall show rule name="LDR Library Document Repository" >nul 2>nul || (
  netsh advfirewall firewall add rule name="LDR Library Document Repository" dir=in action=allow protocol=TCP localport=%PORT% >nul 2>nul && (
    echo       Firewall: port %PORT% opened for the library network.
  ) || (
    echo       Firewall: could not open port %PORT% - right-click install_windows.bat and choose
    echo       "Run as administrator" if other computers cannot connect.
  )
)

echo.
echo ================================================================
echo   Installation complete!
echo ================================================================
echo.
echo   Recommended: run LDR in the BACKGROUND like Koha / DSpace
echo   (no window to keep open, starts automatically with the computer).
echo.
choice /c YN /m "  Set up LDR as a background service now"
if errorlevel 2 goto manual
call "%~dp0ldr_service.bat" install
goto done

:manual
echo.
echo   OK. Start LDR any time with the "LDR Server" desktop icon
echo   (a window opens - keep it open while LDR is in use).
echo   Later you can run ldr_service.bat to switch to background mode.

:done
echo.
echo   Optional: install Tesseract OCR so scanned documents become searchable:
echo   https://github.com/UB-Mannheim/tesseract/wiki
echo.
pause
exit /b 0

:fail
echo.
echo [ERROR] Installation failed. Check the messages above (internet connection?).
pause
exit /b 1
