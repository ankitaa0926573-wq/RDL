<#
  LDR - Library Document Repository : Windows background service manager

  Runs LDR in the background (no window) as a Windows scheduled task under the
  SYSTEM account, the same way Koha/DSpace run as services:
    * starts automatically when the computer is switched on (no login needed)
    * restarts automatically if it ever stops unexpectedly
    * no time limit (runs for months)

  Usage (normally called from ldr_service.bat, as Administrator):
    windows_service.ps1 -Action install|start|stop|restart|status|uninstall
#>
param([ValidateSet('install', 'start', 'stop', 'restart', 'status', 'uninstall')][string]$Action = 'status')

$ErrorActionPreference = 'Stop'
$TaskName = 'LDR Library Document Repository'
$App = Split-Path -Parent $PSScriptRoot
$Py = Join-Path $App '.venv\Scripts\python.exe'
$Pyw = Join-Path $App '.venv\Scripts\pythonw.exe'
$Server = Join-Path $App 'run_server.py'

function Get-Port {
    try {
        $p = & $Py -c "import configparser;c=configparser.ConfigParser();c.read(r'$App\ldr_config.ini');print(c.get('server','port',fallback='8080'))"
        if ($p) { return [int]$p.Trim() }
    } catch {}
    return 8080
}

function Test-Port([int]$Port) {
    $c = New-Object Net.Sockets.TcpClient
    try { $c.Connect('127.0.0.1', $Port); return $true } catch { return $false } finally { $c.Close() }
}

function Stop-LdrProcesses {
    Get-CimInstance Win32_Process -Filter "Name='python.exe' OR Name='pythonw.exe'" |
        Where-Object { $_.CommandLine -and $_.CommandLine -like '*run_server.py*' } |
        ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
}

function Wait-Started([int]$Port) {
    Write-Host -NoNewline "  Starting LDR "
    for ($i = 0; $i -lt 90; $i++) {
        if (Test-Port $Port) { Write-Host " started."; return $true }
        Write-Host -NoNewline "."
        Start-Sleep -Seconds 1
    }
    Write-Host ""
    return $false
}

function Show-Addresses([int]$Port) {
    Write-Host ""
    Write-Host "  LDR is running in the background." -ForegroundColor Green
    Write-Host "    On this computer  : http://localhost:$Port"
    Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
        Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' } |
        ForEach-Object { Write-Host "    On the library LAN: http://$($_.IPAddress):$Port" }
}

function New-BrowserShortcut([int]$Port) {
    $desktop = [Environment]::GetFolderPath('CommonDesktopDirectory')
    $file = Join-Path $desktop 'LDR - Library Document Repository.url'
    Set-Content -Path $file -Encoding ASCII -Value "[InternetShortcut]`r`nURL=http://localhost:$Port/`r`n"
    Write-Host "  Desktop shortcut created: 'LDR - Library Document Repository' (opens LDR in the browser)."
}

if (-not (Test-Path $Pyw)) {
    Write-Host "LDR is not installed yet. Run install_windows.bat first." -ForegroundColor Red
    exit 1
}
$Port = Get-Port

switch ($Action) {
    'install' {
        Write-Host "Setting up LDR as a background service ..."
        Stop-LdrProcesses   # close any LDR console window that is running
        Start-Sleep -Seconds 1
        $act = New-ScheduledTaskAction -Execute $Pyw -Argument "`"$Server`" --background" -WorkingDirectory $App
        $trg = New-ScheduledTaskTrigger -AtStartup
        $pri = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
        $set = New-ScheduledTaskSettingsSet -ExecutionTimeLimit ([TimeSpan]::Zero) -RestartCount 999 `
            -RestartInterval (New-TimeSpan -Minutes 1) -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries `
            -StartWhenAvailable -MultipleInstances IgnoreNew
        $desc = "LDR - Library Document Repository web server (http://localhost:$Port)"
        Register-ScheduledTask -TaskName $TaskName -Action $act -Trigger $trg -Principal $pri -Settings $set `
            -Description $desc -Force | Out-Null
        if (-not (Get-NetFirewallRule -DisplayName 'LDR Library Document Repository' -ErrorAction SilentlyContinue)) {
            New-NetFirewallRule -DisplayName 'LDR Library Document Repository' -Direction Inbound -Action Allow `
                -Protocol TCP -LocalPort $Port | Out-Null
            Write-Host "  Firewall: port $Port opened for the library network."
        }
        Start-ScheduledTask -TaskName $TaskName
        if (Wait-Started $Port) {
            Show-Addresses $Port
            New-BrowserShortcut $Port
            Write-Host ""
            Write-Host "  You can close this window. LDR keeps running and will start" -ForegroundColor Green
            Write-Host "  automatically every time this computer is switched on." -ForegroundColor Green
        } else {
            Write-Host "  LDR did not start within 90 seconds. See data\logs\server_console.log" -ForegroundColor Red
        }
    }
    'start' {
        if (Test-Port $Port) { Write-Host "LDR is already running."; Show-Addresses $Port; break }
        Start-ScheduledTask -TaskName $TaskName
        if (Wait-Started $Port) { Show-Addresses $Port } else { Write-Host "  Not started - see data\logs\server_console.log" -ForegroundColor Red }
    }
    'stop' {
        Stop-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
        Stop-LdrProcesses
        Write-Host "LDR has been stopped. (It will start again at the next reboot, or choose Start.)"
    }
    'restart' {
        Stop-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
        Stop-LdrProcesses
        Start-Sleep -Seconds 2
        Start-ScheduledTask -TaskName $TaskName
        if (Wait-Started $Port) { Show-Addresses $Port } else { Write-Host "  Not started - see data\logs\server_console.log" -ForegroundColor Red }
    }
    'status' {
        $t = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
        if ($t) { Write-Host "Background service: installed (starts automatically with Windows)" }
        else { Write-Host "Background service: NOT installed" -ForegroundColor Yellow }
        if (Test-Port $Port) { Write-Host "Server: RUNNING" -ForegroundColor Green; Show-Addresses $Port }
        else { Write-Host "Server: STOPPED" -ForegroundColor Red }
    }
    'uninstall' {
        Stop-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
        Stop-LdrProcesses
        Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction SilentlyContinue
        $file = Join-Path ([Environment]::GetFolderPath('CommonDesktopDirectory')) 'LDR - Library Document Repository.url'
        Remove-Item $file -ErrorAction SilentlyContinue
        Write-Host "Background service removed. Your data is untouched; you can still use start_ldr.bat."
    }
}
