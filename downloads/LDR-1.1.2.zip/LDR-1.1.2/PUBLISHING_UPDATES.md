# Publishing LDR and its updates (developer guide)

This guide is for **you, the LDR developer**. Libraries never need it. They download LDR once from your website, and after that the administrator gets an **"Update available"** message inside LDR and installs each update with one click.

```
 Your PC (LDR-source folder)            Your website (e.g. GitHub Pages)           Every library's LDR
 ─────────────────────────────          ───────────────────────────────            ─────────────────────
 publish_release.bat ──builds──►  index.html  (about LDR, download page)
   signs with your private key     latest.json (newest version + notes)  ◄──checks daily──  Settings ▸ Software updates
                                   downloads/LDR-x.y.z.zip               ◄──"Update now"──  backup ▸ verify ▸ install ▸ restart
```

---

## 1. Keep your signing key safe (most important)

`ldr_signing_key.pem` is your **private signing key**. Every installed LDR accepts an update only if it is signed with this key, so nobody else can push a fake update to libraries.

* Store it **outside** the LDR folder, for example `C:\LDR-keys\ldr_signing_key.pem`.
* **Back it up** to a pen drive or a password manager. If you lose it, existing installations can't receive updates any more; each library would have to reinstall manually once.
* **Never** upload it to GitHub or your website, and never email it.

(Advanced: `python tools/release.py keygen` creates a new key pair. Only do this **before** your first public release, because existing installations trust only the old key.)

## 2. Create the website (one time, free, about 15 minutes)

GitHub Pages is free and works well:

1. Create an account at <https://github.com> (free).
2. Click **New repository**. Name it `ldr`, make it **Public**, and tick *Add a README*. Click **Create**.
3. In the repository, click **Add file → Upload files**, drag in **everything inside** the `website` folder (`index.html`, the `screenshots` folder and so on), then click **Commit changes**.
4. Go to **Settings → Pages**, set *Source: Deploy from a branch*, *Branch: main / (root)*, then click **Save**.
5. After 1–2 minutes your site is live at `https://YOURNAME.github.io/ldr/`.

Your update address is then: **`https://YOURNAME.github.io/ldr/latest.json`**

(A college or university web server works too. It only needs to serve plain files.)

## 3. Publish the first public version

In the `LDR-source` folder, double-click **`publish_release.bat`**:

* **Key file:** for example `C:\LDR-keys\ldr_signing_key.pem` (asked only the first time)
* **Website address:** `https://YOURNAME.github.io/ldr/latest.json` (asked only the first time)
* **New version:** for example `1.1.1`
* **What's new:** for example `First public release`

It creates `website\latest.json` and `website\downloads\LDR-1.1.1.zip`. Upload both to GitHub (**Add file → Upload files**; keep the `downloads` folder name), then click **Commit**.

Libraries download LDR from your website, and **every copy will now check your website for updates**.

> Only give libraries copies built by `publish_release.bat` **after** you set the website address. A copy built without the address can still be updated, but the administrator must first type the address in *Settings & backup → Update address*.

## 4. Every time you add new features

1. Make the changes in the `LDR-source` folder and test them, for example with `python run_server.py`.
2. Run **`publish_release.bat`**, enter a higher version number (1.1.1 → 1.2.0) and a short "What's new".
3. Upload the new `website\latest.json` and `website\downloads\LDR-1.2.0.zip` to your website.

Within a day, every library's administrator sees **"New version 1.2.0 of LDR is available"**. When they click **Update now**, LDR:

1. downloads the zip and checks its SHA-256 and **your digital signature**
2. makes a **full backup** (database and all documents)
3. restarts, installs the new program files, and installs any new Python packages
4. applies database changes automatically
5. checks that the new version really works; if it doesn't, it **rolls back** to the old version and the old database by itself
6. records the update in the audit trail

Documents, users and settings (`data` folder, `ldr_config.ini`) are never touched.

**Libraries without internet** can download the zip from your website on another computer and use *Settings & backup → Install an update from a file*. The same signature checks apply.

## 5. Version numbers

Use `MAJOR.MINOR.PATCH`:

* `1.1.1 → 1.1.2` for bug fixes
* `1.1.x → 1.2.0` for new features
* `1.x → 2.0.0` for big changes

LDR only updates to a **higher** number.

If a release needs an older version to be updated first, use `--min-from` with `tools/release.py`, for example `--min-from 1.2.0`.

## 6. Command-line equivalent

```bash
python tools/release.py build --version 1.2.0 --notes "Added X; fixed Y" \
    --url https://YOURNAME.github.io/ldr/latest.json \
    --key C:/LDR-keys/ldr_signing_key.pem --website website
```
