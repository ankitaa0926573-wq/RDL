from django.apps import AppConfig


class RepositoryConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "repository"
    verbose_name = "Library Document Repository"

    def ready(self):
        from django.contrib.auth.signals import user_logged_in, user_logged_out, user_login_failed

        from .models import Action
        from .services.audit import audit

        def on_login(sender, request, user, **kw):
            audit(Action.LOGIN, request, user=user)

        def on_logout(sender, request, user, **kw):
            if user:
                audit(Action.LOGOUT, request, user=user)

        def on_failed(sender, credentials, request=None, **kw):
            audit(Action.LOGIN_FAILED, request, details=f"username={credentials.get('username', '')}")

        user_logged_in.connect(on_login, dispatch_uid="ldr_login")
        user_logged_out.connect(on_logout, dispatch_uid="ldr_logout")
        user_login_failed.connect(on_failed, dispatch_uid="ldr_failed")
