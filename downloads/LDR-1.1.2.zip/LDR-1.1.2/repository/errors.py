from django.shortcuts import render


def forbidden(request, exception=None):
    return render(request, "repository/error.html", {
        "code": 403, "title": "Access not permitted",
        "message": "Your role does not allow this action, or the document is restricted. "
                   "For confidential documents, use 'Request access' on the document page.",
    }, status=403)


def not_found(request, exception=None):
    return render(request, "repository/error.html", {
        "code": 404, "title": "Not found", "message": "The page or document you requested does not exist.",
    }, status=404)
