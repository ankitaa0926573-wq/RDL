from django.shortcuts import redirect


class SetupRequiredMiddleware:
    """Send every request to the first-run setup wizard until an administrator exists."""

    _done = False

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if not SetupRequiredMiddleware._done:
            path = request.path
            if not (path.startswith("/setup") or path.startswith("/static")):
                from .models import SiteSettings, User

                try:
                    done = SiteSettings.load().setup_completed and User.objects.exists()
                except Exception:
                    done = False
                if not done:
                    return redirect("setup")
                SetupRequiredMiddleware._done = True
        return self.get_response(request)
