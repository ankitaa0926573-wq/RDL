"""
Where this installation looks for updates, and the key used to verify them.

* UPDATE_URL: address of latest.json on the LDR website. Set automatically by
  ``python tools/release.py build --url ...``. Administrators can override it in
  Settings & backup -> Software updates.
* PUBLIC_KEY_PEM: the developer's PUBLIC signing key. Only releases signed with the
  matching private key (kept by the developer, never distributed) are accepted.
"""

UPDATE_URL = "https://ankitaa0926573-wq.github.io/RDL/latest.json"

PUBLIC_KEY_PEM = """-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEA6PWU/UkTOfEu8ZHoi7Wver3H6odzpNfccTHEvSUBxuc=
-----END PUBLIC KEY-----
"""
