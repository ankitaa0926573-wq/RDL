"""
Render files for viewing inside LDR (no download needed).

PDF and common images are shown by the browser itself; this module converts the
formats browsers cannot show (Excel, Word, CSV, TIFF/BMP, e-mail) into safe HTML
context for the templates.
"""
import csv
import datetime as dt
import email
import email.policy
import io
import logging

log = logging.getLogger("ldr")

MAX_ROWS = 2000
MAX_COLS = 60


def col_letter(n):
    s = ""
    while n:
        n, r = divmod(n - 1, 26)
        s = chr(65 + r) + s
    return s


def _fmt(v):
    if v is None:
        return ""
    if isinstance(v, dt.datetime):
        return v.strftime("%d-%m-%Y %H:%M") if (v.hour or v.minute) else v.strftime("%d-%m-%Y")
    if isinstance(v, dt.date):
        return v.strftime("%d-%m-%Y")
    if isinstance(v, float):
        return str(int(v)) if v == int(v) else f"{v:.10g}"
    if isinstance(v, bool):
        return "TRUE" if v else "FALSE"
    return str(v)


def _raw(v):
    """Value as the user would type it in the editor."""
    if v is None:
        return ""
    if isinstance(v, dt.datetime):
        return v.strftime("%Y-%m-%d %H:%M") if (v.hour or v.minute) else v.strftime("%Y-%m-%d")
    if isinstance(v, dt.date):
        return v.strftime("%Y-%m-%d")
    if isinstance(v, float) and v == int(v):
        return str(int(v))
    return str(v)


def read_csv(data):
    for enc in ("utf-8-sig", "cp1252", "latin-1"):
        try:
            text = data.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    try:
        dialect = csv.Sniffer().sniff(text[:4096], delimiters=",;\t|")
    except csv.Error:
        dialect = csv.excel
    return list(csv.reader(io.StringIO(text), dialect)), dialect


def sheets(data, ext, for_edit=False):
    """Return list of {name, rows, ncols, truncated}."""
    out = []
    if ext == "csv":
        rows, _ = read_csv(data)
        out.append({"name": "Sheet1", "rows": rows})
    elif ext == "xls":
        import xlrd

        book = xlrd.open_workbook(file_contents=data)
        for sh in book.sheets():
            rows = []
            for r in range(min(sh.nrows, MAX_ROWS)):
                row = []
                for c in range(min(sh.ncols, MAX_COLS)):
                    cell = sh.cell(r, c)
                    v = cell.value
                    if cell.ctype == xlrd.XL_CELL_DATE:
                        try:
                            v = xlrd.xldate.xldate_as_datetime(v, book.datemode)
                        except Exception:
                            pass
                    row.append(_fmt(v))
                rows.append(row)
            out.append({"name": sh.name, "rows": rows, "truncated": sh.nrows > MAX_ROWS or sh.ncols > MAX_COLS})
        return _finish(out)
    else:
        import openpyxl

        wb_f = openpyxl.load_workbook(io.BytesIO(data), data_only=False, read_only=True)
        wb_v = None if for_edit else openpyxl.load_workbook(io.BytesIO(data), data_only=True, read_only=True)
        for ws in wb_f.worksheets:
            wsv = wb_v[ws.title] if wb_v else None
            rows = []
            vals_iter = wsv.iter_rows(values_only=True, max_col=MAX_COLS) if wsv is not None else None
            for frow in ws.iter_rows(values_only=True, max_col=MAX_COLS):
                vrow = next(vals_iter, None) if vals_iter is not None else None
                row = []
                for i, f in enumerate(frow):
                    if for_edit:
                        row.append(_raw(f))
                    else:
                        v = vrow[i] if vrow is not None and i < len(vrow) else None
                        if v is None and isinstance(f, str) and f.startswith("="):
                            v = f  # formula without a cached value (file saved by a program other than Excel)
                        row.append(_fmt(v))
                rows.append(row)
                if len(rows) >= MAX_ROWS:
                    break
            dims_trunc = (ws.max_row or 0) > MAX_ROWS or (ws.max_column or 0) > MAX_COLS
            out.append({"name": ws.title, "rows": rows, "truncated": dims_trunc})
    return _finish(out)


def _finish(out):
    for sh in out:
        rows = sh["rows"]
        # trim fully empty trailing rows / columns
        while rows and not any(str(c).strip() for c in rows[-1]):
            rows.pop()
        ncols = max((len(r) for r in rows), default=0)
        while ncols and not any(len(r) >= ncols and str(r[ncols - 1]).strip() for r in rows):
            ncols -= 1
        sh["rows"] = [list(r[:ncols]) + [""] * (ncols - len(r[:ncols])) for r in rows]
        sh["ncols"] = ncols
        sh["cols"] = [col_letter(i + 1) for i in range(ncols)]
        sh.setdefault("truncated", False)
    return out


def word_html(data):
    import mammoth

    import re

    result = mammoth.convert_to_html(io.BytesIO(data))
    # neutralise any script links embedded in the document
    return re.sub(r'href="\s*(javascript|data|vbscript):[^"]*"', 'href="#"', result.value, flags=re.I)


def text(data):
    for enc in ("utf-8-sig", "cp1252", "latin-1"):
        try:
            return data.decode(enc)
        except UnicodeDecodeError:
            continue
    return data.decode("utf-8", errors="replace")


def email_message(data):
    msg = email.message_from_bytes(data, policy=email.policy.default)
    body = msg.get_body(preferencelist=("plain", "html"))
    content = ""
    if body is not None:
        content = body.get_content()
        if body.get_content_type() == "text/html":
            import re

            content = re.sub(r"<[^>]+>", " ", content)
    attachments = [p.get_filename() for p in msg.iter_attachments() if p.get_filename()]
    return {
        "headers": [(h, str(msg.get(h, ""))) for h in ("From", "To", "Cc", "Date", "Subject") if msg.get(h)],
        "body": content.strip(),
        "attachments": attachments,
    }


def image_page_count(data):
    from PIL import Image

    im = Image.open(io.BytesIO(data))
    return getattr(im, "n_frames", 1)


def image_as_png(data, page=0, max_side=2400):
    from PIL import Image

    im = Image.open(io.BytesIO(data))
    try:
        im.seek(page)
    except EOFError:
        im.seek(0)
    im = im.convert("RGB") if im.mode not in ("RGB", "L") else im
    im.thumbnail((max_side, max_side))
    buf = io.BytesIO()
    im.save(buf, "PNG", optimize=True)
    return buf.getvalue()
