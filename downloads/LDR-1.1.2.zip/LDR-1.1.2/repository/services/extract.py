"""
Phase 2 - Digitization helpers.

* Extracts text from PDF, Word, Excel, CSV and text files so documents are
  full-text searchable.
* If Tesseract OCR is installed, scanned images and image-only PDFs are OCR'd
  and a *searchable PDF access copy* is produced next to the untouched
  preservation master (OAIS: AIP master + DIP access copy).

Every optional dependency is imported lazily; the system keeps working (without
OCR) on machines where Tesseract is not installed.
"""
import io
import logging
import shutil

from django.conf import settings

log = logging.getLogger("ldr")

IMAGE_EXT = {"jpg", "jpeg", "png", "tif", "tiff", "bmp", "gif", "webp"}
MAX_TEXT = 500_000


def _tesseract():
    if not settings.OCR_ENABLED:
        return None
    try:
        import pytesseract
    except ImportError:
        return None
    if settings.TESSERACT_CMD:
        pytesseract.pytesseract.tesseract_cmd = settings.TESSERACT_CMD
    else:
        found = shutil.which("tesseract")
        if not found:
            for candidate in (
                r"C:\Program Files\Tesseract-OCR\tesseract.exe",
                r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
            ):
                import os

                if os.path.exists(candidate):
                    found = candidate
                    break
        if not found:
            return None
        pytesseract.pytesseract.tesseract_cmd = found
    try:
        pytesseract.get_tesseract_version()
    except Exception:
        return None
    return pytesseract


def ocr_available():
    return _tesseract() is not None


def _pdf_text(data):
    from pypdf import PdfReader

    reader = PdfReader(io.BytesIO(data))
    parts = []
    for page in reader.pages:
        try:
            parts.append(page.extract_text() or "")
        except Exception:
            parts.append("")
    return "\n".join(parts), len(reader.pages)


def _docx_text(data):
    import docx

    d = docx.Document(io.BytesIO(data))
    parts = [p.text for p in d.paragraphs]
    for table in d.tables:
        for row in table.rows:
            parts.append(" | ".join(c.text for c in row.cells))
    return "\n".join(parts)


def _xlsx_text(data):
    import openpyxl

    wb = openpyxl.load_workbook(io.BytesIO(data), read_only=True, data_only=True)
    parts = []
    for ws in wb.worksheets:
        parts.append(f"[{ws.title}]")
        for row in ws.iter_rows(values_only=True):
            vals = [str(v) for v in row if v is not None]
            if vals:
                parts.append(" | ".join(vals))
            if len(parts) > 20000:
                break
    return "\n".join(parts)


def _ocr_images(images, tess):
    """OCR a list of PIL images. Returns (text, searchable_pdf_bytes)."""
    from pypdf import PdfReader, PdfWriter

    texts = []
    writer = PdfWriter()
    lang = settings.OCR_LANGUAGES or "eng"
    for img in images:
        if img.mode not in ("RGB", "L"):
            img = img.convert("RGB")
        texts.append(tess.image_to_string(img, lang=lang))
        pdf_bytes = tess.image_to_pdf_or_hocr(img, extension="pdf", lang=lang)
        for p in PdfReader(io.BytesIO(pdf_bytes)).pages:
            writer.add_page(p)
    out = io.BytesIO()
    writer.write(out)
    return "\n".join(texts), out.getvalue()


def process_file(data, filename):
    """
    Returns dict(text=str, pages=int|None, ocr=bool, searchable_pdf=bytes|None, note=str)
    """
    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    result = {"text": "", "pages": None, "ocr": False, "searchable_pdf": None, "note": ""}
    try:
        if ext == "pdf":
            text, pages = _pdf_text(data)
            result["pages"] = pages
            result["text"] = text
            if len(text.strip()) < 5 * max(pages, 1):
                tess = _tesseract()
                if tess:
                    import pypdfium2 as pdfium

                    pdf = pdfium.PdfDocument(data)
                    images = [pdf[i].render(scale=300 / 72).to_pil() for i in range(min(len(pdf), 200))]
                    ocr_text, spdf = _ocr_images(images, tess)
                    result.update(text=ocr_text, ocr=True, searchable_pdf=spdf, note="Scanned PDF - OCR applied")
                else:
                    result["note"] = "Scanned PDF - install Tesseract OCR to make it searchable"
        elif ext in IMAGE_EXT:
            from PIL import Image, ImageSequence

            tess = _tesseract()
            if tess:
                im = Image.open(io.BytesIO(data))
                frames = [f.copy() for f in ImageSequence.Iterator(im)][:200]
                ocr_text, spdf = _ocr_images(frames, tess)
                result.update(
                    text=ocr_text, ocr=True, searchable_pdf=spdf, pages=len(frames),
                    note="Image - OCR applied, searchable PDF created",
                )
            else:
                result["note"] = "Image stored - install Tesseract OCR to make it searchable"
        elif ext == "docx":
            result["text"] = _docx_text(data)
        elif ext in ("xlsx", "xlsm"):
            result["text"] = _xlsx_text(data)
        elif ext in ("txt", "csv", "md", "xml", "json", "html", "htm"):
            result["text"] = data.decode("utf-8", errors="replace")
    except Exception as exc:  # never block an upload because extraction failed
        log.exception("Text extraction failed for %s", filename)
        result["note"] = f"Text extraction failed: {exc.__class__.__name__}"
    result["text"] = (result["text"] or "")[:MAX_TEXT]
    return result
