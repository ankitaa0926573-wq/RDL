"""Helpers for writing to and verifying the tamper-evident audit trail."""
import logging

from django.conf import settings

from ..models import AuditLog, Notification, Role, User

log = logging.getLogger("ldr")


def client_ip(request):
    if request is None:
        return None
    fwd = request.META.get("HTTP_X_FORWARDED_FOR")
    ip = fwd.split(",")[0].strip() if fwd else request.META.get("REMOTE_ADDR")
    return ip or None


def audit(action, request=None, user=None, document=None, details=""):
    if user is None and request is not None and getattr(request, "user", None) and request.user.is_authenticated:
        user = request.user
    entry = AuditLog(
        user=user,
        username=(user.username if user else "system"),
        action=action,
        document=document,
        doc_ref=(document.doc_id if document else ""),
        details=str(details)[:4000],
        ip_address=client_ip(request),
    )
    entry.save()
    log.info("AUDIT %s %s %s %s", entry.username, action, entry.doc_ref, entry.details[:200])
    return entry


def verify_chain():
    """Recompute every hash. Returns (ok, checked_count, first_bad_entry_or_None)."""
    prev = "0" * 64
    count = 0
    for entry in AuditLog.objects.order_by("id").iterator():
        count += 1
        if entry.prev_hash != prev or entry.compute_hash() != entry.entry_hash:
            return False, count, entry
        prev = entry.entry_hash
    return True, count, None


def notify(users, message, link="", level="info", dedupe_key=""):
    """Create in-app notifications (and e-mail if configured)."""
    created = 0
    for u in users:
        if dedupe_key and Notification.objects.filter(user=u, dedupe_key=dedupe_key).exists():
            continue
        Notification.objects.create(user=u, message=message[:400], link=link, level=level, dedupe_key=dedupe_key)
        created += 1
        if u.email and settings.EMAIL_BACKEND.endswith("smtp.EmailBackend"):
            try:
                from django.core.mail import send_mail

                send_mail("[LDR] " + message[:80], message, None, [u.email], fail_silently=True)
            except Exception:  # pragma: no cover - mail is optional
                log.exception("e-mail notification failed")
    return created


def approvers():
    return User.objects.filter(is_active=True, role__in=[Role.SUPER_LIBRARIAN, Role.ADMIN])
