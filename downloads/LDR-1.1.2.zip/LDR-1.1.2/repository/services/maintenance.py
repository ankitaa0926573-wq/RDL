"""
Scheduled jobs: retention monitoring (Phase 6), fixity checking and backups.
Run automatically once a day by the bundled server, or manually with
``python manage.py ldr_daily`` / ``python manage.py ldr_backup``.
"""
import json
import logging
import os
import shutil
import sqlite3
import zipfile
from datetime import timedelta

from django.conf import settings
from django.db import connection
from django.utils import timezone

from ..models import Action, Document, DocumentFile, SiteSettings, Status
from .audit import approvers, audit, notify

log = logging.getLogger("ldr")


def retention_check():
    """Flag expired records for review and alert about records nearing expiry."""
    s = SiteSettings.load()
    today = timezone.localdate()
    soon = today + timedelta(days=s.alert_days_before_expiry)
    expired = Document.objects.filter(status=Status.ACTIVE, permanent=False, expiry_date__lte=today)
    n_expired = 0
    for doc in expired:
        doc.status = Status.UNDER_REVIEW
        doc.save(update_fields=["status", "updated_at"])
        audit(Action.RETENTION_ALERT, document=doc, details=f"Retention period ended on {doc.expiry_date}; review required")
        notify(approvers() | type(doc.custodian).objects.filter(pk=doc.custodian_id),
               f"{doc.doc_id} retention period ended ({doc.expiry_date}). Review required.",
               link=doc.get_absolute_url(), level="danger", dedupe_key=f"expired-{doc.pk}-{doc.expiry_date}")
        n_expired += 1
    upcoming = Document.objects.filter(status=Status.ACTIVE, permanent=False, expiry_date__gt=today, expiry_date__lte=soon)
    n_soon = 0
    for doc in upcoming:
        n_soon += notify(
            type(doc.custodian).objects.filter(pk=doc.custodian_id) | approvers(),
            f"{doc.doc_id} '{doc.title}' expires on {doc.expiry_date:%d %b %Y}.",
            link=doc.get_absolute_url(), level="warning", dedupe_key=f"soon-{doc.pk}-{doc.expiry_date}",
        )
    return {"expired_flagged": n_expired, "upcoming_alerts": n_soon}


def fixity_check():
    ok = bad = 0
    failed = []
    for f in DocumentFile.objects.filter(purged=False).select_related("document"):
        if f.verify_fixity():
            ok += 1
        else:
            bad += 1
            failed.append(f)
            audit(Action.FIXITY_FAILED, document=f.document, details=f"{f.original_name} checksum mismatch or file missing")
    if failed:
        notify(approvers(), f"Integrity check: {bad} file(s) failed. Restore them from backup.",
               link="/reports/", level="danger", dedupe_key=f"fixity-{timezone.localdate()}")
    audit(Action.FIXITY_OK if not bad else Action.FIXITY_FAILED, details=f"Fixity check: {ok} ok, {bad} failed")
    return {"ok": ok, "failed": bad}


def make_backup(user=None, request=None):
    """Zip the database + all repository files into data/backups."""
    s = SiteSettings.load()
    stamp = timezone.localtime().strftime("%Y%m%d_%H%M%S")
    target = settings.BACKUP_DIR / f"ldr_backup_{stamp}.zip"
    tmp_db = settings.BACKUP_DIR / f"_db_{stamp}.sqlite3"
    db = settings.DATABASES["default"]
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED, allowZip64=True) as zf:
        if db["ENGINE"].endswith("sqlite3"):
            connection.ensure_connection()
            src = sqlite3.connect(str(db["NAME"]))
            dst = sqlite3.connect(str(tmp_db))
            with dst:
                src.backup(dst)
            src.close()
            dst.close()
            zf.write(tmp_db, "database/ldr.sqlite3")
            os.remove(tmp_db)
        else:
            from django.core import management
            import io

            buf = io.StringIO()
            management.call_command("dumpdata", "--natural-foreign", "--indent", "1", stdout=buf)
            zf.writestr("database/ldr_dump.json", buf.getvalue())
        for root, _dirs, files in os.walk(settings.MEDIA_ROOT):
            for name in files:
                full = os.path.join(root, name)
                zf.write(full, os.path.join("repository_files", os.path.relpath(full, settings.MEDIA_ROOT)))
        cfg = settings.CONFIG_FILE
        if cfg.exists():
            zf.write(cfg, "ldr_config.ini")
        zf.writestr("BACKUP_INFO.json", json.dumps({
            "created": timezone.now().isoformat(),
            "version": settings.LDR_VERSION,
            "documents": Document.objects.count(),
            "files": DocumentFile.objects.filter(purged=False).count(),
        }, indent=1))
    s.last_backup = timezone.now()
    s.save()
    # rotate
    backups = sorted(settings.BACKUP_DIR.glob("ldr_backup_*.zip"))
    for old in backups[: max(0, len(backups) - s.backups_to_keep)]:
        old.unlink(missing_ok=True)
    size_mb = target.stat().st_size / 1024 / 1024
    audit(Action.BACKUP, request=request, user=user, details=f"{target.name} ({size_mb:.1f} MB)")
    return target


def daily_jobs(force=False):
    s = SiteSettings.load()
    now = timezone.now()
    results = {}
    if force or not s.last_daily_run or s.last_daily_run.date() < timezone.localdate():
        results["retention"] = retention_check()
        results["fixity"] = fixity_check()
        if s.update_check_enabled:
            try:
                from .updates import check_for_update, update_url

                if update_url():
                    results["update"] = check_for_update().get("version")
            except Exception as exc:  # no internet etc. - never block the daily jobs
                results["update"] = f"check failed: {exc}"
        s.last_daily_run = now
        s.save()
    local = timezone.localtime(now)
    if force or ((not s.last_backup or timezone.localtime(s.last_backup).date() < local.date()) and local.hour >= s.backup_hour):
        results["backup"] = str(make_backup())
    return results


def disk_usage():
    total = 0
    for root, _d, files in os.walk(settings.MEDIA_ROOT):
        for f in files:
            try:
                total += os.path.getsize(os.path.join(root, f))
            except OSError:
                pass
    du = shutil.disk_usage(settings.DATA_DIR)
    return {"repository_bytes": total, "disk_free": du.free, "disk_total": du.total}
