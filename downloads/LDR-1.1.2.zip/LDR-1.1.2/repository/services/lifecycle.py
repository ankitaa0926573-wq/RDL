"""
Business rules for the seven-phase LDR workflow.

Views call these functions; keeping the rules here means they are applied the
same way from the web interface, the management commands and the tests.
"""
import hashlib
import json
import logging
import mimetypes
import os
from datetime import timedelta

from django.core.exceptions import PermissionDenied, ValidationError
from django.core.files.base import ContentFile
from django.db import transaction
from django.db.models import Q
from django.utils import timezone

from ..models import (
    AccessRequest,
    Action,
    Confidentiality,
    DisposalRecord,
    Document,
    DocumentFile,
    FileRole,
    Notification,
    RetentionReview,
    Role,
    SiteSettings,
    Status,
)
from .audit import approvers, audit, notify
from .extract import process_file

log = logging.getLogger("ldr")

ALLOWED_EXT = {
    "pdf", "doc", "docx", "odt", "rtf", "txt", "xls", "xlsx", "xlsm", "ods", "csv", "ppt", "pptx", "odp",
    "jpg", "jpeg", "png", "tif", "tiff", "bmp", "gif", "webp", "zip", "xml", "json", "msg", "eml", "html", "htm",
}


# --------------------------------------------------------------------------
# Visibility / access control (Phase 5)
# --------------------------------------------------------------------------
def visible_documents(user, qs=None):
    """Documents a user may see in lists/search (metadata level)."""
    qs = Document.objects.all() if qs is None else qs
    if user.is_super_librarian:
        return qs
    cond = Q(confidentiality=Confidentiality.GENERAL) | Q(created_by=user) | Q(custodian=user)
    if user.department_id:
        cond |= Q(confidentiality=Confidentiality.DEPARTMENT, department_id=user.department_id)
    # confidential documents appear in results (title only) so staff can request access
    cond |= Q(confidentiality=Confidentiality.CONFIDENTIAL)
    qs = qs.filter(cond)
    # Work-in-progress documents are only visible to staff who work on them
    if user.role == Role.AUTHORIZED:
        qs = qs.filter(status__in=[Status.ACTIVE, Status.UNDER_REVIEW, Status.DISPOSAL_REQUESTED, Status.DISPOSED])
    return qs


def can_open(user, doc):
    """Can the user open the files / full metadata of this document?"""
    if user.is_super_librarian or doc.created_by_id == user.pk or doc.custodian_id == user.pk:
        return True
    if user.role == Role.AUTHORIZED and not doc.is_official:
        return False
    if doc.confidentiality == Confidentiality.GENERAL:
        return True
    if doc.confidentiality == Confidentiality.DEPARTMENT:
        if user.department_id and user.department_id == doc.department_id:
            return True
    return has_valid_grant(user, doc)


def has_valid_grant(user, doc):
    return AccessRequest.objects.filter(
        document=doc, requested_by=user, state=AccessRequest.State.APPROVED, valid_until__gte=timezone.now()
    ).exists()


def request_access(doc, user, purpose, request=None):
    if AccessRequest.objects.filter(document=doc, requested_by=user, state=AccessRequest.State.PENDING).exists():
        raise ValidationError("You already have a pending request for this document.")
    ar = AccessRequest.objects.create(document=doc, requested_by=user, purpose=purpose)
    audit(Action.ACCESS_REQUESTED, request, user=user, document=doc, details=purpose)
    notify(
        approvers(),
        f"{user.display_name()} requested access to {doc.doc_id}: {doc.title}",
        link="/access-requests/",
        level="warning",
    )
    return ar


def decide_access(ar, user, approve, remarks="", request=None):
    if not user.can_approve:
        raise PermissionDenied
    days = SiteSettings.load().access_grant_days
    ar.state = AccessRequest.State.APPROVED if approve else AccessRequest.State.REJECTED
    ar.decided_by = user
    ar.decided_at = timezone.now()
    ar.remarks = remarks
    ar.valid_until = timezone.now() + timedelta(days=days) if approve else None
    ar.save()
    audit(
        Action.ACCESS_GRANTED if approve else Action.ACCESS_REJECTED,
        request,
        document=ar.document,
        details=f"For {ar.requested_by.username}; {remarks}" + (f"; valid {days} days" if approve else ""),
    )
    notify(
        [ar.requested_by],
        f"Your access request for {ar.document.doc_id} was {'approved' if approve else 'rejected'}.",
        link=ar.document.get_absolute_url(),
        level="success" if approve else "danger",
    )


# --------------------------------------------------------------------------
# Phase 1 - Receipt
# --------------------------------------------------------------------------
def register_document(doc, user, request=None):
    if not user.can_register:
        raise PermissionDenied
    doc.created_by = user
    if not doc.custodian_id:
        doc.custodian = user
    doc.status = Status.RECEIVED
    if not doc.confidentiality:
        doc.confidentiality = doc.category.default_confidentiality
    doc.compute_expiry()
    doc.save()
    audit(Action.REGISTERED, request, user=user, document=doc,
          details=f"{doc.title} | category={doc.category.code} | from={doc.received_from} | custodian={doc.custodian.username}")
    return doc


# --------------------------------------------------------------------------
# Phase 2 - Digitization
# --------------------------------------------------------------------------
def _validate_upload(name, data):
    from django.conf import settings

    ext = name.rsplit(".", 1)[-1].lower() if "." in name else ""
    if ext not in ALLOWED_EXT:
        raise ValidationError(f"File type .{ext} is not allowed.")
    if len(data) > settings.MAX_UPLOAD_MB * 1024 * 1024:
        raise ValidationError(f"File is larger than {settings.MAX_UPLOAD_MB} MB.")


def _store_file(doc, data, name, user, request=None, previous=None, pending=False, note=""):
    """Save a master file (+ OCR access copy). Returns (master, info)."""
    sha = hashlib.sha256(data).hexdigest()
    info = process_file(data, name)
    is_current = not pending
    master = DocumentFile(
        document=doc,
        role=FileRole.MASTER,
        original_name=name,
        mime_type=mimetypes.guess_type(name)[0] or "application/octet-stream",
        size=len(data),
        sha256=sha,
        pages=info["pages"],
        extracted_text=info["text"],
        ocr_applied=info["ocr"],
        uploaded_by=user,
        version=(previous.version + 1) if previous else 1,
        previous=previous,
        is_current=is_current,
        pending_approval=pending,
        change_note=note,
    )
    master.file.save(name, ContentFile(data), save=False)
    master.save()
    if previous is None:
        audit(Action.FILE_UPLOADED, request, user=user, document=doc,
              details=f"{name} ({len(data)} bytes) sha256={sha} {info['note']}")
    if info["searchable_pdf"]:
        spdf = info["searchable_pdf"]
        access_name = name.rsplit(".", 1)[0] + "_searchable.pdf"
        acc = DocumentFile(
            document=doc,
            role=FileRole.ACCESS,
            derived_from=master,
            original_name=access_name,
            mime_type="application/pdf",
            size=len(spdf),
            sha256=hashlib.sha256(spdf).hexdigest(),
            pages=info["pages"],
            ocr_applied=True,
            uploaded_by=user,
            version=master.version,
            is_current=is_current,
            pending_approval=pending,
        )
        acc.file.save(access_name, ContentFile(spdf), save=False)
        acc.save()
        audit(Action.OCR, request, user=user, document=doc, details=f"Searchable PDF created from {name}")
    return master, info


def add_file(doc, uploaded, user, request=None):
    if not user.can_digitize and not (doc.created_by_id == user.pk and doc.is_editable):
        raise PermissionDenied
    if not doc.is_editable:
        raise ValidationError("Files can only be added before the document is approved. "
                              "To change an approved file, open it and save a new version.")
    name = os.path.basename(uploaded.name)
    data = uploaded.read()
    uploaded.seek(0)
    _validate_upload(name, data)
    sha = hashlib.sha256(data).hexdigest()
    if doc.files.filter(sha256=sha, purged=False, is_current=True).exists():
        raise ValidationError(f"{name} is already attached to this document (identical checksum).")
    with transaction.atomic():
        master, info = _store_file(doc, data, name, user, request)
        refresh_text(doc)
    return master, info


def remove_file(df, user, request=None):
    doc = df.document
    if not doc.is_editable or not (user.can_digitize or doc.created_by_id == user.pk):
        raise PermissionDenied
    name, sha = df.original_name, df.sha256
    previous = df.previous
    with transaction.atomic():
        for f in [df, *DocumentFile.objects.filter(derived_from=df)]:
            if f.file:
                f.file.delete(save=False)
            f.delete()
        if previous is not None:  # removing a version brings the previous one back
            _set_current(previous, True)
        refresh_text(doc)
    audit(Action.FILE_REMOVED, request, user=user, document=doc,
          details=f"{name} sha256={sha} (before approval)" + (f"; version {previous.version} restored" if previous else ""))


def refresh_text(doc):
    texts = [f.extracted_text for f in doc.files.filter(purged=False, is_current=True) if f.extracted_text]
    doc.extracted_text = "\n\n".join(texts)[:1_000_000]
    doc.save(update_fields=["extracted_text", "updated_at"])


# --------------------------------------------------------------------------
# Versioned editing
# --------------------------------------------------------------------------
def can_edit_file(user, df):
    doc = df.document
    if df.purged or doc.is_disposed or df.role != FileRole.MASTER or not df.is_current:
        return False
    if doc.status in (Status.PENDING_APPROVAL, Status.DISPOSAL_REQUESTED):
        return False
    return user.can_catalogue or user.can_digitize or doc.custodian_id == user.pk or (
        doc.is_editable and doc.created_by_id == user.pk)


def _set_current(master, current):
    master.is_current = current
    master.save(update_fields=["is_current"])
    DocumentFile.objects.filter(derived_from=master).update(is_current=current)


def add_version(old, data, filename, note, user, request=None):
    """
    Save edited content as a new version of ``old``.
    * Document still in workflow (phases 1-4): the new version becomes current immediately.
    * Approved record: the new version waits for Super Librarian approval; the approved
      version stays the official one until then.
    """
    doc = old.document
    if not can_edit_file(user, old):
        if doc.status == Status.PENDING_APPROVAL:
            raise ValidationError("This document is awaiting approval. Ask the Super Librarian to return it first.")
        raise PermissionDenied
    if not (note or "").strip():
        raise ValidationError("Please describe what you changed (change note).")
    if old.next_versions.filter(pending_approval=True).exists():
        raise ValidationError("A new version of this file is already awaiting approval.")
    filename = os.path.basename(filename or old.original_name)
    _validate_upload(filename, data)
    if hashlib.sha256(data).hexdigest() == old.sha256:
        raise ValidationError("No changes were made - the new file is identical to the current version.")
    pending = doc.is_official
    with transaction.atomic():
        new, _info = _store_file(doc, data, filename, user, request, previous=old, pending=pending, note=note.strip())
        if not pending:
            _set_current(old, False)
            refresh_text(doc)
        audit(Action.VERSION_SUBMITTED if pending else Action.VERSION_CREATED, request, user=user, document=doc,
              details=f"{filename} v{new.version} (replaces v{old.version}); sha256={new.sha256}; note: {note}")
    if pending:
        notify(approvers(), f"New version v{new.version} of '{filename}' in {doc.doc_id} awaits your approval.",
               link=doc.get_absolute_url(), level="warning")
    return new


def decide_version(new, user, approve, remarks="", request=None):
    if not user.can_approve:
        raise PermissionDenied
    if not new.pending_approval:
        raise ValidationError("This version is not awaiting approval.")
    doc = new.document
    if approve and not new.verify_fixity():
        raise ValidationError("Integrity check failed for the new version.")
    with transaction.atomic():
        new.pending_approval = False
        new.version_decided_by = user
        new.version_decided_at = timezone.now()
        if approve:
            new.save()
            DocumentFile.objects.filter(derived_from=new).update(pending_approval=False)
            if new.previous_id:
                _set_current(new.previous, False)
            _set_current(new, True)
            refresh_text(doc)
            audit(Action.VERSION_APPROVED, request, user=user, document=doc,
                  details=f"{new.original_name} v{new.version} is now the official version; {remarks}")
        else:
            name, ver, sha = new.original_name, new.version, new.sha256
            for f in [new, *DocumentFile.objects.filter(derived_from=new)]:
                if f.file:
                    f.file.delete(save=False)
                f.delete()
            audit(Action.VERSION_REJECTED, request, user=user, document=doc,
                  details=f"{name} v{ver} rejected and removed (sha256={sha}); {remarks}")
    target = [new.uploaded_by] if approve else []
    if target:
        notify(target, f"Your new version of '{new.original_name}' ({doc.doc_id}) was approved.",
               link=doc.get_absolute_url(), level="success")


def mark_digitized(doc, user, request=None):
    if not user.can_digitize:
        raise PermissionDenied
    if not doc.files.filter(role=FileRole.MASTER, is_current=True).exists():
        raise ValidationError("Upload at least one file before completing digitization.")
    doc.digitized_by = user
    doc.digitized_at = timezone.now()
    if doc.status == Status.RECEIVED:
        doc.status = Status.DIGITIZED
    doc.save()
    audit(Action.DIGITIZED, request, user=user, document=doc, details=f"{doc.files.filter(is_current=True, role=FileRole.MASTER).count()} file(s)")


# --------------------------------------------------------------------------
# Phase 3 - Metadata
# --------------------------------------------------------------------------
REQUIRED_METADATA = ["title", "category", "description", "document_year", "custodian"]


def metadata_missing(doc):
    missing = [f for f in REQUIRED_METADATA if not getattr(doc, f if f not in ("category", "custodian") else f + "_id")]
    if not doc.permanent and not doc.expiry_date:
        missing.append("expiry_date")
    return missing


def save_metadata(doc, user, changed_fields, request=None):
    if not user.can_catalogue:
        raise PermissionDenied
    if not doc.is_editable:
        raise ValidationError("Metadata is locked after approval. Use retention review to change expiry.")
    if doc.permanent:
        doc.expiry_date = None
    elif not doc.expiry_date:
        doc.compute_expiry()
    elif "expiry_date" not in changed_fields and {"retention_years", "category", "document_date"} & set(changed_fields):
        doc.compute_expiry()
    doc.catalogued_by = user
    doc.catalogued_at = timezone.now()
    if doc.status in (Status.RECEIVED, Status.DIGITIZED) and doc.files.exists() and not metadata_missing(doc):
        doc.status = Status.METADATA_DONE
    doc.save()
    audit(Action.METADATA, request, user=user, document=doc, details="Changed: " + ", ".join(changed_fields) if changed_fields else "Saved")


# --------------------------------------------------------------------------
# Phase 4 - Validation & approval
# --------------------------------------------------------------------------
def submit_for_approval(doc, user, request=None):
    if not (user.can_catalogue or user.can_digitize):
        raise PermissionDenied
    if not doc.is_editable:
        raise ValidationError("Document is not in an editable state.")
    if not doc.files.filter(role=FileRole.MASTER, is_current=True).exists():
        raise ValidationError("Phase 2 incomplete: attach the digitized file(s) first.")
    missing = metadata_missing(doc)
    if missing:
        raise ValidationError("Phase 3 incomplete. Missing metadata: " + ", ".join(m.replace("_", " ") for m in missing))
    doc.status = Status.PENDING_APPROVAL
    doc.submitted_at = timezone.now()
    doc.save()
    audit(Action.SUBMITTED, request, user=user, document=doc)
    notify(approvers(), f"{doc.doc_id} '{doc.title}' is awaiting your approval.", link=doc.get_absolute_url(), level="warning")


RETENTION_YEAR_CHOICES = [1, 2, 3, 5, 7, 8, 10, 15, 20, 25, 30]


def apply_retention_decision(doc, choice, until=None):
    """
    Retention decided by the approver (Phase 4):
      'default' -> keep the retention proposed in the metadata (category schedule if none)
      'permanent' -> keep forever
      '<n>'      -> keep n years (from the document / receipt date)
      'date'     -> keep until the given date
    Returns a short description for the audit trail.
    """
    choice = (choice or "default").strip()
    if choice == "default":
        if not doc.permanent and not doc.expiry_date:
            doc.compute_expiry()
        return "as proposed (" + (
            "permanent" if doc.permanent else f"until {doc.expiry_date:%d-%m-%Y}") + ")"
    if choice == "permanent":
        doc.permanent = True
        doc.retention_years = 0
        doc.expiry_date = None
        return "retain permanently"
    if choice == "date":
        if not until or until <= timezone.localdate():
            raise ValidationError("Choose a retention date in the future.")
        doc.permanent = False
        doc.expiry_date = until
        return f"retain until {until:%d-%m-%Y}"
    try:
        years = int(choice)
    except ValueError:
        raise ValidationError("Unknown retention choice.")
    if years <= 0 or years > 100:
        raise ValidationError("Retention years must be between 1 and 100.")
    doc.permanent = False
    doc.retention_years = years
    doc.compute_expiry()
    return f"retain {years} years (until {doc.expiry_date:%d-%m-%Y})"


def approve(doc, user, remarks="", request=None, retention=None, retention_until=None):
    if not user.can_approve:
        raise PermissionDenied
    if doc.status != Status.PENDING_APPROVAL:
        raise ValidationError("Only documents awaiting approval can be approved.")
    bad = [f.original_name for f in doc.files.filter(purged=False) if not f.verify_fixity()]
    if bad:
        raise ValidationError("Integrity check failed for: " + ", ".join(bad))
    retention_text = apply_retention_decision(doc, retention, retention_until)
    Notification.objects.filter(link=doc.get_absolute_url(), message__contains="awaiting your approval").update(read=True)
    doc.status = Status.ACTIVE
    doc.approved_by = user
    doc.approved_at = timezone.now()
    doc.approval_remarks = remarks
    doc.save()
    audit(Action.APPROVED, request, user=user, document=doc,
          details=f"Signed off by {user.display_name()}; files verified (SHA-256); retention: {retention_text}; {remarks}")
    notify([doc.created_by, doc.custodian], f"{doc.doc_id} has been approved and is now an official record.",
           link=doc.get_absolute_url(), level="success")


def return_for_correction(doc, user, remarks, request=None):
    if not user.can_approve:
        raise PermissionDenied
    if doc.status != Status.PENDING_APPROVAL:
        raise ValidationError("Only documents awaiting approval can be returned.")
    if not remarks.strip():
        raise ValidationError("Please give the reason for returning the document.")
    doc.status = Status.RETURNED
    doc.approval_remarks = remarks
    doc.save()
    audit(Action.RETURNED, request, user=user, document=doc, details=remarks)
    notify([doc.created_by, doc.custodian], f"{doc.doc_id} was returned for correction: {remarks}",
           link=doc.get_absolute_url(), level="danger")


# --------------------------------------------------------------------------
# Phase 6 - Retention monitoring
# --------------------------------------------------------------------------
def review_retention(doc, user, decision, remarks="", new_expiry=None, request=None):
    if not user.can_manage_retention:
        raise PermissionDenied
    if doc.status not in (Status.ACTIVE, Status.UNDER_REVIEW):
        raise ValidationError("Retention can only be reviewed for approved documents.")
    prev = doc.expiry_date
    if decision == RetentionReview.Decision.RETAIN:
        if not new_expiry or new_expiry <= timezone.localdate():
            raise ValidationError("Give a new expiry date in the future.")
        doc.expiry_date = new_expiry
        doc.permanent = False
        doc.status = Status.ACTIVE
    elif decision == RetentionReview.Decision.PERMANENT:
        doc.expiry_date = None
        doc.permanent = True
        doc.status = Status.ACTIVE
    elif decision == RetentionReview.Decision.DISPOSE:
        pass  # a disposal request is created separately
    else:
        raise ValidationError("Unknown decision")
    doc.last_reviewed_at = timezone.now()
    doc.save()
    rr = RetentionReview.objects.create(
        document=doc, reviewed_by=user, decision=decision, previous_expiry=prev, new_expiry=doc.expiry_date, remarks=remarks
    )
    audit(Action.RETENTION_REVIEW, request, user=user, document=doc,
          details=f"{rr.get_decision_display()}; expiry {prev} -> {doc.expiry_date}; {remarks}")
    return rr


# --------------------------------------------------------------------------
# Phase 7 - Secure disposal
# --------------------------------------------------------------------------
def request_disposal(doc, user, reason, method, authority_reference="", request=None):
    if not user.can_request_disposal:
        raise PermissionDenied
    if doc.status not in (Status.ACTIVE, Status.UNDER_REVIEW):
        raise ValidationError("Only approved records can be put forward for disposal.")
    if doc.disposals.filter(state=DisposalRecord.State.REQUESTED).exists():
        raise ValidationError("A disposal request is already pending.")
    if not reason.strip():
        raise ValidationError("Reason for disposal is required.")
    rec = DisposalRecord.objects.create(
        document=doc, reason=reason, method=method, authority_reference=authority_reference, requested_by=user
    )
    doc.status = Status.DISPOSAL_REQUESTED
    doc.save()
    audit(Action.DISPOSAL_REQUESTED, request, user=user, document=doc, details=f"{rec.get_method_display()}; {reason}")
    notify(approvers(), f"Disposal requested for {doc.doc_id}: {doc.title}", link=doc.get_absolute_url(), level="danger")
    return rec


def _secure_erase(path):
    """Overwrite file content before unlinking (best effort on SSDs)."""
    try:
        size = os.path.getsize(path)
        with open(path, "r+b") as fh:
            remaining = size
            while remaining > 0:
                n = min(remaining, 1 << 20)
                fh.write(os.urandom(n))
                remaining -= n
            fh.flush()
            os.fsync(fh.fileno())
        os.remove(path)
        return True
    except FileNotFoundError:
        return True
    except OSError:
        log.exception("secure erase failed for %s", path)
        return False


def decide_disposal(rec, user, approve, remarks="", request=None):
    if not user.can_approve:
        raise PermissionDenied
    if rec.state != DisposalRecord.State.REQUESTED:
        raise ValidationError("This request was already decided.")
    if approve and rec.requested_by_id == user.pk and not user.is_admin_role:
        # four-eyes principle
        raise ValidationError("Disposal must be approved by a different Super Librarian or the Administrator.")
    doc = rec.document
    rec.decided_by = user
    rec.decided_at = timezone.now()
    rec.decision_remarks = remarks
    if not approve:
        rec.state = DisposalRecord.State.REJECTED
        rec.save()
        doc.status = Status.ACTIVE if (doc.permanent or not doc.expiry_date or doc.expiry_date > timezone.localdate()) else Status.UNDER_REVIEW
        doc.save()
        audit(Action.DISPOSAL_REJECTED, request, user=user, document=doc, details=remarks)
        return rec
    manifest = []
    with transaction.atomic():
        for f in doc.files.filter(purged=False):
            entry = {"file": f.original_name, "role": f.role, "size": f.size, "sha256": f.sha256}
            if rec.method in (DisposalRecord.Method.DIGITAL_DELETE, DisposalRecord.Method.DELETE_AND_SHRED, DisposalRecord.Method.TRANSFER):
                path = f.file.path if f.file else None
                entry["erased"] = _secure_erase(path) if path else True
                f.file = None
                f.purged = True
                f.extracted_text = ""
                f.save()
            manifest.append(entry)
        rec.file_manifest = json.dumps(manifest, indent=1)
        rec.state = DisposalRecord.State.APPROVED
        year = timezone.localdate().year
        n = DisposalRecord.objects.filter(state=DisposalRecord.State.APPROVED, decided_at__year=year).count() + 1
        rec.certificate_number = f"DSP-{year}-{n:04d}"
        rec.save()
        doc.status = Status.DISPOSED
        doc.extracted_text = ""
        doc.save()
        audit(Action.DISPOSAL_APPROVED, request, user=user, document=doc, details=f"Certificate {rec.certificate_number}; {remarks}")
        audit(Action.DISPOSED, request, user=user, document=doc,
              details=f"{rec.get_method_display()}; {len(manifest)} file(s) destroyed; reason: {rec.reason}")
    return rec
