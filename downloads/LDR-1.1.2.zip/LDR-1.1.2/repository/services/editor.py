"""
In-browser editing of Excel, CSV, Word and text files.

Edits never overwrite the original: the result is saved as a NEW VERSION of the
file (see lifecycle.add_version), so every earlier version stays available.
"""
import csv
import datetime as dt
import io
import re

from django.core.exceptions import ValidationError

from .viewer import read_csv

NUM_RE = re.compile(r"^-?\d+(\.\d+)?$")
DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}( \d{2}:\d{2})?$")


def _coerce(value, original=None):
    v = value.strip() if isinstance(value, str) else value
    if v == "":
        return None
    if isinstance(v, str):
        if v.startswith("="):
            return v
        plain = v.replace(",", "") if NUM_RE.match(v.replace(",", "")) else None
        if plain is not None:
            return int(plain) if "." not in plain else float(plain)
        if DATE_RE.match(v) and (original is None or isinstance(original, (dt.date, dt.datetime))):
            try:
                return dt.datetime.strptime(v, "%Y-%m-%d %H:%M") if " " in v else dt.datetime.strptime(v, "%Y-%m-%d")
            except ValueError:
                pass
    return v


def apply_sheet_edits(data, ext, edits):
    """
    edits = {"<sheet name>": {"<row>,<col>": "new value", ...}}  (1-based row/col)
    Returns new file bytes. Formatting of untouched cells is preserved for .xlsx.
    """
    if not isinstance(edits, dict):
        raise ValidationError("Invalid edit data.")
    if ext == "csv":
        rows, dialect = read_csv(data)
        for _sheet, cells in edits.items():
            for key, val in cells.items():
                r, c = (int(x) for x in key.split(","))
                while len(rows) < r:
                    rows.append([])
                row = rows[r - 1]
                while len(row) < c:
                    row.append("")
                row[c - 1] = "" if val is None else str(val)
        while rows and not any(str(x).strip() for x in rows[-1]):
            rows.pop()
        out = io.StringIO()
        csv.writer(out, delimiter=getattr(dialect, "delimiter", ","), lineterminator="\r\n").writerows(rows)
        return out.getvalue().encode("utf-8-sig")

    import openpyxl

    wb = openpyxl.load_workbook(io.BytesIO(data), keep_vba=(ext == "xlsm"))
    for sheet, cells in edits.items():
        if sheet not in wb.sheetnames:
            raise ValidationError(f"Sheet '{sheet}' not found.")
        ws = wb[sheet]
        for key, val in cells.items():
            r, c = (int(x) for x in key.split(","))
            if r < 1 or c < 1 or r > 1_048_576 or c > 16384:
                raise ValidationError("Cell out of range.")
            cell = ws.cell(row=r, column=c)
            if type(cell).__name__ == "MergedCell":
                continue
            cell.value = _coerce(val, cell.value)
    out = io.BytesIO()
    wb.save(out)
    return out.getvalue()


# ---------------------------------------------------------------- Word
def _iter_paragraphs(doc):
    """Yield (id, paragraph) for body paragraphs and table-cell paragraphs."""
    for i, p in enumerate(doc.paragraphs):
        yield f"p{i}", p
    for ti, table in enumerate(doc.tables):
        for ri, row in enumerate(table.rows):
            seen = set()
            for ci, cell in enumerate(row.cells):
                if id(cell._tc) in seen:  # merged cells repeat
                    continue
                seen.add(id(cell._tc))
                for pi, p in enumerate(cell.paragraphs):
                    yield f"t{ti}r{ri}c{ci}p{pi}", p


def word_paragraphs(data):
    import docx

    doc = docx.Document(io.BytesIO(data))
    items = []
    for pid, p in _iter_paragraphs(doc):
        items.append({
            "id": pid,
            "text": p.text,
            "style": p.style.name if p.style is not None else "",
            "table": pid.startswith("t"),
            "heading": (p.style is not None and p.style.name.lower().startswith(("heading", "title"))),
        })
    return items


def apply_word_edits(data, edits, appended=""):
    """
    edits = {"<paragraph id>": "new text"}. The paragraph keeps its style and the
    formatting of its first run; ``appended`` text is added as new paragraphs at the end.
    """
    import docx

    doc = docx.Document(io.BytesIO(data))
    paras = dict(_iter_paragraphs(doc))
    for pid, new_text in (edits or {}).items():
        p = paras.get(pid)
        if p is None or p.text == new_text:
            continue
        runs = p.runs
        if runs:
            runs[0].text = new_text
            for r in runs[1:]:
                r.text = ""
        else:
            p.add_run(new_text)
    for line in (appended or "").splitlines():
        if line.strip():
            doc.add_paragraph(line)
    out = io.BytesIO()
    doc.save(out)
    return out.getvalue()


def apply_text_edit(new_text):
    return new_text.replace("\r\n", "\n").encode("utf-8")
