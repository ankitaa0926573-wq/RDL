"""
In-app software updates.

How it works
------------
* The developer publishes two files on the LDR website (see tools/release.py):
    latest.json        - newest version number, release notes, download link, SHA-256
    LDR-x.y.z.zip      - the release; contains RELEASE_MANIFEST.json (SHA-256 of every
                         file) and RELEASE_SIGNATURE.txt (Ed25519 signature of the manifest)
* Every installation checks latest.json once a day and shows the administrator an
  "Update available" banner.
* "Update now" downloads the zip, verifies the SHA-256 and the developer's digital
  signature, makes a full backup, and stages the files. The server then restarts;
  the supervisor in run_server.py swaps the program files, starts the new version
  and rolls everything back automatically if it does not start.
* Libraries without internet can upload the release zip instead (same checks).
"""
import base64
import hashlib
import json
import logging
import os
import shutil
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path

from django.conf import settings
from django.core.exceptions import ValidationError
from django.utils import timezone

from .. import update_source
from ..models import Action, Role, SiteSettings, User
from .audit import audit, notify

log = logging.getLogger("ldr")

MANIFEST = "RELEASE_MANIFEST.json"
SIGNATURE = "RELEASE_SIGNATURE.txt"
MAX_DOWNLOAD = 600 * 1024 * 1024
RESTART_EXIT_CODE = 75

# Never touched by an update (user data and local installation)
PROTECTED = {"data", ".venv", "venv", "staticfiles", "ldr_config.ini", ".git", "dist", "release_keys", "website", "release_settings.ini", "publish_release.bat"}


def updates_dir():
    d = settings.DATA_DIR / "updates"
    d.mkdir(parents=True, exist_ok=True)
    return d


def pending_file():
    return updates_dir() / "pending.json"


def result_file():
    return updates_dir() / "last_result.json"


def parse_version(v):
    parts = []
    for p in str(v).strip().lstrip("vV").split("."):
        num = "".join(ch for ch in p if ch.isdigit())
        parts.append(int(num) if num else 0)
    while len(parts) < 3:
        parts.append(0)
    return tuple(parts[:3])


def is_newer(candidate, current=None):
    return parse_version(candidate) > parse_version(current or settings.LDR_VERSION)


def update_url():
    s = SiteSettings.load()
    return (s.update_url or settings.CONFIG.get("updates", "url", fallback="") or update_source.UPDATE_URL).strip()


def self_update_supported():
    """False inside Docker (update the image instead)."""
    return not os.environ.get("LDR_DOCKER")


def supervised():
    return os.environ.get("LDR_SUPERVISED") == "1"


def latest_info():
    s = SiteSettings.load()
    try:
        return json.loads(s.update_latest_info) if s.update_latest_info else None
    except ValueError:
        return None


def update_available():
    s = SiteSettings.load()
    return bool(s.update_latest_version and is_newer(s.update_latest_version))


# ----------------------------------------------------------------- checking
def _http_get(url, timeout=20):
    req = urllib.request.Request(url, headers={
        "User-Agent": f"LDR/{settings.LDR_VERSION}",
        "Cache-Control": "no-cache",
    })
    return urllib.request.urlopen(req, timeout=timeout)


def check_for_update(user=None, request=None):
    """Fetch latest.json. Returns the info dict (with 'newer': bool)."""
    s = SiteSettings.load()
    url = update_url()
    s.update_last_check = timezone.now()
    if not url:
        s.update_check_error = "No update address configured."
        s.save()
        raise ValidationError("No update address is configured. Enter the address of latest.json in Settings.")
    try:
        # cache-buster so web hosts/CDNs never serve an old latest.json
        sep = "&" if "?" in url else "?"
        with _http_get(f"{url}{sep}t={int(time.time())}") as resp:
            raw = resp.read(256 * 1024)
        info = json.loads(raw.decode("utf-8"))
        if info.get("product", "LDR") != "LDR" or "version" not in info or "download_url" not in info:
            raise ValueError("latest.json is missing required fields")
        info["download_url"] = urllib.parse.urljoin(url, info["download_url"])
    except (urllib.error.URLError, OSError, ValueError) as exc:
        s.update_check_error = f"Could not check for updates: {exc}"[:400]
        s.save()
        raise ValidationError(s.update_check_error)
    s.update_check_error = ""
    s.update_latest_version = str(info["version"])
    s.update_latest_info = json.dumps(info)
    s.save()
    info["newer"] = is_newer(info["version"])
    if info["newer"]:
        admins = User.objects.filter(is_active=True, role=Role.ADMIN)
        created = notify(admins, f"LDR update available: version {info['version']} (you have {settings.LDR_VERSION}).",
                         link="/admin/settings/#updates", level="info", dedupe_key=f"update-{info['version']}")
        if created:
            audit(Action.UPDATE_AVAILABLE, request, user=user, details=f"Version {info['version']} published")
    return info


# ----------------------------------------------------------------- verification
def _public_key():
    from cryptography.hazmat.primitives.serialization import load_pem_public_key

    return load_pem_public_key(update_source.PUBLIC_KEY_PEM.encode())


def verify_release_dir(root: Path):
    """Check signature + every file hash. Returns the manifest dict."""
    from cryptography.exceptions import InvalidSignature

    mpath, spath = root / MANIFEST, root / SIGNATURE
    if not mpath.exists() or not spath.exists():
        raise ValidationError("This is not a signed LDR release (manifest or signature missing).")
    manifest_bytes = mpath.read_bytes()
    try:
        _public_key().verify(base64.b64decode(spath.read_text().strip()), manifest_bytes)
    except (InvalidSignature, ValueError):
        raise ValidationError("Digital signature check FAILED - this update was not published by the LDR developer.")
    manifest = json.loads(manifest_bytes.decode("utf-8"))
    files = manifest.get("files", {})
    for rel, digest in files.items():
        p = root / rel
        if ".." in Path(rel).parts or Path(rel).is_absolute():
            raise ValidationError("Release contains an unsafe path.")
        if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest() != digest:
            raise ValidationError(f"Release file damaged or modified: {rel}")
    actual = {str(p.relative_to(root)).replace("\\", "/") for p in root.rglob("*") if p.is_file()}
    extra = actual - set(files) - {MANIFEST, SIGNATURE}
    if extra:
        raise ValidationError(f"Release contains unexpected files: {sorted(extra)[:5]}")
    return manifest


def _extract(zip_path: Path):
    stage = updates_dir() / "staging" / f"{int(time.time())}"
    if stage.exists():
        shutil.rmtree(stage)
    stage.mkdir(parents=True)
    with zipfile.ZipFile(zip_path) as zf:
        for info in zf.infolist():
            name = info.filename
            if name.startswith("/") or ".." in Path(name).parts:
                raise ValidationError("Release zip contains unsafe paths.")
        zf.extractall(stage)
    # release zips contain a single top folder LDR-x.y.z/
    candidates = [stage] + [p for p in stage.iterdir() if p.is_dir()]
    for c in candidates:
        if (c / MANIFEST).exists():
            return c
    raise ValidationError("This zip is not an LDR release (RELEASE_MANIFEST.json not found).")


def stage_update(zip_path: Path, user, request=None, expected_sha256=None):
    """Verify a release zip and prepare it for installation. Returns the manifest."""
    if not self_update_supported():
        raise ValidationError("This installation runs in Docker: update by pulling/building the new image.")
    if pending_file().exists():
        raise ValidationError("An update is already being installed. Restart LDR to finish it.")
    if expected_sha256:
        h = hashlib.sha256()
        with open(zip_path, "rb") as fh:
            for chunk in iter(lambda: fh.read(1 << 20), b""):
                h.update(chunk)
        if h.hexdigest() != expected_sha256.lower():
            raise ValidationError("Downloaded file is damaged (SHA-256 mismatch). Please try again.")
    root = _extract(zip_path)
    stage_dir = root if root.parent.name == "staging" else root.parent
    try:
        manifest = verify_release_dir(root)
        new_ver = manifest.get("version", "")
        if not is_newer(new_ver):
            raise ValidationError(f"Version {new_ver} is not newer than the installed version {settings.LDR_VERSION}.")
        min_from = manifest.get("min_from_version")
        if min_from and parse_version(settings.LDR_VERSION) < parse_version(min_from):
            raise ValidationError(f"Version {new_ver} requires at least version {min_from}. Install {min_from} first.")
    except ValidationError:
        shutil.rmtree(stage_dir, ignore_errors=True)
        raise
    from .maintenance import make_backup

    backup = make_backup(user=user, request=request)
    pending = {
        "version": new_ver,
        "from_version": settings.LDR_VERSION,
        "source_dir": str(root),
        "backup": str(backup),
        "requested_by": user.username if user else "system",
        "requested_at": timezone.now().isoformat(),
        "database": str(settings.DATABASES["default"]["NAME"]) if settings.DATABASES["default"]["ENGINE"].endswith("sqlite3") else "",
    }
    pending_file().write_text(json.dumps(pending, indent=1), encoding="utf-8")
    audit(Action.UPDATE_STARTED, request, user=user,
          details=f"Updating {settings.LDR_VERSION} -> {new_ver}; signature verified; backup {Path(backup).name}")
    return manifest


def download_and_stage(user, request=None):
    info = latest_info()
    if not info or not is_newer(info.get("version", "0")):
        raise ValidationError("No newer version is available. Click 'Check for updates' first.")
    dl = updates_dir() / "downloads"
    dl.mkdir(exist_ok=True)
    target = dl / f"LDR-{info['version']}.zip"
    try:
        with _http_get(info["download_url"], timeout=60) as resp, open(target, "wb") as out:
            total = 0
            for chunk in iter(lambda: resp.read(1 << 20), b""):
                total += len(chunk)
                if total > MAX_DOWNLOAD:
                    raise ValidationError("Download is unexpectedly large - aborted.")
                out.write(chunk)
    except (urllib.error.URLError, OSError) as exc:
        raise ValidationError(f"Download failed: {exc}")
    return stage_update(target, user, request, expected_sha256=info.get("sha256"))


def request_restart():
    """Ask the supervisor to restart the server so the staged update is installed."""
    if not supervised():
        return False
    threading.Timer(1.5, lambda: os._exit(RESTART_EXIT_CODE)).start()
    return True


def cancel_pending():
    p = pending_file()
    if p.exists():
        data = json.loads(p.read_text(encoding="utf-8"))
        shutil.rmtree(data.get("source_dir", ""), ignore_errors=True)
        p.unlink()


def record_last_result():
    """Called once at server start: log the outcome of an update the supervisor performed."""
    rf = result_file()
    if not rf.exists():
        return None
    try:
        res = json.loads(rf.read_text(encoding="utf-8"))
    except ValueError:
        return None
    if res.get("logged"):
        return res
    ok = res.get("ok")
    audit(Action.UPDATE_APPLIED if ok else Action.UPDATE_FAILED,
          details=f"{res.get('from_version')} -> {res.get('version')}: {res.get('message', '')}")
    admins = User.objects.filter(is_active=True, role=Role.ADMIN)
    notify(admins, (f"LDR was updated to version {res.get('version')}." if ok else
                    f"Update to {res.get('version')} failed and was rolled back: {res.get('message', '')}"),
           link="/admin/settings/#updates", level="success" if ok else "danger")
    res["logged"] = True
    rf.write_text(json.dumps(res, indent=1), encoding="utf-8")
    return res


def last_result():
    try:
        return json.loads(result_file().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
