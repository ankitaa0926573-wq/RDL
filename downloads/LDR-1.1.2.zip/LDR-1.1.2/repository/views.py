import csv
import mimetypes
import os
import zipfile
from datetime import timedelta
from functools import wraps

from django.conf import settings
from django.contrib import messages
from django.contrib.auth import login as auth_login
from django.contrib.auth import update_session_auth_hash
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied, ValidationError
from django.core.paginator import Paginator
from django.db.models import Count, Q, Sum
from django.http import FileResponse, Http404, HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.http import require_POST

from . import forms as F
from .models import (
    PHASE_NAMES,
    AccessRequest,
    Action,
    AuditLog,
    Category,
    Confidentiality,
    Department,
    DisposalRecord,
    Document,
    DocumentFile,
    FileRole,
    Notification,
    RetentionReview,
    Role,
    SiteSettings,
    Status,
    User,
)
from .services import lifecycle as L
from .services import maintenance as M
from .services.audit import audit, verify_chain
from .services.extract import ocr_available

WORKFLOW_STATES = [Status.RECEIVED, Status.DIGITIZED, Status.METADATA_DONE, Status.RETURNED, Status.PENDING_APPROVAL]


def require(attr):
    """Decorator: user must have the boolean permission property ``attr``."""

    def deco(view):
        @wraps(view)
        @login_required
        def wrapper(request, *a, **kw):
            if not getattr(request.user, attr, False):
                raise PermissionDenied
            return view(request, *a, **kw)

        return wrapper

    return deco


def _errors(request, exc):
    for m in getattr(exc, "messages", [str(exc)]):
        messages.error(request, m)


# ======================================================================
# First-run setup (like Koha's web installer)
# ======================================================================
def setup(request):
    s = SiteSettings.load()
    if s.setup_completed and User.objects.exists():
        return redirect("dashboard")
    form = F.SetupForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        d = form.cleaned_data
        if d["load_defaults"]:
            from .defaults import load_defaults

            load_defaults()
        first, _, last = d["admin_full_name"].partition(" ")
        user = User.objects.create_superuser(
            username=d["admin_username"], email=d["admin_email"], password=d["password1"],
            first_name=first, last_name=last, role=Role.ADMIN,
        )
        s.library_name = d["library_name"]
        s.institution_name = d["institution_name"]
        s.id_prefix = d["id_prefix"].upper().strip() or "LDR"
        s.setup_completed = True
        s.save()
        audit(Action.SETTINGS, request, user=user, details="Initial setup completed")
        auth_login(request, user)
        messages.success(request, "Setup complete. Welcome to the Library Document Repository!")
        return redirect("dashboard")
    return render(request, "repository/setup.html", {"form": form})


# ======================================================================
# Dashboard
# ======================================================================
@login_required
def dashboard(request):
    u = request.user
    today = timezone.localdate()
    s = SiteSettings.load()
    visible = L.visible_documents(u)
    stats = {
        "total": Document.objects.exclude(status=Status.DISPOSED).count(),
        "active": Document.objects.filter(status=Status.ACTIVE).count(),
        "workflow": Document.objects.filter(status__in=WORKFLOW_STATES).count(),
        "review": Document.objects.filter(status=Status.UNDER_REVIEW).count(),
        "disposed": Document.objects.filter(status=Status.DISPOSED).count(),
        "files": DocumentFile.objects.filter(purged=False).count(),
        "storage": DocumentFile.objects.filter(purged=False).aggregate(s=Sum("size"))["s"] or 0,
    }
    phase_counts = []
    by_status = dict(Document.objects.values_list("status").annotate(c=Count("id")))
    groups = {
        1: [Status.RECEIVED], 2: [Status.DIGITIZED], 3: [Status.METADATA_DONE],
        4: [Status.PENDING_APPROVAL, Status.RETURNED], 5: [Status.ACTIVE], 6: [Status.UNDER_REVIEW],
        7: [Status.DISPOSAL_REQUESTED, Status.DISPOSED],
    }
    for n, name in PHASE_NAMES:
        phase_counts.append((n, name, sum(by_status.get(st, 0) for st in groups[n])))
    my_tasks = Document.objects.filter(
        Q(custodian=u) | Q(created_by=u), status__in=[Status.RECEIVED, Status.DIGITIZED, Status.METADATA_DONE, Status.RETURNED]
    )[:10]
    expiring = visible.filter(
        status=Status.ACTIVE, permanent=False, expiry_date__gte=today,
        expiry_date__lte=today + timedelta(days=s.alert_days_before_expiry),
    ).order_by("expiry_date")[:8]
    recent = visible.exclude(status=Status.DISPOSED).order_by("-created_at")[:8]
    by_category = (
        Document.objects.exclude(status=Status.DISPOSED).values("category__name").annotate(c=Count("id")).order_by("-c")[:8]
    )
    return render(request, "repository/dashboard.html", {
        "stats": stats, "phase_counts": phase_counts, "my_tasks": my_tasks, "expiring": expiring,
        "recent": recent, "by_category": by_category,
        "notifications": u.notifications.filter(read=False)[:6],
        "ocr": ocr_available(),
    })


# ======================================================================
# Search / list
# ======================================================================
def _search(request):
    form = F.SearchForm(request.GET or None)
    qs = L.visible_documents(request.user).select_related("category", "department", "custodian")
    if form.is_valid():
        d = form.cleaned_data
        if d["q"]:
            for term in d["q"].split():
                cond = (
                    Q(title__icontains=term) | Q(doc_id__icontains=term) | Q(keywords__icontains=term)
                    | Q(description__icontains=term) | Q(reference_number__icontains=term)
                    | Q(received_from__icontains=term) | Q(creator__icontains=term)
                )
                # full-text search inside files; confidential text is searched only for Super Librarians
                if request.user.is_super_librarian:
                    cond |= Q(extracted_text__icontains=term)
                else:
                    cond |= Q(extracted_text__icontains=term) & ~Q(confidentiality=Confidentiality.CONFIDENTIAL)
                qs = qs.filter(cond)
        if d["category"]:
            qs = qs.filter(category=d["category"])
        if d["department"]:
            qs = qs.filter(department=d["department"])
        if d["status"] == "WORKFLOW":
            qs = qs.filter(status__in=WORKFLOW_STATES)
        elif d["status"]:
            qs = qs.filter(status=d["status"])
        else:
            qs = qs.exclude(status=Status.DISPOSED)
        if d["year"]:
            qs = qs.filter(document_year__icontains=d["year"])
        if d["date_from"]:
            qs = qs.filter(received_date__gte=d["date_from"])
        if d["date_to"]:
            qs = qs.filter(received_date__lte=d["date_to"])
    else:
        qs = qs.exclude(status=Status.DISPOSED)
    return form, qs.distinct()


@login_required
def document_list(request):
    form, qs = _search(request)
    sort = request.GET.get("sort", "-created_at")
    if sort.lstrip("-") in ("created_at", "title", "doc_id", "expiry_date", "received_date", "status"):
        qs = qs.order_by(sort)
    page = Paginator(qs, 25).get_page(request.GET.get("page"))
    params = request.GET.copy()
    params.pop("page", None)
    return render(request, "repository/document_list.html", {
        "form": form, "page": page, "total": qs.count(), "params": params.urlencode(), "sort": sort,
    })


@login_required
def document_export(request):
    _form, qs = _search(request)
    audit(Action.DOWNLOADED, request, details=f"CSV export of {qs.count()} records")
    resp = HttpResponse(content_type="text/csv; charset=utf-8")
    resp["Content-Disposition"] = f'attachment; filename="ldr_documents_{timezone.localdate()}.csv"'
    resp.write("﻿")
    w = csv.writer(resp)
    w.writerow(["Document ID", "Title", "Category", "Department", "Year", "Received date", "Received from",
                "Reference no.", "Status", "Confidentiality", "Custodian", "Expiry date", "Physical location", "Keywords"])
    for d in qs:
        w.writerow([d.doc_id, d.title, d.category.name, d.department or "", d.document_year, d.received_date,
                    d.received_from, d.reference_number, d.get_status_display(), d.get_confidentiality_display(),
                    d.custodian, "Permanent" if d.permanent else (d.expiry_date or ""), d.physical_location, d.keywords])
    return resp


# ======================================================================
# Phase 1 - Receipt
# ======================================================================
@require("can_register")
def document_new(request):
    form = F.ReceiptForm(request.POST or None, initial={"department": request.user.department_id})
    if request.method == "POST" and form.is_valid():
        doc = form.save(commit=False)
        doc.confidentiality = form.cleaned_data["confidentiality"]
        L.register_document(doc, request.user, request)
        messages.success(request, f"Document registered as {doc.doc_id}. Next: attach the digitized file(s).")
        return redirect("document_detail", doc.pk)
    return render(request, "repository/document_new.html", {"form": form})


# ======================================================================
# Document detail (all phases)
# ======================================================================
@login_required
def document_detail(request, pk):
    doc = get_object_or_404(Document.objects.select_related("category", "department", "custodian", "created_by"), pk=pk)
    u = request.user
    if not L.visible_documents(u, Document.objects.filter(pk=pk)).exists():
        raise PermissionDenied
    can_open = L.can_open(u, doc)
    if can_open:
        audit(Action.VIEWED, request, document=doc)
    pending_req = AccessRequest.objects.filter(document=doc, requested_by=u, state=AccessRequest.State.PENDING).first()
    grant = AccessRequest.objects.filter(
        document=doc, requested_by=u, state=AccessRequest.State.APPROVED, valid_until__gte=timezone.now()
    ).first()
    ctx = {
        "doc": doc,
        "can_open": can_open,
        "phases": PHASE_NAMES,
        "files": doc.files.filter(is_current=True).select_related("uploaded_by") if can_open else [],
        "pending_versions": doc.files.filter(pending_approval=True, role=FileRole.MASTER).select_related("uploaded_by", "previous") if can_open else [],
        "old_versions": doc.files.filter(is_current=False, pending_approval=False).select_related("uploaded_by").order_by("-uploaded_at") if can_open else [],
        "upload_form": F.UploadForm(),
        "decision_form": F.DecisionForm(),
        "year_choices": L.RETENTION_YEAR_CHOICES,
        "access_form": F.AccessRequestForm(),
        "review_form": F.RetentionReviewForm(),
        "disposal_form": F.DisposalRequestForm(),
        "pending_req": pending_req,
        "grant": grant,
        "missing": [m.replace("_", " ") for m in L.metadata_missing(doc)] if doc.is_editable else [],
        "reviews": doc.reviews.select_related("reviewed_by")[:10],
        "disposals": doc.disposals.select_related("requested_by", "decided_by"),
        "history": doc.audit.exclude(action=Action.VIEWED).select_related("user").order_by("-id")[:40] if can_open else [],
        "access_log": doc.audit.filter(action__in=[Action.VIEWED, Action.DOWNLOADED]).order_by("-id")[:20]
        if u.can_view_audit else [],
        "ocr": ocr_available(),
        "can_edit_files": doc.is_editable and (u.can_digitize or doc.created_by_id == u.pk),
    }
    return render(request, "repository/document_detail.html", ctx)


# ======================================================================
# Phase 2 - Digitization
# ======================================================================
@login_required
@require_POST
def document_upload(request, pk):
    doc = get_object_or_404(Document, pk=pk)
    form = F.UploadForm(request.POST, request.FILES)
    if not form.is_valid():
        messages.error(request, "Please choose at least one file.")
        return redirect("document_detail", pk)
    for f in form.cleaned_data["files"]:
        try:
            _df, info = L.add_file(doc, f, request.user, request)
            msg = f"Uploaded {f.name}."
            if info["note"]:
                msg += " " + info["note"] + "."
            messages.success(request, msg)
        except (ValidationError, PermissionDenied) as e:
            if isinstance(e, PermissionDenied):
                raise
            _errors(request, e)
    return redirect("document_detail", pk)


@login_required
@require_POST
def file_remove(request, pk):
    df = get_object_or_404(DocumentFile, pk=pk)
    L.remove_file(df, request.user, request)
    messages.info(request, f"Removed {df.original_name}.")
    return redirect("document_detail", df.document_id)


@login_required
@require_POST
def document_digitized(request, pk):
    doc = get_object_or_404(Document, pk=pk)
    try:
        L.mark_digitized(doc, request.user, request)
        messages.success(request, "Digitization complete. Next: assign metadata.")
        return redirect("document_metadata", pk)
    except ValidationError as e:
        _errors(request, e)
    return redirect("document_detail", pk)


@login_required
def file_download(request, pk):
    df = get_object_or_404(DocumentFile.objects.select_related("document"), pk=pk)
    doc = df.document
    if not L.can_open(request.user, doc):
        audit(Action.ACCESS_DENIED, request, document=doc, details=df.original_name)
        raise PermissionDenied
    if df.purged or not df.file:
        raise Http404("This file was destroyed during secure disposal.")
    inline = request.GET.get("inline") == "1" and df.can_preview_inline
    audit(Action.VIEWED if inline else Action.DOWNLOADED, request, document=doc, details=df.original_name)
    resp = FileResponse(df.file.open("rb"), as_attachment=not inline, filename=df.original_name,
                        content_type=df.mime_type or mimetypes.guess_type(df.original_name)[0])
    resp["Cache-Control"] = "no-store"
    return resp


# ======================================================================
# Phase 3 - Metadata
# ======================================================================
@require("can_catalogue")
def document_metadata(request, pk):
    doc = get_object_or_404(Document, pk=pk)
    if not doc.is_editable:
        messages.warning(request, "Metadata is locked after submission/approval.")
        return redirect("document_detail", pk)
    form = F.MetadataForm(request.POST or None, instance=doc, user=request.user)
    if request.method == "POST" and form.is_valid():
        doc = form.save(commit=False)
        try:
            L.save_metadata(doc, request.user, form.changed_data, request)
        except ValidationError as e:
            _errors(request, e)
            return redirect("document_detail", pk)
        if "submit" in request.POST:
            try:
                L.submit_for_approval(doc, request.user, request)
                messages.success(request, "Metadata saved and sent to the Super Librarian for approval.")
            except ValidationError as e:
                _errors(request, e)
        else:
            messages.success(request, "Metadata saved.")
        return redirect("document_detail", pk)
    snippet = (doc.extracted_text or "")[:1500]
    return render(request, "repository/document_metadata.html", {"form": form, "doc": doc, "snippet": snippet})


# ======================================================================
# Phase 4 - Validation & approval
# ======================================================================
@login_required
@require_POST
def document_submit(request, pk):
    doc = get_object_or_404(Document, pk=pk)
    try:
        L.submit_for_approval(doc, request.user, request)
        messages.success(request, "Sent for approval.")
    except ValidationError as e:
        _errors(request, e)
    return redirect("document_detail", pk)


@require("can_approve")
@require_POST
def document_decide(request, pk):
    doc = get_object_or_404(Document, pk=pk)
    form = F.DecisionForm(request.POST)
    form.is_valid()
    remarks = form.cleaned_data.get("remarks", "")
    try:
        if request.POST.get("decision") == "approve":
            L.approve(doc, request.user, remarks, request,
                      retention=form.cleaned_data.get("retention") or "default",
                      retention_until=form.cleaned_data.get("retention_until"))
            messages.success(request, f"{doc.doc_id} approved. It is now an official record.")
        else:
            L.return_for_correction(doc, request.user, remarks, request)
            messages.warning(request, f"{doc.doc_id} returned for correction.")
    except ValidationError as e:
        _errors(request, e)
    nxt = request.POST.get("next", "")
    if nxt.startswith("/"):
        return redirect(nxt)
    return redirect("document_detail", pk)


@require("can_approve")
def approvals(request):
    docs = Document.objects.filter(status=Status.PENDING_APPROVAL).select_related("category", "created_by").order_by("submitted_at")
    versions = DocumentFile.objects.filter(pending_approval=True, role=FileRole.MASTER).select_related(
        "document", "uploaded_by", "previous").order_by("uploaded_at")
    return render(request, "repository/approvals.html", {"docs": docs, "versions": versions, "decision_form": F.DecisionForm(),
                                                        "year_choices": L.RETENTION_YEAR_CHOICES})


# ======================================================================
# Phase 5 - Access requests
# ======================================================================
@login_required
@require_POST
def access_request(request, pk):
    doc = get_object_or_404(Document, pk=pk)
    form = F.AccessRequestForm(request.POST)
    if form.is_valid():
        try:
            L.request_access(doc, request.user, form.cleaned_data["purpose"], request)
            messages.success(request, "Access request sent to the Super Librarian.")
        except ValidationError as e:
            _errors(request, e)
    return redirect("document_detail", pk)


@login_required
def access_requests(request):
    u = request.user
    if u.can_approve:
        pending = AccessRequest.objects.filter(state=AccessRequest.State.PENDING).select_related("document", "requested_by")
        decided = AccessRequest.objects.exclude(state=AccessRequest.State.PENDING).select_related("document", "requested_by", "decided_by")[:50]
    else:
        pending = AccessRequest.objects.filter(requested_by=u, state=AccessRequest.State.PENDING).select_related("document")
        decided = AccessRequest.objects.filter(requested_by=u).exclude(state=AccessRequest.State.PENDING).select_related("document")[:50]
    return render(request, "repository/access_requests.html", {"pending": pending, "decided": decided})


@require("can_approve")
@require_POST
def access_decide(request, pk):
    ar = get_object_or_404(AccessRequest, pk=pk, state=AccessRequest.State.PENDING)
    L.decide_access(ar, request.user, request.POST.get("decision") == "approve", request.POST.get("remarks", ""), request)
    messages.success(request, "Decision recorded.")
    return redirect("access_requests")


# ======================================================================
# Phase 6 - Retention monitoring
# ======================================================================
@require("can_manage_retention")
def retention(request):
    s = SiteSettings.load()
    today = timezone.localdate()
    due = Document.objects.filter(status=Status.UNDER_REVIEW).select_related("category").order_by("expiry_date")
    soon = Document.objects.filter(
        status=Status.ACTIVE, permanent=False, expiry_date__gt=today,
        expiry_date__lte=today + timedelta(days=max(s.alert_days_before_expiry, 90)),
    ).select_related("category").order_by("expiry_date")
    recent_reviews = RetentionReview.objects.select_related("document", "reviewed_by")[:20]
    schedule = Category.objects.annotate(
        n=Count("document", filter=~Q(document__status=Status.DISPOSED))
    ).order_by("name")
    return render(request, "repository/retention.html", {
        "due": due, "soon": soon, "recent_reviews": recent_reviews, "schedule": schedule,
        "review_form": F.RetentionReviewForm(), "last_run": s.last_daily_run,
    })


@require("can_manage_retention")
@require_POST
def retention_review(request, pk):
    doc = get_object_or_404(Document, pk=pk)
    form = F.RetentionReviewForm(request.POST)
    if form.is_valid():
        d = form.cleaned_data
        try:
            L.review_retention(doc, request.user, d["decision"], d["remarks"], d["new_expiry"], request)
            if d["decision"] == RetentionReview.Decision.DISPOSE:
                messages.info(request, "Review recorded. Now complete the disposal request below.")
                return redirect(f"{doc.get_absolute_url()}#disposal")
            messages.success(request, "Retention decision recorded.")
        except ValidationError as e:
            _errors(request, e)
    else:
        messages.error(request, "Please choose a decision.")
    return redirect("document_detail", pk)


@require("can_manage_retention")
@require_POST
def run_daily(request):
    r = M.retention_check()
    fx = M.fixity_check()
    messages.success(request, f"Retention check: {r['expired_flagged']} flagged for review, {r['upcoming_alerts']} alerts. "
                              f"Integrity check: {fx['ok']} OK, {fx['failed']} failed.")
    return redirect(request.POST.get("next") or "retention")


# ======================================================================
# Phase 7 - Secure disposal
# ======================================================================
@login_required
@require_POST
def disposal_request(request, pk):
    doc = get_object_or_404(Document, pk=pk)
    form = F.DisposalRequestForm(request.POST)
    if form.is_valid():
        d = form.cleaned_data
        try:
            L.request_disposal(doc, request.user, d["reason"], d["method"], d["authority_reference"], request)
            messages.success(request, "Disposal request submitted for approval.")
        except ValidationError as e:
            _errors(request, e)
    else:
        messages.error(request, "Reason for disposal is required.")
    return redirect("document_detail", pk)


@require("can_approve")
def disposals(request):
    pending = DisposalRecord.objects.filter(state=DisposalRecord.State.REQUESTED).select_related("document", "requested_by")
    done = DisposalRecord.objects.exclude(state=DisposalRecord.State.REQUESTED).select_related("document", "requested_by", "decided_by")
    page = Paginator(done, 30).get_page(request.GET.get("page"))
    return render(request, "repository/disposals.html", {"pending": pending, "page": page})


@require("can_approve")
@require_POST
def disposal_decide(request, pk):
    rec = get_object_or_404(DisposalRecord, pk=pk)
    approve_ = request.POST.get("decision") == "approve"
    if approve_ and request.POST.get("confirm") != rec.document.doc_id:
        messages.error(request, f"Type the document ID ({rec.document.doc_id}) to confirm permanent destruction.")
        return redirect("disposals")
    try:
        L.decide_disposal(rec, request.user, approve_, request.POST.get("remarks", ""), request)
        if approve_:
            messages.success(request, f"{rec.document.doc_id} disposed. Certificate {rec.certificate_number} generated.")
            return redirect("disposal_certificate", rec.pk)
        messages.info(request, "Disposal request rejected; the document stays in the repository.")
    except ValidationError as e:
        _errors(request, e)
    return redirect("disposals")


@require("can_approve")
def disposal_certificate(request, pk):
    rec = get_object_or_404(DisposalRecord.objects.select_related("document", "requested_by", "decided_by"), pk=pk,
                            state=DisposalRecord.State.APPROVED)
    return render(request, "repository/disposal_certificate.html", {"rec": rec, "manifest": rec.manifest()})


# ======================================================================
# Audit trail & reports
# ======================================================================
@require("can_view_audit")
def audit_log(request):
    qs = AuditLog.objects.select_related("user")
    q = request.GET.get("q", "").strip()
    action = request.GET.get("action", "")
    user = request.GET.get("user", "")
    dfrom, dto = request.GET.get("from", ""), request.GET.get("to", "")
    if q:
        qs = qs.filter(Q(doc_ref__icontains=q) | Q(details__icontains=q))
    if action:
        qs = qs.filter(action=action)
    if user:
        qs = qs.filter(username=user)
    if dfrom:
        qs = qs.filter(timestamp__date__gte=dfrom)
    if dto:
        qs = qs.filter(timestamp__date__lte=dto)
    if request.GET.get("export") == "csv":
        audit(Action.DOWNLOADED, request, details="Audit log CSV export")
        resp = HttpResponse(content_type="text/csv; charset=utf-8")
        resp["Content-Disposition"] = f'attachment; filename="ldr_audit_{timezone.localdate()}.csv"'
        resp.write("﻿")
        w = csv.writer(resp)
        w.writerow(["#", "Timestamp", "User", "Action", "Document", "Details", "IP", "Hash"])
        for e in qs.order_by("id"):
            w.writerow([e.id, timezone.localtime(e.timestamp).strftime("%Y-%m-%d %H:%M:%S"), e.username, e.action,
                        e.doc_ref, e.details, e.ip_address or "", e.entry_hash])
        return resp
    verify = None
    if request.GET.get("verify"):
        ok, n, bad = verify_chain()
        verify = {"ok": ok, "count": n, "bad": bad}
    actions = AuditLog.objects.values_list("action", flat=True).distinct().order_by("action")
    users = AuditLog.objects.values_list("username", flat=True).distinct().order_by("username")
    page = Paginator(qs, 50).get_page(request.GET.get("page"))
    params = request.GET.copy()
    params.pop("page", None)
    params.pop("verify", None)
    return render(request, "repository/audit_log.html", {
        "page": page, "actions": actions, "users": users, "verify": verify, "params": params.urlencode(),
    })


@require("can_view_audit")
def reports(request):
    year = request.GET.get("year", "")
    base = Document.objects.all()
    if year:
        base = base.filter(Q(document_year__icontains=year) | Q(received_date__year=year if year.isdigit() else 0))
    by_cat = base.values("category__name", "category__code").annotate(
        total=Count("id"),
        active=Count("id", filter=Q(status=Status.ACTIVE)),
        workflow=Count("id", filter=Q(status__in=WORKFLOW_STATES)),
        disposed=Count("id", filter=Q(status=Status.DISPOSED)),
    ).order_by("category__name")
    by_status = base.values("status").annotate(c=Count("id")).order_by("status")
    status_labels = dict(Status.choices)
    by_status = [(status_labels.get(r["status"], r["status"]), r["c"]) for r in by_status]
    by_year = base.exclude(document_year="").values("document_year").annotate(c=Count("id")).order_by("-document_year")[:15]
    by_dept = base.values("department__name").annotate(c=Count("id")).order_by("-c")
    by_user = AuditLog.objects.filter(action__in=[Action.REGISTERED, Action.FILE_UPLOADED, Action.APPROVED]).values(
        "username", "action").annotate(c=Count("id")).order_by("username")
    fixity_bad = DocumentFile.objects.filter(purged=False, fixity_ok=False).select_related("document")
    return render(request, "repository/reports.html", {
        "by_cat": by_cat, "by_status": by_status, "by_year": by_year, "by_dept": by_dept, "by_user": by_user,
        "year": year, "fixity_bad": fixity_bad, "usage": M.disk_usage(),
        "access_count": AuditLog.objects.filter(action__in=[Action.VIEWED, Action.DOWNLOADED]).count(),
        "denied_count": AuditLog.objects.filter(action=Action.ACCESS_DENIED).count(),
    })


# ======================================================================
# Notifications & profile
# ======================================================================
@login_required
def notifications(request):
    qs = request.user.notifications.all()
    if request.method == "POST":
        qs.filter(read=False).update(read=True)
        return redirect("notifications")
    page = Paginator(qs, 30).get_page(request.GET.get("page"))
    return render(request, "repository/notifications.html", {"page": page})


@login_required
def notification_open(request, pk):
    n = get_object_or_404(Notification, pk=pk, user=request.user)
    n.read = True
    n.save(update_fields=["read"])
    return redirect(n.link if n.link.startswith("/") else "dashboard")


@login_required
def profile(request):
    form = F.OwnPasswordForm(request.user, request.POST or None)
    if request.method == "POST" and form.is_valid():
        form.save()
        update_session_auth_hash(request, form.user)
        audit(Action.USER_CHANGE, request, details="Changed own password")
        messages.success(request, "Password changed.")
        return redirect("profile")
    my_docs = Document.objects.filter(custodian=request.user).exclude(status=Status.DISPOSED).count()
    return render(request, "repository/profile.html", {"form": form, "my_docs": my_docs})


# ======================================================================
# Administration
# ======================================================================
@require("is_admin_role")
def users(request):
    return render(request, "repository/users.html", {"users": User.objects.select_related("department").order_by("username")})


@require("is_admin_role")
def user_edit(request, pk=None):
    obj = get_object_or_404(User, pk=pk) if pk else None
    form = F.UserForm(request.POST or None, instance=obj)
    if request.method == "POST" and form.is_valid():
        if obj and obj.pk == request.user.pk and (form.cleaned_data["role"] != Role.ADMIN or not form.cleaned_data["is_active"]):
            messages.error(request, "You cannot remove your own administrator rights or deactivate yourself.")
        else:
            u = form.save()
            audit(Action.USER_CHANGE, request, details=f"{'Updated' if obj else 'Created'} user {u.username} role={u.role} active={u.is_active}")
            messages.success(request, f"User {u.username} saved.")
            return redirect("users")
    return render(request, "repository/simple_form.html", {
        "form": form, "title": f"Edit user {obj.username}" if obj else "New user", "back": "users",
        "help": "Roles: Administrator (everything) · Super Librarian (approve + decide retention, disposal, audit) · "
                "Cataloguer, Technical Staff and Library Staff (register, upload, metadata, submit for approval; "
                "Cataloguer can also request disposal) · "
                "Authorized Staff (search and view approved documents only).",
    })


@require("is_admin_role")
def categories(request):
    cats = Category.objects.annotate(n=Count("document")).order_by("name")
    return render(request, "repository/categories.html", {"categories": cats, "departments": Department.objects.annotate(n=Count("document"))})


@require("is_admin_role")
def category_edit(request, pk=None):
    obj = get_object_or_404(Category, pk=pk) if pk else None
    form = F.CategoryForm(request.POST or None, instance=obj)
    if request.method == "POST" and form.is_valid():
        c = form.save()
        audit(Action.SETTINGS, request, details=f"Category {c.code} saved (retention {c.retention_years} yrs)")
        messages.success(request, "Category saved.")
        return redirect("categories")
    return render(request, "repository/simple_form.html", {
        "form": form, "title": "Edit category" if obj else "New category", "back": "categories",
        "help": "Retention years drive the automatic expiry date of each document (0 = keep permanently).",
    })


@require("is_admin_role")
def department_edit(request, pk=None):
    obj = get_object_or_404(Department, pk=pk) if pk else None
    form = F.DepartmentForm(request.POST or None, instance=obj)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Department saved.")
        return redirect("categories")
    return render(request, "repository/simple_form.html", {"form": form, "title": "Department", "back": "categories"})


@require("is_admin_role")
def site_settings(request):
    s = SiteSettings.load()
    form = F.SiteSettingsForm(request.POST or None, instance=s)
    if request.method == "POST" and form.is_valid():
        form.save()
        audit(Action.SETTINGS, request, details="Library settings updated")
        messages.success(request, "Settings saved.")
        return redirect("site_settings")
    import socket

    try:
        hostname = socket.gethostname()
    except Exception:
        hostname = ""
    from .netinfo import lan_addresses

    port = settings.CONFIG.get("server", "port")
    return render(request, "repository/settings.html", {
        "form": form, "s": s, "port": port, "ips": lan_addresses(), "hostname": hostname,
        "ocr": ocr_available(), "data_dir": settings.DATA_DIR, "usage": M.disk_usage(),
        "backups": sorted(settings.BACKUP_DIR.glob("ldr_backup_*.zip"), reverse=True)[:30],
        "db_engine": settings.DATABASES["default"]["ENGINE"].rsplit(".", 1)[-1],
        "upd": _update_context(),
    })


def _update_context():
    from .services import updates as U

    info = U.latest_info()
    return {
        "url": U.update_url(), "info": info, "available": U.update_available(),
        "pending": U.pending_file().exists(), "last": U.last_result(), "supported": U.self_update_supported(),
        "supervised": U.supervised(),
    }


@require("is_admin_role")
@require_POST
def backup_now(request):
    path = M.make_backup(user=request.user, request=request)
    messages.success(request, f"Backup created: {path.name}")
    return redirect("site_settings")


@require("is_admin_role")
def backup_download(request, name):
    path = settings.BACKUP_DIR / name
    if not name.startswith("ldr_backup_") or not name.endswith(".zip") or "/" in name or "\\" in name or not path.exists():
        raise Http404
    audit(Action.DOWNLOADED, request, details=f"Backup {name}")
    return FileResponse(open(path, "rb"), as_attachment=True, filename=name)


# ======================================================================
# Help
# ======================================================================
@login_required
def help_page(request):
    return render(request, "repository/help.html", {"phases": PHASE_NAMES})


# ======================================================================
# In-app viewer and versioned editing
# ======================================================================
def _open_file_for(request, pk):
    df = get_object_or_404(DocumentFile.objects.select_related("document", "uploaded_by", "previous"), pk=pk)
    doc = df.document
    if not L.can_open(request.user, doc):
        audit(Action.ACCESS_DENIED, request, document=doc, details=df.original_name)
        raise PermissionDenied
    if df.purged or not df.file:
        raise Http404("This file was destroyed during secure disposal.")
    return df, doc


def _read(df):
    with df.file.open("rb") as fh:
        return fh.read()


@login_required
def file_view(request, pk):
    from .services import viewer as V

    df, doc = _open_file_for(request, pk)
    kind = df.view_kind
    ctx = {"f": df, "doc": doc, "kind": kind, "versions": df.version_chain(),
           "can_edit": L.can_edit_file(request.user, df) and df.edit_kind is not None,
           "can_new_version": L.can_edit_file(request.user, df),
           "pending_next": df.next_versions.filter(pending_approval=True).first(),
           "access_copy": DocumentFile.objects.filter(derived_from=df, purged=False).first()}
    error = None
    try:
        if kind == "sheet":
            ctx["sheets"] = V.sheets(_read(df), df.extension)
        elif kind == "word":
            ctx["word_html"] = V.word_html(_read(df))
        elif kind == "text":
            ctx["text"] = V.text(_read(df))
        elif kind == "email":
            ctx["mail"] = V.email_message(_read(df))
        elif kind == "image" and df.extension in ("tif", "tiff", "bmp"):
            ctx["png_pages"] = range(V.image_page_count(_read(df)))
    except Exception as exc:  # corrupt or unsupported file content
        error = f"This file could not be displayed ({exc.__class__.__name__}). Please download it instead."
    ctx["error"] = error
    audit(Action.VIEWED, request, document=doc, details=f"{df.original_name} v{df.version} (in-app viewer)")
    return render(request, "repository/file_view.html", ctx)


@login_required
def file_png(request, pk, page=0):
    from .services import viewer as V

    df, _doc = _open_file_for(request, pk)
    resp = HttpResponse(V.image_as_png(_read(df), page), content_type="image/png")
    resp["Cache-Control"] = "no-store"
    return resp


@login_required
def file_edit(request, pk):
    import json

    from .services import editor as E
    from .services import viewer as V

    df, doc = _open_file_for(request, pk)
    if not L.can_edit_file(request.user, df) or df.edit_kind is None:
        raise PermissionDenied
    kind = df.edit_kind
    if request.method == "POST":
        note = request.POST.get("change_note", "")
        try:
            data = _read(df)
            if kind == "sheet":
                new = E.apply_sheet_edits(data, df.extension, json.loads(request.POST.get("edits") or "{}"))
            elif kind == "word":
                new = E.apply_word_edits(data, json.loads(request.POST.get("edits") or "{}"), request.POST.get("appended", ""))
            else:
                new = E.apply_text_edit(request.POST.get("content", ""))
            nv = L.add_version(df, new, df.original_name, note, request.user, request)
        except (ValidationError, ValueError) as e:
            _errors(request, e if isinstance(e, ValidationError) else ValidationError(str(e)))
            return redirect("file_edit", pk)
        if nv.pending_approval:
            messages.success(request, f"Saved as version {nv.version}. It will become the official version after the Super Librarian approves it.")
        else:
            messages.success(request, f"Saved as version {nv.version}. Version {df.version} is kept in the history.")
        return redirect("file_view", nv.pk)
    ctx = {"f": df, "doc": doc, "kind": kind, "official": doc.is_official}
    data = _read(df)
    if kind == "sheet":
        sheets = V.sheets(data, df.extension, for_edit=True)
        for sh in sheets:  # room to add rows/columns
            extra_cols = 3
            sh["ncols"] = max(sh["ncols"], 1) + extra_cols
            sh["cols"] = [V.col_letter(i + 1) for i in range(sh["ncols"])]
            sh["rows"] = [r + [""] * (sh["ncols"] - len(r)) for r in sh["rows"]] + [[""] * sh["ncols"] for _ in range(15)]
        ctx["sheets"] = sheets
    elif kind == "word":
        ctx["paragraphs"] = E.word_paragraphs(data)
    else:
        ctx["content"] = V.text(data)
    return render(request, "repository/file_edit.html", ctx)


@login_required
@require_POST
def file_new_version(request, pk):
    df, doc = _open_file_for(request, pk)
    up = request.FILES.get("file")
    if not up:
        messages.error(request, "Choose the edited file to upload.")
        return redirect("file_view", pk)
    try:
        nv = L.add_version(df, up.read(), up.name, request.POST.get("change_note", ""), request.user, request)
    except ValidationError as e:
        _errors(request, e)
        return redirect("file_view", pk)
    messages.success(request, f"Uploaded as version {nv.version}" + (" - awaiting approval." if nv.pending_approval else "."))
    return redirect("file_view", nv.pk)


@require("can_approve")
@require_POST
def version_decide(request, pk):
    nv = get_object_or_404(DocumentFile, pk=pk, pending_approval=True)
    doc = nv.document
    try:
        L.decide_version(nv, request.user, request.POST.get("decision") == "approve", request.POST.get("remarks", ""), request)
        messages.success(request, "Version approved - it is now the official version." if request.POST.get("decision") == "approve"
                         else "Version rejected and removed.")
    except ValidationError as e:
        _errors(request, e)
    nxt = request.POST.get("next", "")
    return redirect(nxt) if nxt.startswith("/") else redirect("document_detail", doc.pk)


# ======================================================================
# Software updates (administrator)
# ======================================================================
@require("is_admin_role")
@require_POST
def update_check(request):
    from .services import updates as U

    try:
        info = U.check_for_update(request.user, request)
        if info["newer"]:
            messages.success(request, f"Version {info['version']} is available.")
        else:
            messages.info(request, f"LDR is up to date (version {settings.LDR_VERSION}).")
    except ValidationError as e:
        _errors(request, e)
    return redirect(reverse_settings_updates())


def reverse_settings_updates():
    from django.urls import reverse

    return reverse("site_settings") + "#updates"


def _after_stage(request, manifest):
    from .services import updates as U

    if U.request_restart():
        return render(request, "repository/updating.html", {"target": manifest["version"]})
    messages.warning(request, f"Version {manifest['version']} is ready. Restart LDR to finish installing "
                              "(ldr_service.bat → Restart, or close and reopen the LDR window).")
    return redirect(reverse_settings_updates())


@require("is_admin_role")
@require_POST
def update_install(request):
    from .services import updates as U

    try:
        manifest = U.download_and_stage(request.user, request)
    except ValidationError as e:
        _errors(request, e)
        return redirect(reverse_settings_updates())
    return _after_stage(request, manifest)


@require("is_admin_role")
@require_POST
def update_upload(request):
    from .services import updates as U

    up = request.FILES.get("release")
    if not up or not up.name.lower().endswith(".zip"):
        messages.error(request, "Choose the LDR release .zip file.")
        return redirect(reverse_settings_updates())
    target = U.updates_dir() / "downloads"
    target.mkdir(exist_ok=True)
    path = target / ("upload_" + os.path.basename(up.name))
    with open(path, "wb") as fh:
        for chunk in up.chunks():
            fh.write(chunk)
    try:
        manifest = U.stage_update(path, request.user, request)
    except (ValidationError, zipfile.BadZipFile) as e:
        _errors(request, e if isinstance(e, ValidationError) else ValidationError("Not a valid zip file."))
        return redirect(reverse_settings_updates())
    return _after_stage(request, manifest)


@require("is_admin_role")
@require_POST
def update_cancel(request):
    from .services import updates as U

    U.cancel_pending()
    messages.info(request, "Pending update cancelled.")
    return redirect(reverse_settings_updates())


@login_required
def update_status(request):
    from django.http import JsonResponse

    from .services import updates as U

    return JsonResponse({"version": settings.LDR_VERSION, "pending": U.pending_file().exists(),
                         "last_result": U.last_result()})
