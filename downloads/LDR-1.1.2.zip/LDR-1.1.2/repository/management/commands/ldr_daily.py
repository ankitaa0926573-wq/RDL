from django.core.management.base import BaseCommand

from repository.services.maintenance import daily_jobs


class Command(BaseCommand):
    help = "Run retention monitoring, integrity (fixity) check and backup."

    def add_arguments(self, parser):
        parser.add_argument("--force", action="store_true", help="Run even if already run today")

    def handle(self, *args, **opts):
        self.stdout.write(str(daily_jobs(force=opts["force"])))
