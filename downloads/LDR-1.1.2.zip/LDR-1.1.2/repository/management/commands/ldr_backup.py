from django.core.management.base import BaseCommand

from repository.services.maintenance import make_backup


class Command(BaseCommand):
    help = "Create a full backup (database + files) in data/backups."

    def handle(self, *args, **opts):
        self.stdout.write(self.style.SUCCESS(f"Backup written to {make_backup()}"))
