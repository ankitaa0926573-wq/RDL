import shutil
import zipfile
from pathlib import Path

from django.conf import settings
from django.core.management.base import BaseCommand, CommandError


class Command(BaseCommand):
    help = "Restore a backup zip created by LDR (stop the server first!). Current data is moved to data/before_restore_*."

    def add_arguments(self, parser):
        parser.add_argument("zipfile")

    def handle(self, *args, **opts):
        src = Path(opts["zipfile"])
        if not src.exists():
            raise CommandError(f"{src} not found")
        if not settings.DATABASES["default"]["ENGINE"].endswith("sqlite3"):
            raise CommandError("Automatic restore supports the default SQLite database only. Use loaddata for PostgreSQL.")
        from django.db import connections

        connections.close_all()
        from django.utils import timezone

        stamp = timezone.now().strftime("%Y%m%d_%H%M%S")
        keep = settings.DATA_DIR / f"before_restore_{stamp}"
        keep.mkdir()
        db = Path(settings.DATABASES["default"]["NAME"])
        for p in (db, Path(str(db) + "-wal"), Path(str(db) + "-shm")):
            if p.exists():
                shutil.move(str(p), keep / p.name)
        if settings.MEDIA_ROOT.exists():
            shutil.move(str(settings.MEDIA_ROOT), keep / "repository_files")
        settings.MEDIA_ROOT.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(src) as zf:
            for info in zf.infolist():
                name = info.filename
                if ".." in Path(name).parts or name.startswith("/"):
                    continue
                if name == "database/ldr.sqlite3":
                    with zf.open(info) as fsrc, open(db, "wb") as fdst:
                        shutil.copyfileobj(fsrc, fdst)
                elif name.startswith("repository_files/") and not name.endswith("/"):
                    target = settings.MEDIA_ROOT / Path(name).relative_to("repository_files")
                    target.parent.mkdir(parents=True, exist_ok=True)
                    with zf.open(info) as fsrc, open(target, "wb") as fdst:
                        shutil.copyfileobj(fsrc, fdst)
        self.stdout.write(self.style.SUCCESS(f"Restored from {src}. Previous data kept in {keep}"))
