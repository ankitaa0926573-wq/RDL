from django.conf import settings

from .models import AccessRequest, DisposalRecord, Document, SiteSettings, Status


def ldr_context(request):
    ctx = {"ldr_version": settings.LDR_VERSION}
    try:
        ctx["site"] = SiteSettings.load()
    except Exception:
        return ctx
    user = getattr(request, "user", None)
    if user is not None and user.is_authenticated:
        ctx["unread_notifications"] = user.notifications.filter(read=False).count()
        if user.is_admin_role and ctx["site"].update_latest_version:
            from .services.updates import is_newer

            if is_newer(ctx["site"].update_latest_version):
                ctx["update_banner"] = ctx["site"].update_latest_version
        if user.can_approve:
            from .models import DocumentFile

            ctx["pending_approvals"] = Document.objects.filter(status=Status.PENDING_APPROVAL).count() + \
                DocumentFile.objects.filter(pending_approval=True, role="MASTER").count()
            ctx["pending_access"] = AccessRequest.objects.filter(state=AccessRequest.State.PENDING).count()
            ctx["pending_disposals"] = DisposalRecord.objects.filter(state=DisposalRecord.State.REQUESTED).count()
            ctx["review_due"] = Document.objects.filter(status=Status.UNDER_REVIEW).count()
    return ctx
