from django.contrib import admin
from django.contrib.auth.admin import UserAdmin

from . import models as m


@admin.register(m.User)
class LDRUserAdmin(UserAdmin):
    fieldsets = UserAdmin.fieldsets + (("Library", {"fields": ("role", "department", "designation", "phone")}),)
    list_display = ("username", "first_name", "last_name", "role", "department", "is_active")


@admin.register(m.Document)
class DocumentAdmin(admin.ModelAdmin):
    list_display = ("doc_id", "title", "category", "status", "expiry_date")
    list_filter = ("status", "category", "confidentiality")
    search_fields = ("doc_id", "title")
    readonly_fields = ("doc_id", "extracted_text")


@admin.register(m.AuditLog)
class AuditLogAdmin(admin.ModelAdmin):
    list_display = ("timestamp", "username", "action", "doc_ref", "ip_address")
    list_filter = ("action",)

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False

    def has_add_permission(self, request):
        return False


for model in (m.Category, m.Department, m.DocumentFile, m.AccessRequest, m.RetentionReview, m.DisposalRecord, m.SiteSettings):
    admin.site.register(model)
