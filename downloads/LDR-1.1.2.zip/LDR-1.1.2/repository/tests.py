import io
import shutil
import tempfile
from datetime import date, timedelta

from django.conf import settings
from django.core.exceptions import ValidationError
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import TestCase, override_settings
from django.urls import reverse
from django.utils import timezone

from .defaults import load_defaults
from .models import (
    AccessRequest,
    AuditLog,
    Category,
    Confidentiality,
    DisposalRecord,
    Document,
    DocumentFile,
    Role,
    SiteSettings,
    Status,
    User,
)
from .services import lifecycle as L
from .services import maintenance as M
from .services.audit import verify_chain

TMP = tempfile.mkdtemp()


def make_pdf(text="Invoice No 4521 from Allied Book Agency for Rs 45,000"):
    """Tiny valid PDF with real text."""
    from pypdf import PdfWriter
    from pypdf.generic import DecodedStreamObject, DictionaryObject, NameObject

    w = PdfWriter()
    page = w.add_blank_page(612, 792)
    font = DictionaryObject({
        NameObject("/Type"): NameObject("/Font"), NameObject("/Subtype"): NameObject("/Type1"),
        NameObject("/BaseFont"): NameObject("/Helvetica"),
    })
    page[NameObject("/Resources")] = DictionaryObject({
        NameObject("/Font"): DictionaryObject({NameObject("/F1"): w._add_object(font)})
    })
    stream = DecodedStreamObject()
    stream.set_data(f"BT /F1 12 Tf 72 720 Td ({text}) Tj ET".encode())
    page[NameObject("/Contents")] = w._add_object(stream)
    buf = io.BytesIO()
    w.write(buf)
    return buf.getvalue()


@override_settings(MEDIA_ROOT=TMP, BACKUP_DIR=settings.BACKUP_DIR.__class__(TMP) / "backups")
class WorkflowTests(TestCase):
    @classmethod
    def tearDownClass(cls):
        super().tearDownClass()
        shutil.rmtree(TMP, ignore_errors=True)

    def setUp(self):
        (settings.BACKUP_DIR.__class__(TMP) / "backups").mkdir(parents=True, exist_ok=True)
        load_defaults()
        s = SiteSettings.load()
        s.setup_completed = True
        s.save()
        self.admin = User.objects.create_user("admin", password="x", role=Role.ADMIN, is_superuser=True, is_staff=True)
        self.sup = User.objects.create_user("super", password="x", role=Role.SUPER_LIBRARIAN, first_name="Super")
        self.sup2 = User.objects.create_user("super2", password="x", role=Role.SUPER_LIBRARIAN)
        self.cat_user = User.objects.create_user("cat", password="x", role=Role.CATALOGUER)
        self.tech = User.objects.create_user("tech", password="x", role=Role.TECHNICAL)
        self.viewer = User.objects.create_user("viewer", password="x", role=Role.AUTHORIZED)
        self.inv = Category.objects.get(code="INV")
        self.agr = Category.objects.get(code="AGR")

    def _register(self, client, title="Invoice from Allied Book Agency", category=None):
        category = category or self.inv
        r = client.post(reverse("document_new"), {
            "title": title, "category": category.pk, "source_type": "PHYSICAL",
            "received_from": "Allied Book Agency", "received_date": date.today().isoformat(),
            "reference_number": "INV-4521", "physical_location": "Cabinet A / File 3",
            "confidentiality": "",
        })
        self.assertEqual(r.status_code, 302, getattr(r, "context", None) and r.context["form"].errors)
        return Document.objects.latest("id")

    def test_full_seven_phase_lifecycle(self):
        c = self.client
        c.force_login(self.tech)
        # Phase 1
        doc = self._register(c)
        self.assertTrue(doc.doc_id.startswith(f"LDR-{timezone.localdate().year}-"))
        self.assertEqual(doc.status, Status.RECEIVED)
        self.assertEqual(doc.custodian, self.tech)
        self.assertIsNotNone(doc.expiry_date)  # 8-year retention from category
        # Phase 2
        pdf = SimpleUploadedFile("invoice.pdf", make_pdf(), content_type="application/pdf")
        r = c.post(reverse("document_upload", args=[doc.pk]), {"files": [pdf]})
        self.assertEqual(r.status_code, 302)
        doc.refresh_from_db()
        self.assertEqual(doc.files.count(), 1)
        self.assertIn("Allied", doc.extracted_text)
        self.assertEqual(len(doc.files.first().sha256), 64)
        c.post(reverse("document_digitized", args=[doc.pk]))
        doc.refresh_from_db()
        self.assertEqual(doc.status, Status.DIGITIZED)
        # view-only staff cannot do metadata; working staff can
        c.force_login(self.viewer)
        self.assertEqual(c.get(reverse("document_metadata", args=[doc.pk])).status_code, 403)
        # Phase 3
        c.force_login(self.cat_user)
        r = c.post(reverse("document_metadata", args=[doc.pk]), {
            "title": doc.title, "category": self.inv.pk, "description": "Book purchase invoice",
            "keywords": "books, purchase", "document_year": "2025-26", "language": "English",
            "custodian": self.tech.pk, "confidentiality": "GENERAL", "received_from": "Allied Book Agency",
            "amount": "45000", "submit": "1",
        })
        self.assertEqual(r.status_code, 302)
        doc.refresh_from_db()
        self.assertEqual(doc.status, Status.PENDING_APPROVAL)
        # super librarian got a notification
        self.assertTrue(self.sup.notifications.filter(message__contains=doc.doc_id).exists())
        # Phase 4: cataloguer cannot approve
        r = c.post(reverse("document_decide", args=[doc.pk]), {"decision": "approve"})
        self.assertEqual(r.status_code, 403)
        c.force_login(self.sup)
        c.post(reverse("document_decide", args=[doc.pk]), {"decision": "return", "remarks": "Add vendor GST no."})
        doc.refresh_from_db()
        self.assertEqual(doc.status, Status.RETURNED)
        c.force_login(self.cat_user)
        c.post(reverse("document_submit", args=[doc.pk]))
        c.force_login(self.sup)
        c.post(reverse("document_decide", args=[doc.pk]), {"decision": "approve", "remarks": "Verified"})
        doc.refresh_from_db()
        self.assertEqual(doc.status, Status.ACTIVE)
        self.assertEqual(doc.approved_by, self.sup)
        # metadata locked
        c.force_login(self.cat_user)
        r = c.get(reverse("document_metadata", args=[doc.pk]))
        self.assertEqual(r.status_code, 302)
        # Phase 5: viewer can open general doc & download is logged
        c.force_login(self.viewer)
        self.assertEqual(c.get(doc.get_absolute_url()).status_code, 200)
        f = doc.files.first()
        r = c.get(reverse("file_download", args=[f.pk]))
        self.assertEqual(r.status_code, 200)
        self.assertTrue(AuditLog.objects.filter(action="DOWNLOADED", document=doc, username="viewer").exists())
        # Search finds text inside the PDF
        r = c.get(reverse("document_list"), {"q": "Allied"})
        self.assertContains(r, doc.doc_id)
        # Phase 6: expire it, daily job flags review
        Document.objects.filter(pk=doc.pk).update(expiry_date=timezone.localdate() - timedelta(days=1))
        M.retention_check()
        doc.refresh_from_db()
        self.assertEqual(doc.status, Status.UNDER_REVIEW)
        c.force_login(self.sup)
        c.post(reverse("retention_review", args=[doc.pk]), {"decision": "DISPOSE", "remarks": "Audit complete"})
        # Phase 7
        c.post(reverse("disposal_request", args=[doc.pk]), {"method": "DELETE", "reason": "Retention period over; audited"})
        doc.refresh_from_db()
        self.assertEqual(doc.status, Status.DISPOSAL_REQUESTED)
        rec = DisposalRecord.objects.get(document=doc)
        # same person cannot approve (four-eyes)
        c.post(reverse("disposal_decide", args=[rec.pk]), {"decision": "approve", "confirm": doc.doc_id})
        rec.refresh_from_db()
        self.assertEqual(rec.state, DisposalRecord.State.REQUESTED)
        c.force_login(self.sup2)
        path = f.file.path
        r = c.post(reverse("disposal_decide", args=[rec.pk]), {"decision": "approve", "confirm": doc.doc_id})
        rec.refresh_from_db()
        doc.refresh_from_db()
        self.assertEqual(rec.state, DisposalRecord.State.APPROVED)
        self.assertEqual(doc.status, Status.DISPOSED)
        self.assertTrue(rec.certificate_number.startswith("DSP-"))
        import os

        self.assertFalse(os.path.exists(path))
        self.assertEqual(rec.manifest()[0]["sha256"], f.sha256)
        self.assertEqual(c.get(reverse("disposal_certificate", args=[rec.pk])).status_code, 200)
        # Audit chain intact
        ok, n, _ = verify_chain()
        self.assertTrue(ok)
        self.assertGreater(n, 10)

    def test_confidential_access_request(self):
        c = self.client
        c.force_login(self.cat_user)
        doc = self._register(c, "AMC agreement with vendor", self.agr)
        self.assertEqual(doc.confidentiality, Confidentiality.CONFIDENTIAL)
        L.add_file(doc, SimpleUploadedFile("agr.pdf", make_pdf("Confidential agreement")), self.cat_user)
        doc.description, doc.document_year = "AMC", "2025"
        doc.save()
        L.submit_for_approval(doc, self.cat_user)
        L.approve(doc, self.sup)
        f = doc.files.first()
        c.force_login(self.tech)
        r = c.get(doc.get_absolute_url())
        self.assertContains(r, "Request access")
        self.assertEqual(c.get(reverse("file_download", args=[f.pk])).status_code, 403)
        self.assertTrue(AuditLog.objects.filter(action="ACCESS_DENIED", username="tech").exists())
        # confidential text not searchable for non-super users
        r = c.get(reverse("document_list"), {"q": "Confidential agreement"})
        self.assertNotContains(r, doc.doc_id)
        c.post(reverse("access_request", args=[doc.pk]), {"purpose": "NAAC criterion 4"})
        ar = AccessRequest.objects.get()
        c.force_login(self.sup)
        c.post(reverse("access_decide", args=[ar.pk]), {"decision": "approve"})
        c.force_login(self.tech)
        self.assertEqual(c.get(reverse("file_download", args=[f.pk])).status_code, 200)

    def test_tamper_detection(self):
        self.client.force_login(self.tech)
        self._register(self.client)
        ok, _, _ = verify_chain()
        self.assertTrue(ok)
        AuditLog.objects.filter(pk=AuditLog.objects.order_by("id").first().pk).update(details="edited")
        ok, _, bad = verify_chain()
        self.assertFalse(ok)

    def test_fixity_and_backup(self):
        doc = L.register_document(Document(title="Minutes", category=Category.objects.get(code="MIN")), self.cat_user)
        df, _ = L.add_file(doc, SimpleUploadedFile("m.txt", b"minutes of meeting"), self.cat_user)
        self.assertTrue(df.verify_fixity())
        with open(df.file.path, "ab") as fh:
            fh.write(b"tampered")
        self.assertFalse(df.verify_fixity())
        z = M.make_backup()
        import zipfile

        names = zipfile.ZipFile(z).namelist()
        self.assertIn("database/ldr.sqlite3", names)
        self.assertTrue(any(n.startswith("repository_files/") for n in names))

    def test_pages_render_for_each_role(self):
        doc = L.register_document(Document(title="Policy", category=Category.objects.get(code="POL")), self.cat_user)
        for u in (self.admin, self.sup, self.cat_user, self.tech, self.viewer):
            self.client.force_login(u)
            for name in ("dashboard", "document_list", "access_requests", "notifications", "profile", "help"):
                self.assertEqual(self.client.get(reverse(name)).status_code, 200, (u.username, name))
        self.client.force_login(self.admin)
        for name in ("approvals", "retention", "disposals", "audit_log", "reports", "users", "categories",
                     "site_settings", "user_new", "category_new"):
            self.assertEqual(self.client.get(reverse(name)).status_code, 200, name)
        self.assertEqual(self.client.get(doc.get_absolute_url()).status_code, 200)
        self.client.force_login(self.viewer)
        self.assertEqual(self.client.get(reverse("audit_log")).status_code, 403)
        # viewer cannot see work-in-progress documents
        self.assertEqual(self.client.get(doc.get_absolute_url()).status_code, 403)


class SetupTests(TestCase):
    def test_setup_wizard(self):
        from .middleware import SetupRequiredMiddleware

        SetupRequiredMiddleware._done = False
        r = self.client.get("/")
        self.assertRedirects(r, reverse("setup"))
        r = self.client.post(reverse("setup"), {
            "library_name": "Central Library", "institution_name": "Test University", "id_prefix": "CL",
            "admin_username": "librarian", "admin_full_name": "Head Librarian", "password1": "Strong#Pass2026",
            "password2": "Strong#Pass2026", "load_defaults": "on",
        })
        self.assertRedirects(r, reverse("dashboard"))
        self.assertTrue(User.objects.get(username="librarian").is_admin_role)
        self.assertGreater(Category.objects.count(), 10)


def make_xlsx():
    import openpyxl

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Stock"
    ws.append(["Item", "Qty", "Rate"])
    ws.append(["Books", 45, 1013.33])
    ws.append(["Journals", 12, 2500])
    ws["D1"] = "Total"
    ws["D2"] = "=B2*C2"
    wb.create_sheet("Notes")["A1"] = "Second sheet"
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def make_docx():
    import docx

    d = docx.Document()
    d.add_heading("Library Committee Minutes", 1)
    d.add_paragraph("Meeting held on 12 August 2025.")
    t = d.add_table(rows=1, cols=2)
    t.rows[0].cells[0].text = "Budget"
    t.rows[0].cells[1].text = "Rs 5,00,000"
    buf = io.BytesIO()
    d.save(buf)
    return buf.getvalue()


@override_settings(MEDIA_ROOT=TMP)
class ViewerVersioningTests(TestCase):
    def setUp(self):
        load_defaults()
        s = SiteSettings.load()
        s.setup_completed = True
        s.save()
        self.sup = User.objects.create_user("super", password="x", role=Role.SUPER_LIBRARIAN)
        self.cat = User.objects.create_user("cat", password="x", role=Role.CATALOGUER)
        self.doc = L.register_document(Document(title="Stock register", category=Category.objects.get(code="STK"),
                                                description="d", document_year="2025"), self.cat)
        self.xl, _ = L.add_file(self.doc, SimpleUploadedFile("stock.xlsx", make_xlsx()), self.cat)
        self.wd, _ = L.add_file(self.doc, SimpleUploadedFile("minutes.docx", make_docx()), self.cat)
        self.csvf, _ = L.add_file(self.doc, SimpleUploadedFile("list.csv", b"name,qty\nA,1\nB,2\n"), self.cat)

    def test_viewers_render(self):
        self.client.force_login(self.cat)
        r = self.client.get(reverse("file_view", args=[self.xl.pk]))
        self.assertContains(r, "Journals")
        self.assertContains(r, "Notes")  # second sheet tab
        self.assertContains(r, "=B2*C2")  # formula shown when no cached value
        r = self.client.get(reverse("file_view", args=[self.wd.pk]))
        self.assertContains(r, "Library Committee Minutes")
        self.assertContains(r, "5,00,000")
        r = self.client.get(reverse("file_view", args=[self.csvf.pk]))
        self.assertContains(r, "<td title=\"B\">B</td>", html=False)
        self.assertEqual(self.client.get(reverse("file_edit", args=[self.xl.pk])).status_code, 200)
        self.assertEqual(self.client.get(reverse("file_edit", args=[self.wd.pk])).status_code, 200)

    def test_edit_in_workflow_creates_current_version(self):
        import json

        import openpyxl

        self.client.force_login(self.cat)
        r = self.client.post(reverse("file_edit", args=[self.xl.pk]), {
            "change_note": "Corrected quantity", "edits": json.dumps({"Stock": {"2,2": "50", "5,1": "Newspapers"}})})
        self.assertEqual(r.status_code, 302)
        new = DocumentFile.objects.get(previous=self.xl)
        self.assertTrue(new.is_current)
        self.xl.refresh_from_db()
        self.assertFalse(self.xl.is_current)
        ws = openpyxl.load_workbook(new.file.path)["Stock"]
        self.assertEqual(ws["B2"].value, 50)
        self.assertEqual(ws["A5"].value, "Newspapers")
        self.assertEqual(ws["D2"].value, "=B2*C2")
        # word edit
        r = self.client.post(reverse("file_edit", args=[self.wd.pk]), {
            "change_note": "Fixed date", "edits": json.dumps({"p1": "Meeting held on 14 August 2025."}),
            "appended": "Action: renew subscriptions"})
        neww = DocumentFile.objects.get(previous=self.wd)
        import docx

        texts = [p.text for p in docx.Document(neww.file.path).paragraphs]
        self.assertIn("Meeting held on 14 August 2025.", texts)
        self.assertIn("Action: renew subscriptions", texts)
        # change note is mandatory
        r = self.client.post(reverse("file_edit", args=[self.csvf.pk]), {"change_note": "", "edits": json.dumps({"Sheet1": {"2,2": "9"}})})
        self.assertFalse(DocumentFile.objects.filter(previous=self.csvf).exists())

    def test_edit_of_approved_record_needs_approval(self):
        import json

        L.submit_for_approval(self.doc, self.cat)
        L.approve(self.doc, self.sup)
        self.client.force_login(self.cat)
        self.client.post(reverse("file_edit", args=[self.csvf.pk]), {
            "change_note": "Added row", "edits": json.dumps({"Sheet1": {"4,1": "C", "4,2": "3"}})})
        new = DocumentFile.objects.get(previous=self.csvf)
        self.assertTrue(new.pending_approval)
        self.assertFalse(new.is_current)
        self.csvf.refresh_from_db()
        self.assertTrue(self.csvf.is_current)  # approved version stays official
        # second edit blocked while pending
        with self.assertRaises(ValidationError):
            L.add_version(self.csvf, b"x,y\n", "list.csv", "again", self.cat)
        # super librarian approves
        self.client.force_login(self.sup)
        self.client.post(reverse("version_decide", args=[new.pk]), {"decision": "approve"})
        new.refresh_from_db()
        self.csvf.refresh_from_db()
        self.assertTrue(new.is_current)
        self.assertFalse(new.pending_approval)
        self.assertFalse(self.csvf.is_current)
        self.assertTrue(AuditLog.objects.filter(action="VERSION_APPROVED").exists())
        # upload-new-version path + reject
        self.client.force_login(self.cat)
        self.client.post(reverse("file_new_version", args=[self.wd.pk]),
                         {"change_note": "Signed copy", "file": SimpleUploadedFile("minutes_signed.docx", make_docx() + b"")})
        # identical content is refused
        self.assertFalse(DocumentFile.objects.filter(previous=self.wd).exists())
        self.client.post(reverse("file_new_version", args=[self.wd.pk]),
                         {"change_note": "Signed copy", "file": SimpleUploadedFile("minutes_signed.pdf", make_pdf("signed"))})
        nv = DocumentFile.objects.get(previous=self.wd)
        self.client.force_login(self.sup)
        self.client.post(reverse("version_decide", args=[nv.pk]), {"decision": "reject"})
        self.assertFalse(DocumentFile.objects.filter(pk=nv.pk).exists())
        self.wd.refresh_from_db()
        self.assertTrue(self.wd.is_current)


class UpdateTests(TestCase):
    """Release signing/verification used by the in-app updater."""

    def _release(self, version, key, tamper=False):
        import base64
        import hashlib
        import json
        import zipfile

        tmp = tempfile.mkdtemp()
        files = {"ldr_project/settings.py": b"LDR_VERSION = 'x'\n", "README.md": b"hello\n"}
        manifest = {"product": "LDR", "version": version, "files": {k: hashlib.sha256(v).hexdigest() for k, v in files.items()}}
        mb = json.dumps(manifest, sort_keys=True).encode()
        sig = base64.b64encode(key.sign(mb)).decode()
        zp = f"{tmp}/LDR-{version}.zip"
        with zipfile.ZipFile(zp, "w") as zf:
            for k, v in files.items():
                zf.writestr(f"LDR-{version}/{k}", v + (b"evil" if tamper and k == "README.md" else b""))
            zf.writestr(f"LDR-{version}/RELEASE_MANIFEST.json", mb)
            zf.writestr(f"LDR-{version}/RELEASE_SIGNATURE.txt", sig)
        return zp

    def setUp(self):
        from cryptography.hazmat.primitives import serialization as S
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

        self.key = Ed25519PrivateKey.generate()
        self.pub = self.key.public_key().public_bytes(S.Encoding.PEM, S.PublicFormat.SubjectPublicKeyInfo).decode()
        self.admin = User.objects.create_user("admin", password="x", role=Role.ADMIN)
        self.tmpdata = tempfile.mkdtemp()

    def _stage(self, zp):
        from pathlib import Path
        from unittest import mock

        from . import update_source
        from .services import updates as U

        with mock.patch.object(update_source, "PUBLIC_KEY_PEM", self.pub), \
                override_settings(DATA_DIR=Path(self.tmpdata), BACKUP_DIR=Path(self.tmpdata) / "b", MEDIA_ROOT=TMP):
            (Path(self.tmpdata) / "b").mkdir(exist_ok=True)
            return U.stage_update(Path(zp), self.admin)

    def test_valid_release_is_staged(self):
        import json
        from pathlib import Path

        m = self._stage(self._release("99.0.0", self.key))
        self.assertEqual(m["version"], "99.0.0")
        pending = json.loads((Path(self.tmpdata) / "updates" / "pending.json").read_text())
        self.assertEqual(pending["version"], "99.0.0")
        self.assertTrue(Path(pending["backup"]).exists())
        self.assertTrue(AuditLog.objects.filter(action="UPDATE_STARTED").exists())

    def test_tampered_release_rejected(self):
        with self.assertRaisesMessage(ValidationError, "damaged or modified"):
            self._stage(self._release("99.0.0", self.key, tamper=True))

    def test_wrong_signer_rejected(self):
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

        with self.assertRaisesMessage(ValidationError, "signature"):
            self._stage(self._release("99.0.0", Ed25519PrivateKey.generate()))

    def test_older_version_rejected(self):
        with self.assertRaisesMessage(ValidationError, "not newer"):
            self._stage(self._release("0.0.1", self.key))

    def test_version_compare(self):
        from .services.updates import is_newer

        self.assertTrue(is_newer("1.10.0", "1.9.9"))
        self.assertFalse(is_newer("1.2.0", "1.2.0"))


class StaffWorkflowRetentionTests(TestCase):
    """Library Staff complete phases 1-3; the approver decides retention at Phase 4."""

    def setUp(self):
        load_defaults()
        s = SiteSettings.load()
        s.setup_completed = True
        s.save()
        self.staff = User.objects.create_user("staff", password="x", role=Role.LIBRARY_STAFF)
        self.admin = User.objects.create_user("admin", password="x", role=Role.ADMIN)

    def _ready_doc(self):
        c = self.client
        c.force_login(self.staff)
        c.post(reverse("document_new"), {"title": "Annual report 2026", "category": Category.objects.get(code="ANR").pk,
                                          "source_type": "DIGITAL", "received_date": date.today().isoformat(),
                                          "received_from": "Registrar"})
        doc = Document.objects.latest("id")
        with override_settings(MEDIA_ROOT=TMP):
            c.post(reverse("document_upload", args=[doc.pk]), {"files": [SimpleUploadedFile("r.txt", b"annual report")]})
            r = c.post(reverse("document_digitized", args=[doc.pk]))
            self.assertEqual(r.status_code, 302)
            page = c.get(reverse("document_metadata", args=[doc.pk]))
            self.assertEqual(page.status_code, 200)
            self.assertNotContains(page, 'name="retention_years"')  # retention is the approver's decision
            c.post(reverse("document_metadata", args=[doc.pk]), {
                "title": doc.title, "category": doc.category_id, "description": "Annual report", "document_year": "2025-26",
                "language": "English", "custodian": self.staff.pk, "confidentiality": "GENERAL", "submit": "1"})
        doc.refresh_from_db()
        self.assertEqual(doc.status, Status.PENDING_APPROVAL)
        self.assertTrue(self.admin.notifications.exists())
        return doc

    def test_staff_completes_phases_and_admin_sets_years(self):
        doc = self._ready_doc()
        self.client.force_login(self.admin)
        with override_settings(MEDIA_ROOT=TMP):
            self.client.post(reverse("document_decide", args=[doc.pk]), {"decision": "approve", "retention": "10"})
        doc.refresh_from_db()
        self.assertEqual(doc.status, Status.ACTIVE)
        self.assertFalse(doc.permanent)
        self.assertEqual(doc.retention_years, 10)
        self.assertEqual(doc.expiry_date.year, doc.received_date.year + 10)
        self.assertTrue(AuditLog.objects.filter(action="APPROVED", details__contains="retain 10 years").exists())

    def test_admin_sets_permanent_and_date(self):
        doc = self._ready_doc()
        self.client.force_login(self.admin)
        with override_settings(MEDIA_ROOT=TMP):
            self.client.post(reverse("document_decide", args=[doc.pk]), {"decision": "approve", "retention": "permanent"})
        doc.refresh_from_db()
        self.assertTrue(doc.permanent)
        self.assertIsNone(doc.expiry_date)
        doc2 = self._ready_doc()
        self.client.force_login(self.admin)
        until = date.today().replace(year=date.today().year + 3)
        with override_settings(MEDIA_ROOT=TMP):
            self.client.post(reverse("document_decide", args=[doc2.pk]),
                             {"decision": "approve", "retention": "date", "retention_until": until.isoformat()})
        doc2.refresh_from_db()
        self.assertEqual(doc2.expiry_date, until)

    def test_staff_cannot_approve_or_request_disposal(self):
        doc = self._ready_doc()
        self.assertEqual(self.client.post(reverse("document_decide", args=[doc.pk]), {"decision": "approve"}).status_code, 403)
        self.assertFalse(self.staff.can_request_disposal)
