"""Starter categories for Indian academic libraries (editable after setup)."""

DEFAULT_CATEGORIES = [
    # name, code, retention years (0 = permanent), confidentiality, description
    ("Invoices & Bills", "INV", 8, "GENERAL", "Vendor invoices, bills, payment vouchers"),
    ("Purchase Orders & Quotations", "PO", 8, "GENERAL", "Purchase orders, quotations, comparative statements, tender papers"),
    ("Vendor Agreements & Contracts", "AGR", 10, "CONFIDENTIAL", "Agreements with vendors, AMC contracts, MoUs"),
    ("E-resource Subscriptions", "SUB", 8, "GENERAL", "Journal / database subscription and licence documents"),
    ("Library Policies", "POL", 0, "GENERAL", "Collection development, circulation, weeding and other policies"),
    ("Library Committee Minutes", "MIN", 0, "DEPARTMENT", "Agenda and minutes of library advisory committee meetings"),
    ("NAAC / NBA / Accreditation", "NAAC", 0, "GENERAL", "SSR data, AQAR, criterion-wise evidence, peer team reports"),
    ("Audit & Inspection Records", "AUD", 10, "CONFIDENTIAL", "Internal / external audit reports, UGC / university inspections"),
    ("Annual Reports", "ANR", 0, "GENERAL", "Annual reports of the library"),
    ("Statistical Reports", "STAT", 10, "GENERAL", "Monthly / yearly usage, circulation, footfall statistics"),
    ("Stock Verification", "STK", 10, "GENERAL", "Stock verification reports, loss and write-off records"),
    ("Correspondence", "COR", 5, "GENERAL", "Letters, circulars, e-mails with authorities and staff"),
    ("Budget & Grants", "BUD", 10, "DEPARTMENT", "Budget proposals, grant sanctions, utilisation certificates"),
    ("Donations & Gifts", "DON", 0, "GENERAL", "Gift / donation registers and acknowledgement letters"),
    ("Staff Records", "STF", 10, "CONFIDENTIAL", "Duty rosters, leave, training and staff-related records"),
    ("Accession & Weeding Registers", "REG", 0, "GENERAL", "Accession register copies, withdrawal / weeding lists"),
]

DEFAULT_DEPARTMENTS = [
    ("Central Library", "CL"),
    ("Acquisition Section", "ACQ"),
    ("Technical Section", "TECH"),
    ("Circulation Section", "CIRC"),
    ("Periodicals Section", "PER"),
    ("Digital Library", "DL"),
]


def load_defaults():
    from .models import Category, Department

    for name, code, years, conf, desc in DEFAULT_CATEGORIES:
        Category.objects.get_or_create(
            code=code,
            defaults={"name": name, "retention_years": years, "default_confidentiality": conf, "description": desc},
        )
    for name, code in DEFAULT_DEPARTMENTS:
        Department.objects.get_or_create(name=name, defaults={"code": code})
