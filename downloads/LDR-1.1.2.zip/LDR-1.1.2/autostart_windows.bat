@echo off
REM Shortcut: install LDR as a background service that starts with Windows.
call "%~dp0ldr_service.bat" install
