# LDR – Library Document Repository

Open-source software for preserving and managing a library's **internal documents**: invoices, purchase orders, vendor agreements, policies, committee minutes, NAAC/inspection data, statistical and annual reports, correspondence and audit records.

It implements the seven-phase LDR framework (aligned with the OAIS reference model, the Records Continuum Model and the DCC Curation Lifecycle Model):

| Phase | What LDR does | Who |
|---|---|---|
| 1. Creation / Receipt | Registers each document with source, reference number, hard-copy location and an assigned custodian; issues a unique ID (`LDR-2026-00001`) | Library staff |
| 2. Digitization | Uploads PDF/Word/Excel/images; records a SHA-256 checksum; OCR turns scans into searchable PDF access copies | Technical staff |
| 3. Metadata assignment | Dublin Core-based form: description, year, keywords, amount, access level, retention; expiry is calculated from the category | Cataloguer |
| 4. Validation & approval | Super Librarian approves (files verified) or returns with remarks; metadata is then locked | Super Librarian |
| 5. Active access | LAN-only web access; role-based permissions; confidential documents need permission; every view/download logged | Authorised staff |
| 6. Retention monitoring | Daily expiry check, alerts, review decisions (extend / permanent / dispose), daily integrity check and backup | System / Super Librarian |
| 7. Secure disposal | Request → approval by a *different* Super Librarian → files securely erased; record, reason and checksums kept; printable certificate | Admin authority |

All actions are written to an append-only, hash-chained **audit trail** that can be verified and exported for auditors.

### Open and edit files inside LDR
* **View in the browser**, with no download needed: PDF, images (zoom/rotate, including TIFF scans), Excel (`.xlsx/.xls/.csv`, sheet tabs, find), Word (`.docx`), text and e-mail (`.eml`). Downloading is still available.
* **Edit Excel, CSV, Word and text files in the browser**, or download → edit in Office → *Upload new version*.
* **Every edit is a new version.** Old versions are kept and viewable. Edits to an **approved record** become official only after the Super Librarian approves the new version.

### Automatic updates
The administrator sees **"Update available"** inside LDR and installs it with one click (backup → signature check → install → automatic rollback if anything fails). Libraries without internet can upload the update file. See `PUBLISHING_UPDATES.md` for how the developer publishes updates.

## Installation

LDR runs like Koha or DSpace: install it once on one computer (the "server"), and every staff computer on the library network uses it through a web browser.

* On the server: `http://localhost:8080`
* From other computers: `http://<server-IP>:8080` (for example `http://192.168.1.25:8080`)

### Windows (recommended for most libraries)
1. Install **Python 3.10 or newer** from python.org. Tick **"Add python.exe to PATH"**.
2. Unzip LDR to a permanent folder, for example `C:\LDR`.
3. Double-click **`install_windows.bat`**. Right-click and choose *Run as administrator* if you want it to open the firewall port automatically.
4. When the installer asks **"Set up LDR as a background service now?"**, press **Y**. LDR then runs with no window, like Koha and DSpace, and starts automatically whenever the computer is switched on, even before anyone logs in.
5. Open LDR with the **LDR - Library Document Repository** desktop shortcut (or `http://localhost:8080`) and complete the first-time setup page.
   * To manage the service later, double-click **`ldr_service.bat`** (Install / Start / Stop / Restart / Status / Remove).
   * `start_ldr.bat` runs LDR in a visible window instead, which is useful for troubleshooting.
6. Optional: install **Tesseract OCR** (https://github.com/UB-Mannheim/tesseract/wiki) to make scanned documents searchable.

### Linux (Ubuntu / Debian)
```bash
unzip LDR-1.0.1.zip && cd LDR-1.0.1
bash install_linux.sh          # installs, registers a systemd service and starts it
```

### Docker
```bash
docker compose up -d
```

## Configuration – `ldr_config.ini`
Created automatically on first start.

```ini
[server]
host = 0.0.0.0      ; 0.0.0.0 = reachable from the LAN, 127.0.0.1 = this computer only
port = 8080
[paths]
data_dir = data     ; database, files, backups, logs
[database]
engine = sqlite     ; or postgresql (pip install -r requirements-postgres.txt)
[ocr]
enabled = true
tesseract_cmd =     ; full path if Tesseract is not on PATH
languages = eng     ; e.g. eng+kan+hin if those language packs are installed
[email]
enabled = false     ; SMTP settings for e-mail alerts
```

Restart LDR after changing this file (`ldr_service.bat` → Restart).

## Backup and restore
* An automatic daily backup (database + all files) is written to `data/backups/`. You can also run one from **Settings & backup → Back up now**, or with `backup_now.bat` / `python manage.py ldr_backup`.
* **Copy the backup zips to an external drive regularly.**
* To restore: stop LDR (`ldr_service.bat` → Stop), run `python manage.py ldr_restore data/backups/ldr_backup_YYYYMMDD_HHMMSS.zip`, then start LDR again.

## Updating to a new version
From version 1.1.0 on: **Settings & backup → Software updates → Update now**. Without internet, use *Install an update from a file* with the release zip.

Updating from 1.0.x (one time, manually): stop LDR (`ldr_service.bat` → Stop), extract the new zip **over** the existing folder, replacing files, then run `install_windows.bat` again (it installs the new packages) and `ldr_service.bat` → Start. Your `data` folder and `ldr_config.ini` are not in the zip, so your documents are kept.

## Command reference
| Command | Purpose |
|---|---|
| `python run_server.py` | Start the server (add `--open` to open a browser) |
| `python manage.py ldr_daily --force` | Run the retention check, integrity check and backup now |
| `python manage.py ldr_backup` | Create a backup |
| `python manage.py ldr_restore <zip>` | Restore a backup |
| `python manage.py test repository` | Run the automated test suite |

## Technology
Python 3 · Django 5.2 · SQLite (default) or PostgreSQL · Waitress WSGI server · Bootstrap 5 (bundled; works without internet) · pypdf / python-docx / openpyxl text extraction · Tesseract OCR (optional).

## Security notes
* Use it inside the library/institution network only. Do not expose port 8080 to the internet.
* Give every staff member their own account. Accounts are never shared, because the audit trail records names.
* Disposal uses overwrite-then-delete. On SSDs, physical erasure can't be guaranteed at file level, so use full-disk encryption on the server for sensitive collections.

## Licence
Copyright © 2026 the LDR authors. Choose and add an open-source licence (for example GPL-3.0, the licence Koha uses) before public release.
